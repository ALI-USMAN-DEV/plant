# API URL Update Script
# Usage: .\UPDATE_API_URL.ps1 -Url "https://your-app.onrender.com/api"

param(
    [Parameter(Mandatory=$true)]
    [string]$Url
)

$apiConstantsFile = "frontend\lib\core\constants\api_constants.dart"

if (-not (Test-Path $apiConstantsFile)) {
    Write-Host "❌ Error: api_constants.dart file not found!" -ForegroundColor Red
    Write-Host "Path: $apiConstantsFile" -ForegroundColor Yellow
    exit 1
}

Write-Host "📝 Updating API URL..." -ForegroundColor Cyan
Write-Host "New URL: $Url" -ForegroundColor Yellow

# Read file
$content = Get-Content $apiConstantsFile -Raw

# Update baseUrl
$pattern = "static const String baseUrl = '[^']*';"
$replacement = "static const String baseUrl = '$Url';"

if ($content -match $pattern) {
    $content = $content -replace $pattern, $replacement
    
    # Write back
    Set-Content -Path $apiConstantsFile -Value $content -NoNewline
    
    Write-Host "✅ API URL updated successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "📋 Next Steps:" -ForegroundColor Cyan
    Write-Host "1. Rebuild APK: .\REBUILD_APK.ps1" -ForegroundColor White
    Write-Host "2. Or manually: cd frontend && flutter build apk --release" -ForegroundColor White
} else {
    Write-Host "❌ Error: Could not find baseUrl in file!" -ForegroundColor Red
    Write-Host "Please check the file manually." -ForegroundColor Yellow
    exit 1
}
