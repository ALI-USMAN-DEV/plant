<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('risk_zones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('map_layer_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->decimal('center_lat', 10, 8);
            $table->decimal('center_lng', 11, 8);
            $table->decimal('radius_meters', 10, 2);
            $table->string('color', 7)->default('#FF0000');
            $table->string('stroke_color', 7)->default('#000000');
            $table->integer('stroke_width')->default(2);
            $table->decimal('opacity', 3, 2)->default(0.5);
            $table->decimal('wind_direction', 5, 2)->default(0.0);
            $table->decimal('wind_velocity', 5, 2)->default(0.0);
            $table->boolean('is_visible')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('risk_zones');
    }
};
