<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('layout_layers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('map_layer_id')->constrained()->onDelete('cascade');
            $table->string('file_path');
            $table->string('file_name');
            $table->decimal('position_lat', 10, 8);
            $table->decimal('position_lng', 11, 8);
            $table->decimal('scale_x', 5, 2)->default(1.0);
            $table->decimal('scale_y', 5, 2)->default(1.0);
            $table->decimal('rotation', 5, 2)->default(0.0);
            $table->integer('width')->nullable();
            $table->integer('height')->nullable();
            $table->boolean('is_visible')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('layout_layers');
    }
};
