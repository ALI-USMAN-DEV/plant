<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class MapLayer extends Model
{
    protected $fillable = [
        'scenario_id',
        'layer_type',
        'name',
        'is_visible',
        'opacity',
        'z_index',
    ];

    protected $casts = [
        'is_visible' => 'boolean',
        'opacity' => 'decimal:2',
    ];

    public function scenario(): BelongsTo
    {
        return $this->belongsTo(Scenario::class);
    }

    public function layoutLayers(): HasMany
    {
        return $this->hasMany(LayoutLayer::class);
    }

    public function equipmentItems(): HasMany
    {
        return $this->hasMany(EquipmentItem::class);
    }

    public function escapeRoutes(): HasMany
    {
        return $this->hasMany(EscapeRoute::class);
    }

    public function riskZones(): HasMany
    {
        return $this->hasMany(RiskZone::class);
    }
}
