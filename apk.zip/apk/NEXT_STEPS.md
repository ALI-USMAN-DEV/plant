# Next Steps - Application Setup & Testing

## Step 1: Backend Setup (Laravel)

### 1.1 Install Dependencies
```bash
cd backend
composer install
```

### 1.2 Configure Environment
```bash
# Copy .env file
cp .env.example .env

# Edit .env file and set:
DB_DATABASE=plant_layout
DB_USERNAME=root
DB_PASSWORD=your_password
```

### 1.3 Generate App Key
```bash
php artisan key:generate
```

### 1.4 Create Database
```sql
CREATE DATABASE plant_layout CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 1.5 Run Migrations
```bash
php artisan migrate
```

### 1.6 Seed Sample Data (Optional)
```bash
php artisan db:seed
```
This creates:
- Admin user: `admin@example.com` / `password`
- Regular user: `user@example.com` / `password`
- Sample project with 50 scenarios

### 1.7 Create Storage Link
```bash
php artisan storage:link
```

### 1.8 Start Server
```bash
php artisan serve
```
Backend will run at: `http://localhost:8000`

## Step 2: Frontend Setup (Flutter)

### 2.1 Install Dependencies
```bash
cd frontend
flutter pub get
```

### 2.2 Configure API URL

Edit `lib/core/constants/api_constants.dart`:

**For Android Emulator:**
```dart
static const String baseUrl = 'http://10.0.2.2:8000/api';
```

**For Physical Device:**
```dart
// Replace with your computer's IP address
static const String baseUrl = 'http://192.168.1.100:8000/api';
```

**For Web/Desktop:**
```dart
static const String baseUrl = 'http://localhost:8000/api';
```

### 2.3 Run Application
```bash
flutter run
```

## Step 3: Test Application

### 3.1 Login Test
1. Open the app
2. Login with: `admin@example.com` / `password`
3. Verify you can see projects

### 3.2 Create Project
1. Click "Naya Project"
2. Enter project name
3. Click "Banaye"
4. Verify project appears in list

### 3.3 Test Map
1. Navigate to a scenario
2. Click "Map & Layers" tab
3. Verify Leaflet map loads
4. Test layer toggles
5. Verify map controls work

### 3.4 Test Other Tabs
- **Text Tab**: Enter text and save
- **Document Tab**: Upload a document
- **Table Tab**: Add rows/columns and save

## Step 4: Build APK

### 4.1 Build Debug APK
```bash
cd frontend
flutter build apk --debug
```
Output: `build/app/outputs/flutter-apk/app-debug.apk`

### 4.2 Build Release APK
```bash
flutter build apk --release
```
Output: `build/app/outputs/flutter-apk/app-release.apk`

### 4.3 Install APK
```bash
# Via ADB
adb install build/app/outputs/flutter-apk/app-release.apk

# Or transfer to device and install manually
```

## Step 5: Common Issues & Solutions

### Backend Issues

**Problem: Composer not found**
```bash
# Install Composer first
# Download from: https://getcomposer.org/
```

**Problem: Database connection error**
- Check MySQL is running
- Verify credentials in `.env`
- Check database exists

**Problem: Migration errors**
```bash
php artisan migrate:fresh
php artisan db:seed
```

### Frontend Issues

**Problem: Packages not installing**
```bash
flutter clean
flutter pub get
```

**Problem: API connection error**
- Check backend is running
- Verify API URL in `api_constants.dart`
- Check CORS settings in Laravel

**Problem: Maps not loading**
- Check internet connection
- Verify OpenStreetMap tiles are accessible
- Check network permissions

## Step 6: Development Checklist

- [ ] Backend running on port 8000
- [ ] Database created and migrated
- [ ] Sample data seeded
- [ ] Frontend dependencies installed
- [ ] API URL configured correctly
- [ ] App runs without errors
- [ ] Login works
- [ ] Map loads and displays
- [ ] Layers toggle correctly
- [ ] All tabs functional
- [ ] APK builds successfully

## Step 7: Production Deployment

### Backend Deployment
1. Set `APP_ENV=production` in `.env`
2. Set `APP_DEBUG=false`
3. Run `php artisan config:cache`
4. Deploy to server (Apache/Nginx)
5. Configure SSL/HTTPS

### Frontend Deployment
1. Build release APK
2. Sign APK (for Play Store)
3. Upload to Play Store or distribute directly

## Step 8: Additional Features (Optional)

### To Implement:
1. **Map Layer Editing**
   - Complete layout image upload
   - Equipment item placement UI
   - Escape route drawing tool
   - Risk zone drawing tool

2. **Offline Support**
   - Cache map tiles
   - Offline data storage

3. **Export Features**
   - Export scenarios as JSON
   - Export maps as images

4. **Advanced Features**
   - Search functionality
   - Filters and sorting
   - Bulk operations

## Need Help?

- Check `docs/` folder for detailed guides
- Review error messages carefully
- Check Laravel logs: `storage/logs/laravel.log`
- Check Flutter console for errors

---

**Ready to start? Begin with Step 1!** 🚀
