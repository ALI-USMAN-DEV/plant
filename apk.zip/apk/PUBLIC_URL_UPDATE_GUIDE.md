# Public URL Update Guide 🌐

## APK Build Complete! ✅

APK successfully built with placeholder URL. Ab URL update karna hoga.

---

## Quick Update Method

### Option 1: ngrok URL (Temporary - Testing)

1. **ngrok start karo:**
   ```bash
   ngrok http 8000
   ```

2. **URL get karo:**
   - Browser: http://localhost:4040
   - Forwarding URL copy karo (e.g., `https://abc123.ngrok-free.app`)

3. **API Constants update karo:**
   - File: `frontend/lib/core/constants/api_constants.dart`
   - Line 11: Update `baseUrl` with your ngrok URL
   - Format: `https://YOUR_URL.ngrok-free.app/api`

4. **APK rebuild:**
   ```bash
   cd frontend
   flutter clean
   flutter pub get
   flutter build apk --release
   ```

---

### Option 2: Free Cloud Hosting (Recommended - Permanent)

#### Using Render (Free Tier)

1. **Sign up:** https://render.com
2. **New Web Service:**
   - Connect GitHub repo (or upload backend code)
   - Build Command: `composer install`
   - Start Command: `php artisan serve --host=0.0.0.0 --port=$PORT`
   - Environment: PHP

3. **Get URL:**
   - Render provides: `https://your-app.onrender.com`
   - Update API constants: `https://your-app.onrender.com/api`

4. **Rebuild APK** (same as above)

#### Using Railway (Free Tier)

1. **Sign up:** https://railway.app
2. **New Project → Deploy from GitHub**
3. **Get URL:** Railway provides permanent URL
4. **Update API constants and rebuild APK**

---

## Current APK Status

- ✅ **Built:** `frontend/build/app/outputs/flutter-apk/app-release.apk`
- ⚠️ **URL:** Placeholder (needs update)
- 📝 **Next:** Update URL and rebuild, OR use cloud hosting

---

## Important Notes

1. **ngrok URLs change** every time you restart (free tier)
2. **Cloud hosting** provides permanent URLs (better for clients)
3. **After URL update**, rebuild APK before distributing

---

## Quick Commands

```bash
# Update URL in api_constants.dart, then:
cd frontend
flutter clean
flutter pub get
flutter build apk --release

# Install on device:
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

---

**APK ready! Just update URL and rebuild! 🚀**
