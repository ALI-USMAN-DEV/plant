import 'package:plant_layout_viewer/domain/entities/scenario_entity.dart';

class ScenarioModel extends ScenarioEntity {
  ScenarioModel({
    required super.id,
    required super.name,
    super.description,
    super.unitId,
    super.mapCenterLat,
    super.mapCenterLng,
    super.mapZoom,
  });

  factory ScenarioModel.fromJson(Map<String, dynamic> json) {
    return ScenarioModel(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      unitId: json['unit_id'],
      mapCenterLat: json['map_center_lat'] != null ? double.tryParse(json['map_center_lat'].toString()) : null,
      mapCenterLng: json['map_center_lng'] != null ? double.tryParse(json['map_center_lng'].toString()) : null,
      mapZoom: json['map_zoom'] != null ? (double.tryParse(json['map_zoom'].toString()) ?? 15.0) : 15.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'unit_id': unitId,
      'map_center_lat': mapCenterLat,
      'map_center_lng': mapCenterLng,
      'map_zoom': mapZoom,
    };
  }
}
