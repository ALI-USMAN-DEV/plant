<?php

namespace App\Http\Controllers;

use App\Models\Scenario;
use App\Models\MapLayer;
use App\Models\LayoutLayer;
use App\Models\EquipmentItem;
use App\Models\EscapeRoute;
use App\Models\RiskZone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class MapLayerController extends Controller
{
    // Helper function to check if user can access project
    private function canAccessProject($user, $project)
    {
        return $user->hasRole('admin') 
            || $project->user_id === $user->id
            || $project->assignedUsers->contains($user->id);
    }

    // Layout Layers
    public function storeLayoutLayer(Request $request, $projectId, $unitId, $scenarioId)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($scenarioId);

        // Admin, owner, or assigned user can edit scenarios (users have full access in scenarios)
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'map_layer_id' => 'required|exists:map_layers,id',
            'file' => 'required|image|max:10240',
            'position_lat' => 'required|numeric',
            'position_lng' => 'required|numeric',
            'scale_x' => 'nullable|numeric|min:0.1|max:10',
            'scale_y' => 'nullable|numeric|min:0.1|max:10',
            'rotation' => 'nullable|numeric',
            'width' => 'nullable|integer',
            'height' => 'nullable|integer',
        ]);

        $file = $request->file('file');
        $path = $file->store('layouts', 'public');

        $layoutLayer = LayoutLayer::create([
            'map_layer_id' => $request->map_layer_id,
            'file_path' => $path,
            'file_name' => $file->getClientOriginalName(),
            'position_lat' => $request->position_lat,
            'position_lng' => $request->position_lng,
            'scale_x' => $request->scale_x ?? 1.0,
            'scale_y' => $request->scale_y ?? 1.0,
            'rotation' => $request->rotation ?? 0.0,
            'width' => $request->width,
            'height' => $request->height,
            'is_visible' => true, // Default to visible
        ]);

        return response()->json([
            'success' => true,
            'data' => $layoutLayer->load('mapLayer'),
            'message' => 'Layout layer created successfully'
        ], 201);
    }

    public function updateLayoutLayer(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $layoutLayer = LayoutLayer::with('mapLayer.scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $layoutLayer->mapLayer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'position_lat' => 'sometimes|numeric',
            'position_lng' => 'sometimes|numeric',
            'scale_x' => 'nullable|numeric|min:0.1|max:10',
            'scale_y' => 'nullable|numeric|min:0.1|max:10',
            'rotation' => 'nullable|numeric',
            'width' => 'nullable|integer',
            'height' => 'nullable|integer',
            'is_visible' => 'sometimes|boolean',
        ]);

        $layoutLayer->update($request->only([
            'position_lat',
            'position_lng',
            'scale_x',
            'scale_y',
            'rotation',
            'width',
            'height',
            'is_visible'
        ]));

        return response()->json([
            'success' => true,
            'data' => $layoutLayer->load('mapLayer'),
            'message' => 'Layout layer updated successfully'
        ]);
    }

    public function deleteLayoutLayer(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $layoutLayer = LayoutLayer::with('mapLayer.scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $layoutLayer->mapLayer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        Storage::disk('public')->delete($layoutLayer->file_path);
        $layoutLayer->delete();

        return response()->json([
            'success' => true,
            'message' => 'Layout layer deleted successfully'
        ]);
    }

    // Equipment Items
    public function storeEquipmentItem(Request $request, $projectId, $unitId, $scenarioId)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($scenarioId);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'map_layer_id' => 'required|exists:map_layers,id',
            'name' => 'required|string|max:255',
            'icon' => 'nullable|image|max:2048',
            'position_lat' => 'required|numeric',
            'position_lng' => 'required|numeric',
            'rotation' => 'nullable|numeric',
            'size' => 'nullable|integer|min:16|max:256',
        ]);

        $iconPath = null;
        if ($request->hasFile('icon')) {
            $iconPath = $request->file('icon')->store('equipment', 'public');
        }

        $equipmentItem = EquipmentItem::create([
            'map_layer_id' => $request->map_layer_id,
            'name' => $request->name,
            'icon_path' => $iconPath,
            'position_lat' => $request->position_lat,
            'position_lng' => $request->position_lng,
            'rotation' => $request->rotation ?? 0.0,
            'size' => $request->size ?? 32,
        ]);

        return response()->json([
            'success' => true,
            'data' => $equipmentItem->load('mapLayer'),
            'message' => 'Equipment item created successfully'
        ], 201);
    }

    public function updateEquipmentItem(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $equipmentItem = EquipmentItem::with('mapLayer.scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $equipmentItem->mapLayer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'name' => 'sometimes|string|max:255',
            'icon' => 'nullable|image|max:2048',
            'position_lat' => 'sometimes|numeric',
            'position_lng' => 'sometimes|numeric',
            'rotation' => 'nullable|numeric',
            'size' => 'nullable|integer|min:16|max:256',
        ]);

        if ($request->hasFile('icon')) {
            if ($equipmentItem->icon_path) {
                Storage::disk('public')->delete($equipmentItem->icon_path);
            }
            $equipmentItem->icon_path = $request->file('icon')->store('equipment', 'public');
        }

        $equipmentItem->update($request->only([
            'name',
            'position_lat',
            'position_lng',
            'rotation',
            'size'
        ]));

        if ($request->hasFile('icon')) {
            $equipmentItem->icon_path = $equipmentItem->icon_path;
            $equipmentItem->save();
        }

        return response()->json([
            'success' => true,
            'data' => $equipmentItem->load('mapLayer'),
            'message' => 'Equipment item updated successfully'
        ]);
    }

    public function deleteEquipmentItem(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $equipmentItem = EquipmentItem::with('mapLayer.scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $equipmentItem->mapLayer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        if ($equipmentItem->icon_path) {
            Storage::disk('public')->delete($equipmentItem->icon_path);
        }
        $equipmentItem->delete();

        return response()->json([
            'success' => true,
            'message' => 'Equipment item deleted successfully'
        ]);
    }

    // Escape Routes
    public function storeEscapeRoute(Request $request, $projectId, $unitId, $scenarioId)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($scenarioId);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'map_layer_id' => 'required|exists:map_layers,id',
            'name' => 'required|string|max:255',
            'color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'width' => 'nullable|integer|min:1|max:20',
            'path_data' => 'required|array|min:2',
            'path_data.*.lat' => 'required|numeric',
            'path_data.*.lng' => 'required|numeric',
        ]);

        $escapeRoute = EscapeRoute::create([
            'map_layer_id' => $request->map_layer_id,
            'name' => $request->name,
            'color' => $request->color ?? '#FF0000',
            'width' => $request->width ?? 3,
            'path_data' => $request->path_data,
        ]);

        return response()->json([
            'success' => true,
            'data' => $escapeRoute->load('mapLayer'),
            'message' => 'Escape route created successfully'
        ], 201);
    }

    public function updateEscapeRoute(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $escapeRoute = EscapeRoute::with('mapLayer.scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $escapeRoute->mapLayer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'name' => 'sometimes|string|max:255',
            'color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'width' => 'nullable|integer|min:1|max:20',
            'path_data' => 'sometimes|array|min:2',
            'path_data.*.lat' => 'required_with:path_data|numeric',
            'path_data.*.lng' => 'required_with:path_data|numeric',
            'is_visible' => 'sometimes|boolean',
        ]);

        $escapeRoute->update($request->only([
            'name',
            'color',
            'width',
            'path_data',
            'is_visible'
        ]));

        return response()->json([
            'success' => true,
            'data' => $escapeRoute->load('mapLayer'),
            'message' => 'Escape route updated successfully'
        ]);
    }

    public function deleteEscapeRoute(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $escapeRoute = EscapeRoute::with('mapLayer.scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $escapeRoute->mapLayer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $escapeRoute->delete();

        return response()->json([
            'success' => true,
            'message' => 'Escape route deleted successfully'
        ]);
    }

    // Risk Zones
    public function storeRiskZone(Request $request, $projectId, $unitId, $scenarioId)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($scenarioId);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'map_layer_id' => 'required|exists:map_layers,id',
            'name' => 'required|string|max:255',
            'center_lat' => 'required|numeric',
            'center_lng' => 'required|numeric',
            'radius_meters' => 'required|numeric|min:1',
            'color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'stroke_color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'stroke_width' => 'nullable|integer|min:1|max:10',
            'opacity' => 'nullable|numeric|min:0|max:1',
            'wind_direction' => 'nullable|numeric|min:0|max:360',
            'wind_velocity' => 'nullable|numeric|min:0',
        ]);

        $riskZone = RiskZone::create([
            'map_layer_id' => $request->map_layer_id,
            'name' => $request->name,
            'center_lat' => $request->center_lat,
            'center_lng' => $request->center_lng,
            'radius_meters' => $request->radius_meters,
            'color' => $request->color ?? '#FF0000',
            'stroke_color' => $request->stroke_color ?? '#000000',
            'stroke_width' => $request->stroke_width ?? 2,
            'opacity' => $request->opacity ?? 0.5,
            'wind_direction' => $request->wind_direction ?? 0.0,
            'wind_velocity' => $request->wind_velocity ?? 0.0,
        ]);

        return response()->json([
            'success' => true,
            'data' => $riskZone->load('mapLayer'),
            'message' => 'Risk zone created successfully'
        ], 201);
    }

    public function updateRiskZone(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $riskZone = RiskZone::with('mapLayer.scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $riskZone->mapLayer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'name' => 'sometimes|string|max:255',
            'center_lat' => 'sometimes|numeric',
            'center_lng' => 'sometimes|numeric',
            'radius_meters' => 'sometimes|numeric|min:1',
            'color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'stroke_color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'stroke_width' => 'nullable|integer|min:1|max:10',
            'opacity' => 'nullable|numeric|min:0|max:1',
            'wind_direction' => 'nullable|numeric|min:0|max:360',
            'wind_velocity' => 'nullable|numeric|min:0',
            'is_visible' => 'sometimes|boolean',
        ]);

        $riskZone->update($request->only([
            'name',
            'center_lat',
            'center_lng',
            'radius_meters',
            'color',
            'stroke_color',
            'stroke_width',
            'opacity',
            'wind_direction',
            'wind_velocity',
            'is_visible'
        ]));

        return response()->json([
            'success' => true,
            'data' => $riskZone->load('mapLayer'),
            'message' => 'Risk zone updated successfully'
        ]);
    }

    public function deleteRiskZone(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $riskZone = RiskZone::with('mapLayer.scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $riskZone->mapLayer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $riskZone->delete();

        return response()->json([
            'success' => true,
            'message' => 'Risk zone deleted successfully'
        ]);
    }

    // Toggle layer visibility
    public function toggleLayer(Request $request, $projectId, $unitId, $scenarioId, $layerId)
    {
        $layer = MapLayer::with('scenario.unit.project.assignedUsers')->findOrFail($layerId);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $layer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'is_visible' => 'required|boolean',
        ]);

        $layer->update(['is_visible' => $request->is_visible]);

        return response()->json([
            'success' => true,
            'data' => $layer,
            'message' => 'Layer visibility updated successfully'
        ]);
    }

    // Update layer properties (opacity, z-index, visibility, name)
    public function updateLayer(Request $request, $projectId, $unitId, $scenarioId, $layerId)
    {
        $layer = MapLayer::with('scenario.unit.project.assignedUsers')->findOrFail($layerId);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $layer->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'name' => 'sometimes|string|max:255',
            'is_visible' => 'sometimes|boolean',
            'opacity' => 'sometimes|numeric|min:0|max:1',
            'z_index' => 'sometimes|integer|min:0',
        ]);

        $layer->update($request->only(['name', 'is_visible', 'opacity', 'z_index']));

        return response()->json([
            'success' => true,
            'data' => $layer->fresh(),
            'message' => 'Layer updated successfully'
        ]);
    }
}
