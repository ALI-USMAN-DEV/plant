# Post-Setup Verification Checklist

## ✅ Backend Verification

### Check Backend is Running
- [ ] Backend server running on `http://localhost:8000`
- [ ] Can access: `http://localhost:8000` (should show API message)
- [ ] Database connected successfully
- [ ] All migrations completed
- [ ] Sample data seeded (if done)

### Test Backend API
```bash
# Test login endpoint
curl -X POST http://localhost:8000/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"password"}'
```

Should return token and user data.

## ✅ Frontend Verification

### Check App Runs
- [ ] Flutter app launches without errors
- [ ] No compilation errors
- [ ] All dependencies installed

### Test Login
- [ ] Login screen appears
- [ ] Can login with `admin@example.com` / `password`
- [ ] After login, main screen shows

### Test Navigation
- [ ] Projects screen loads
- [ ] Can see projects (or empty list)
- [ ] Can create new project
- [ ] Can navigate to units
- [ ] Can navigate to scenarios

### Test Map Tab
- [ ] Map loads (Leaflet/OpenStreetMap)
- [ ] Map displays correctly
- [ ] Layer controls visible
- [ ] Can toggle layers on/off
- [ ] Map zoom/pan works

### Test Other Tabs
- [ ] Text tab opens
- [ ] Can enter text
- [ ] Can save text
- [ ] Document tab opens
- [ ] Can upload documents
- [ ] Table tab opens
- [ ] Can edit table
- [ ] Can save table

## ✅ APK Build Verification

### Check APK Built
- [ ] Debug APK created successfully
- [ ] Release APK created successfully
- [ ] APK size reasonable (< 50MB)
- [ ] APK installs on device

### Test APK on Device
- [ ] App launches on device
- [ ] All features work on device
- [ ] Map loads on device
- [ ] API connection works from device

## 🐛 Common Issues After Setup

### Issue: Backend not accessible from device
**Solution:**
1. Check backend is running
2. Find your computer's IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
3. Update `api_constants.dart` with your IP:
   ```dart
   static const String baseUrl = 'http://YOUR_IP:8000/api';
   ```
4. Make sure firewall allows port 8000

### Issue: CORS errors
**Solution:**
1. Check `backend/config/cors.php`
2. Add your frontend origin to allowed origins
3. Or temporarily allow all: `'allowed_origins' => ['*']`

### Issue: Maps not loading
**Solution:**
1. Check internet connection
2. Verify OpenStreetMap is accessible
3. Check network permissions in AndroidManifest.xml

### Issue: Database connection errors
**Solution:**
1. Verify MySQL is running
2. Check `.env` credentials
3. Test connection: `php artisan tinker` then `DB::connection()->getPdo();`

## 🚀 Next: Implement Missing Features

### Priority 1: Map Layer Editing

#### 1. Layout Image Upload
- [ ] Implement file picker for images
- [ ] Upload to backend
- [ ] Display on map
- [ ] Allow position/scale/rotate

#### 2. Equipment Item Placement
- [ ] Add equipment item dialog
- [ ] Allow drag & drop on map
- [ ] Save position to backend
- [ ] Display with custom icons

#### 3. Escape Route Drawing
- [ ] Implement drawing tool
- [ ] Allow polyline drawing
- [ ] Save route to backend
- [ ] Display with custom colors

#### 4. Risk Zone Drawing
- [ ] Implement circle drawing
- [ ] Allow radius adjustment
- [ ] Add wind direction indicator
- [ ] Save to backend

### Priority 2: Enhanced Features

- [ ] Search functionality
- [ ] Filters and sorting
- [ ] Bulk operations
- [ ] Export features
- [ ] Offline support

## 📱 Production Readiness

### Before Production Deployment

- [ ] Remove debug code
- [ ] Set `APP_DEBUG=false`
- [ ] Configure production database
- [ ] Set up SSL/HTTPS
- [ ] Configure proper CORS
- [ ] Set up backups
- [ ] Configure logging
- [ ] Performance testing
- [ ] Security audit

## 🎯 Success Criteria

Your application is ready when:
- ✅ All features work as expected
- ✅ No critical errors
- ✅ APK builds successfully
- ✅ App works on real device
- ✅ Backend API responds correctly
- ✅ Map displays and layers work
- ✅ All CRUD operations work

---

**Status Check:** Kya sab kuch theek se kaam kar raha hai? Agar koi issue hai to batao! 🚀
