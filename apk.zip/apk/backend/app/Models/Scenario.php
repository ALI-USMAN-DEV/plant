<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Scenario extends Model
{
    protected $fillable = [
        'unit_id',
        'name',
        'description',
        'map_center_lat',
        'map_center_lng',
        'map_zoom',
    ];

    protected $casts = [
        'map_center_lat' => 'decimal:8',
        'map_center_lng' => 'decimal:8',
        'map_zoom' => 'decimal:2',
    ];

    public function unit(): BelongsTo
    {
        return $this->belongsTo(Unit::class);
    }

    public function tabs(): HasMany
    {
        return $this->hasMany(ScenarioTab::class);
    }

    public function mapLayers(): HasMany
    {
        return $this->hasMany(MapLayer::class);
    }

    public function text(): HasOne
    {
        return $this->hasOne(ScenarioText::class);
    }

    public function table(): HasOne
    {
        return $this->hasOne(ScenarioTable::class);
    }

    public function documents(): HasMany
    {
        return $this->hasMany(ScenarioDocument::class);
    }
}
