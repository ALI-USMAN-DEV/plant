# Database Schema Design

## Entity Relationship Diagram

```
users (1) ──< user_roles (M) >── roles (1)
  │
  └──< projects (M)
        │
        └──< units (M)
              │
              └──< scenarios (M)
                    │
                    ├──< scenario_tabs (M)
                    ├──< map_layers (M)
                    ├──< layout_layers (M)
                    ├──< equipment_items (M)
                    ├──< escape_routes (M)
                    ├──< risk_zones (M)
                    ├──< scenario_texts (M)
                    ├──< scenario_tables (M)
                    └──< scenario_documents (M)
```

## Tables

### 1. users
Primary authentication and user management table.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | User ID |
| name | VARCHAR(255) | NOT NULL | User full name |
| email | VARCHAR(255) | UNIQUE, NOT NULL | Email address |
| email_verified_at | TIMESTAMP | NULLABLE | Email verification |
| password | VARCHAR(255) | NOT NULL | Hashed password |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 2. roles
User role definitions.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Role ID |
| name | VARCHAR(255) | UNIQUE, NOT NULL | Role name (admin, user) |
| description | TEXT | NULLABLE | Role description |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 3. user_roles
Pivot table for user-role relationships.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Pivot ID |
| user_id | BIGINT UNSIGNED | FOREIGN KEY → users.id | User reference |
| role_id | BIGINT UNSIGNED | FOREIGN KEY → roles.id | Role reference |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 4. projects
Top-level project container.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Project ID |
| user_id | BIGINT UNSIGNED | FOREIGN KEY → users.id | Owner/creator |
| name | VARCHAR(255) | NOT NULL | Project name |
| description | TEXT | NULLABLE | Project description |
| status | ENUM('active', 'archived') | DEFAULT 'active' | Project status |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 5. units
Units within a project.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Unit ID |
| project_id | BIGINT UNSIGNED | FOREIGN KEY → projects.id | Parent project |
| name | VARCHAR(255) | NOT NULL | Unit name |
| description | TEXT | NULLABLE | Unit description |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 6. scenarios
Scenarios within a unit (40-60+ per unit).

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Scenario ID |
| unit_id | BIGINT UNSIGNED | FOREIGN KEY → units.id | Parent unit |
| name | VARCHAR(255) | NOT NULL | Scenario name |
| description | TEXT | NULLABLE | Scenario description |
| map_center_lat | DECIMAL(10,8) | NULLABLE | Map center latitude |
| map_center_lng | DECIMAL(11,8) | NULLABLE | Map center longitude |
| map_zoom | DECIMAL(5,2) | DEFAULT 15.0 | Map zoom level |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 7. scenario_tabs
Tabs within a scenario (Map, Text, Document, Table).

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Tab ID |
| scenario_id | BIGINT UNSIGNED | FOREIGN KEY → scenarios.id | Parent scenario |
| type | ENUM('map', 'text', 'document', 'table') | NOT NULL | Tab type |
| title | VARCHAR(255) | NOT NULL | Tab title |
| order | INT | DEFAULT 0 | Display order |
| is_active | BOOLEAN | DEFAULT true | Active status |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 8. map_layers
Base map layer configuration.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Layer ID |
| scenario_id | BIGINT UNSIGNED | FOREIGN KEY → scenarios.id | Parent scenario |
| layer_type | ENUM('base', 'layout', 'equipment', 'escape_route', 'risk_zone') | NOT NULL | Layer type |
| name | VARCHAR(255) | NOT NULL | Layer name |
| is_visible | BOOLEAN | DEFAULT true | Visibility toggle |
| opacity | DECIMAL(3,2) | DEFAULT 1.0 | Layer opacity (0-1) |
| z_index | INT | DEFAULT 0 | Z-order for stacking |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 9. layout_layers
Layout image overlays on map.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Layout ID |
| map_layer_id | BIGINT UNSIGNED | FOREIGN KEY → map_layers.id | Parent layer |
| file_path | VARCHAR(500) | NOT NULL | Image file path |
| file_name | VARCHAR(255) | NOT NULL | Original filename |
| position_lat | DECIMAL(10,8) | NOT NULL | Anchor latitude |
| position_lng | DECIMAL(11,8) | NOT NULL | Anchor longitude |
| scale_x | DECIMAL(5,2) | DEFAULT 1.0 | X-axis scale |
| scale_y | DECIMAL(5,2) | DEFAULT 1.0 | Y-axis scale |
| rotation | DECIMAL(5,2) | DEFAULT 0.0 | Rotation in degrees |
| width | INT | NULLABLE | Display width (px) |
| height | INT | NULLABLE | Display height (px) |
| is_visible | BOOLEAN | DEFAULT true | Visibility toggle |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 10. equipment_items
Equipment icons/items placed on map.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Equipment ID |
| map_layer_id | BIGINT UNSIGNED | FOREIGN KEY → map_layers.id | Parent layer |
| name | VARCHAR(255) | NOT NULL | Equipment name |
| icon_path | VARCHAR(500) | NULLABLE | Custom icon path |
| position_lat | DECIMAL(10,8) | NOT NULL | Latitude position |
| position_lng | DECIMAL(11,8) | NOT NULL | Longitude position |
| rotation | DECIMAL(5,2) | DEFAULT 0.0 | Icon rotation |
| size | INT | DEFAULT 32 | Icon size (px) |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 11. escape_routes
Escape route polylines.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Route ID |
| map_layer_id | BIGINT UNSIGNED | FOREIGN KEY → map_layers.id | Parent layer |
| name | VARCHAR(255) | NOT NULL | Route name |
| color | VARCHAR(7) | DEFAULT '#FF0000' | Hex color code |
| width | INT | DEFAULT 3 | Line width (px) |
| path_data | JSON | NOT NULL | Array of {lat, lng} points |
| is_visible | BOOLEAN | DEFAULT true | Visibility toggle |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 12. risk_zones
Risk zone circles with wind direction.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Zone ID |
| map_layer_id | BIGINT UNSIGNED | FOREIGN KEY → map_layers.id | Parent layer |
| name | VARCHAR(255) | NOT NULL | Zone name |
| center_lat | DECIMAL(10,8) | NOT NULL | Circle center latitude |
| center_lng | DECIMAL(11,8) | NOT NULL | Circle center longitude |
| radius_meters | DECIMAL(10,2) | NOT NULL | Radius in meters |
| color | VARCHAR(7) | DEFAULT '#FF0000' | Fill color hex |
| stroke_color | VARCHAR(7) | DEFAULT '#000000' | Border color hex |
| stroke_width | INT | DEFAULT 2 | Border width (px) |
| opacity | DECIMAL(3,2) | DEFAULT 0.5 | Fill opacity (0-1) |
| wind_direction | DECIMAL(5,2) | DEFAULT 0.0 | Wind direction (degrees) |
| wind_velocity | DECIMAL(5,2) | DEFAULT 0.0 | Wind velocity (m/s) |
| is_visible | BOOLEAN | DEFAULT true | Visibility toggle |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 13. scenario_texts
Rich text content for text tab.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Text ID |
| scenario_id | BIGINT UNSIGNED | FOREIGN KEY → scenarios.id | Parent scenario |
| content | LONGTEXT | NULLABLE | Rich text HTML content |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 14. scenario_tables
Editable table data for table tab.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Table ID |
| scenario_id | BIGINT UNSIGNED | FOREIGN KEY → scenarios.id | Parent scenario |
| table_data | JSON | NOT NULL | Table structure: {headers: [], rows: []} |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 15. scenario_documents
Images, PDFs, Word files for document tab.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Document ID |
| scenario_id | BIGINT UNSIGNED | FOREIGN KEY → scenarios.id | Parent scenario |
| file_path | VARCHAR(500) | NOT NULL | File storage path |
| file_name | VARCHAR(255) | NOT NULL | Original filename |
| file_type | ENUM('image', 'pdf', 'word') | NOT NULL | File type |
| file_size | BIGINT | NULLABLE | File size in bytes |
| mime_type | VARCHAR(100) | NULLABLE | MIME type |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

### 16. reports
Generated PDF reports at unit level.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | BIGINT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Report ID |
| unit_id | BIGINT UNSIGNED | FOREIGN KEY → units.id | Parent unit |
| user_id | BIGINT UNSIGNED | FOREIGN KEY → users.id | Generated by |
| file_path | VARCHAR(500) | NOT NULL | PDF file path |
| file_name | VARCHAR(255) | NOT NULL | Report filename |
| file_size | BIGINT | NULLABLE | File size in bytes |
| generated_at | TIMESTAMP | NOT NULL | Generation timestamp |
| created_at | TIMESTAMP | NULLABLE | Creation timestamp |
| updated_at | TIMESTAMP | NULLABLE | Update timestamp |

## Indexes

### Performance Indexes
- `users.email` - UNIQUE index
- `projects.user_id` - Index for user's projects
- `units.project_id` - Index for project's units
- `scenarios.unit_id` - Index for unit's scenarios
- `scenario_tabs.scenario_id` - Index for scenario's tabs
- `map_layers.scenario_id` - Index for scenario's layers
- `reports.unit_id` - Index for unit's reports

## Relationships Summary

1. **users** → **projects** (1:N)
2. **projects** → **units** (1:N)
3. **units** → **scenarios** (1:N, 40-60+)
4. **scenarios** → **scenario_tabs** (1:N)
5. **scenarios** → **map_layers** (1:N)
6. **map_layers** → **layout_layers** (1:N)
7. **map_layers** → **equipment_items** (1:N)
8. **map_layers** → **escape_routes** (1:N)
9. **map_layers** → **risk_zones** (1:N)
10. **scenarios** → **scenario_texts** (1:1)
11. **scenarios** → **scenario_tables** (1:1)
12. **scenarios** → **scenario_documents** (1:N)
13. **units** → **reports** (1:N)
14. **users** → **roles** (N:M via user_roles)
