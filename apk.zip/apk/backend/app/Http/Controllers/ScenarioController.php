<?php

namespace App\Http\Controllers;

use App\Models\Scenario;
use App\Models\Unit;
use Illuminate\Http\Request;

class ScenarioController extends Controller
{
    // Helper function to check if user can access project
    private function canAccessProject($user, $project)
    {
        return $user->hasRole('admin') 
            || $project->user_id === $user->id
            || $project->assignedUsers->contains($user->id);
    }

    public function index(Request $request, $projectId, $unitId)
    {
        $unit = Unit::with('project.assignedUsers')->findOrFail($unitId);

        // Check permission - admin, owner, or assigned user
        if (!$this->canAccessProject($request->user(), $unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $scenarios = Scenario::where('unit_id', $unitId)
            ->with(['tabs', 'mapLayers', 'text', 'table', 'documents'])
            ->get();

        return response()->json([
            'success' => true,
            'data' => $scenarios,
        ]);
    }

    public function store(Request $request, $projectId, $unitId)
    {
        $unit = Unit::with('project.assignedUsers')->findOrFail($unitId);

        // Only admin or project owner can create scenarios
        if (!$request->user()->hasRole('admin') && $unit->project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin or project owner can create scenarios'
            ], 403);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'map_center_lat' => 'nullable|numeric',
            'map_center_lng' => 'nullable|numeric',
            'map_zoom' => 'nullable|numeric|min:1|max:20',
        ]);

        $scenario = Scenario::create([
            'unit_id' => $unitId,
            'name' => $request->name,
            'description' => $request->description,
            'map_center_lat' => $request->map_center_lat,
            'map_center_lng' => $request->map_center_lng,
            'map_zoom' => $request->map_zoom ?? 15.0,
        ]);

        // Create default tabs
        $defaultTabs = [
            ['type' => 'map', 'title' => 'Map & Layers', 'order' => 0],
            ['type' => 'text', 'title' => 'Text', 'order' => 1],
            ['type' => 'document', 'title' => 'Documents', 'order' => 2],
            ['type' => 'table', 'title' => 'Table', 'order' => 3],
        ];

        foreach ($defaultTabs as $tab) {
            $scenario->tabs()->create($tab);
        }

        // Create default map layers
        $defaultLayers = [
            ['layer_type' => 'base', 'name' => 'Base Map', 'z_index' => 0],
            ['layer_type' => 'layout', 'name' => 'Layout Layer', 'z_index' => 1],
            ['layer_type' => 'equipment', 'name' => 'Equipment Layer', 'z_index' => 2],
            ['layer_type' => 'escape_route', 'name' => 'Escape Route Layer', 'z_index' => 3],
            ['layer_type' => 'risk_zone', 'name' => 'Risk Zone Layer', 'z_index' => 4],
        ];

        foreach ($defaultLayers as $layer) {
            $scenario->mapLayers()->create($layer);
        }

        return response()->json([
            'success' => true,
            'data' => $scenario->load(['tabs', 'mapLayers', 'text', 'table', 'documents']),
            'message' => 'Scenario created successfully'
        ], 201);
    }

    public function show(Request $request, $projectId, $unitId, $id)
    {
        $scenario = Scenario::with([
            'unit.project.assignedUsers',
            'tabs',
            'mapLayers.layoutLayers',
            'mapLayers.equipmentItems',
            'mapLayers.escapeRoutes',
            'mapLayers.riskZones',
            'text',
            'table',
            'documents'
        ])->findOrFail($id);

        // Check permission - admin, owner, or assigned user can view
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        return response()->json([
            'success' => true,
            'data' => $scenario,
        ]);
    }

    public function update(Request $request, $projectId, $unitId, $id)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can update scenarios (users have full access in scenarios)
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'map_center_lat' => 'nullable|numeric',
            'map_center_lng' => 'nullable|numeric',
            'map_zoom' => 'nullable|numeric|min:1|max:20',
        ]);

        $scenario->update($request->only([
            'name',
            'description',
            'map_center_lat',
            'map_center_lng',
            'map_zoom'
        ]));

        return response()->json([
            'success' => true,
            'data' => $scenario->load(['tabs', 'mapLayers', 'text', 'table', 'documents']),
            'message' => 'Scenario updated successfully'
        ]);
    }

    public function destroy(Request $request, $projectId, $unitId, $id)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($id);

        // Only admin or project owner can delete scenarios
        if (!$request->user()->hasRole('admin') && $scenario->unit->project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin or project owner can delete scenarios'
            ], 403);
        }

        $scenario->delete();

        return response()->json([
            'success' => true,
            'message' => 'Scenario deleted successfully'
        ]);
    }
}
