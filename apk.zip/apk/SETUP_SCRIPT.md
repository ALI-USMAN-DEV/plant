# Setup Script - Step by Step Execution

## Step 1: Backend Setup

### 1.1 Check Composer
```bash
composer --version
```

### 1.2 Install Dependencies
```bash
cd backend
composer install
```

### 1.3 Create .env File
```bash
# If .env doesn't exist, copy from .env.example
copy .env.example .env
# Or manually create .env with these settings:
```

### 1.4 Generate App Key
```bash
php artisan key:generate
```

### 1.5 Create Database
```sql
CREATE DATABASE plant_layout CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 1.6 Run Migrations
```bash
php artisan migrate
```

### 1.7 Seed Database
```bash
php artisan db:seed
```

### 1.8 Create Storage Link
```bash
php artisan storage:link
```

### 1.9 Start Server
```bash
php artisan serve
```

## Step 2: Frontend Setup

### 2.1 Install Dependencies
```bash
cd frontend
flutter pub get
```

### 2.2 Configure API URL
Edit `lib/core/constants/api_constants.dart`:
- For emulator: `http://10.0.2.2:8000/api`
- For device: `http://YOUR_IP:8000/api`

### 2.3 Run App
```bash
flutter run
```

## Step 3: Test

1. Login with: `admin@example.com` / `password`
2. Create project
3. Create unit
4. Create scenario
5. Test map features
