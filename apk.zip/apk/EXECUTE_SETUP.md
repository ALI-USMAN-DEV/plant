# Execute Setup - Step by Step

## ✅ Automated Setup Script

Main ne setup script banaya hai. Ab aap yeh kar sakte hain:

### Option 1: PowerShell Script (Recommended)
```powershell
.\RUN_SETUP.ps1
```

### Option 2: Batch Script
```cmd
RUN_SETUP.bat
```

## 📋 Manual Setup (Agar scripts kaam na karein)

### Backend Setup

#### Step 1: Install Composer Dependencies
```bash
cd backend
composer install
```

#### Step 2: Create .env File
```bash
# Windows
copy .env.example .env

# Or manually create .env with:
DB_DATABASE=plant_layout
DB_USERNAME=root
DB_PASSWORD=your_password
```

#### Step 3: Generate App Key
```bash
php artisan key:generate
```

#### Step 4: Create Database
MySQL mein run karo:
```sql
CREATE DATABASE plant_layout CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

#### Step 5: Run Migrations
```bash
php artisan migrate
```

#### Step 6: Seed Database
```bash
php artisan db:seed
```

#### Step 7: Create Storage Link
```bash
php artisan storage:link
```

#### Step 8: Start Server
```bash
php artisan serve
```

Backend ab `http://localhost:8000` par chalega.

### Frontend Setup

#### Step 1: Install Dependencies
```bash
cd frontend
flutter pub get
```

#### Step 2: Configure API URL
Edit `lib/core/constants/api_constants.dart`:
```dart
// Android Emulator ke liye:
static const String baseUrl = 'http://10.0.2.2:8000/api';

// Physical device ke liye (apni IP use karo):
static const String baseUrl = 'http://192.168.1.100:8000/api';
```

#### Step 3: Run App
```bash
flutter run
```

## 🧪 Test Karein

1. **Login**: `admin@example.com` / `password`
2. **Project Create**: "Naya Project" click karo
3. **Unit Create**: Project mein "Naya Unit" click karo
4. **Scenario Create**: Unit mein "Naya Scenario" click karo
5. **Map Test**: Scenario mein "Map & Layers" tab mein jao
6. **Features Test**:
   - Layout image upload
   - Equipment add
   - Escape route draw
   - Risk zone create

## ✅ Success Indicators

- ✅ Backend: `http://localhost:8000` accessible
- ✅ Frontend: App launches without errors
- ✅ Login: Successfully logs in
- ✅ Map: Leaflet map displays
- ✅ Features: All features work

## 🐛 Agar Issues Aayein

### Backend Issues
- **Composer not found**: Install from https://getcomposer.org/
- **PHP not found**: Install PHP 8.1+ from https://php.net/
- **Database error**: Check MySQL is running and credentials

### Frontend Issues
- **Flutter not found**: Install from https://flutter.dev/
- **Pub get fails**: Run `flutter clean && flutter pub get`
- **API error**: Check backend URL in `api_constants.dart`

---

**Setup Complete!** Ab aap app use kar sakte hain! 🚀
