<?php

namespace App\Http\Controllers;

use App\Models\Unit;
use App\Models\Report;
use App\Services\ReportService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ReportController extends Controller
{
    protected $reportService;

    public function __construct(ReportService $reportService)
    {
        $this->reportService = $reportService;
    }

    public function generate(Request $request, $projectId, $unitId)
    {
        $unit = Unit::with('project')->findOrFail($unitId);

        // Check permission
        if (!$request->user()->hasRole('admin') && $unit->project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $report = $this->reportService->generateReport($unit, $request->user()->id);

        return response()->json([
            'success' => true,
            'data' => $report,
            'message' => 'Report generated successfully'
        ], 201);
    }

    public function index(Request $request, $projectId, $unitId)
    {
        $unit = Unit::with('project')->findOrFail($unitId);

        // Check permission
        if (!$request->user()->hasRole('admin') && $unit->project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $reports = Report::where('unit_id', $unitId)
            ->with('user')
            ->orderBy('generated_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $reports,
        ]);
    }

    public function download(Request $request, $projectId, $unitId, $id)
    {
        $report = Report::with('unit.project')->findOrFail($id);

        // Check permission
        if (!$request->user()->hasRole('admin') && $report->unit->project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        if (!Storage::disk('public')->exists($report->file_path)) {
            return response()->json([
                'success' => false,
                'message' => 'Report file not found'
            ], 404);
        }

        return Storage::disk('public')->download($report->file_path, $report->file_name);
    }
}
