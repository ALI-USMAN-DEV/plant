import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:plant_layout_viewer/data/models/project_model.dart';
import 'package:plant_layout_viewer/data/models/unit_model.dart';
import 'package:plant_layout_viewer/data/services/api_service.dart';
import 'package:plant_layout_viewer/core/constants/api_constants.dart';
import 'package:plant_layout_viewer/presentation/screens/scenarios/scenarios_screen.dart';
import 'package:plant_layout_viewer/presentation/providers/auth_provider.dart';

class UnitsScreen extends StatefulWidget {
  final ProjectModel project;

  const UnitsScreen({super.key, required this.project});

  @override
  State<UnitsScreen> createState() => _UnitsScreenState();
}

class _UnitsScreenState extends State<UnitsScreen> {
  List<UnitModel> _units = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUnits();
  }

  Future<void> _loadUnits() async {
    setState(() => _isLoading = true);
    try {
      final response = await ApiService().get(ApiConstants.units(widget.project.id));
      if (response.statusCode == 200 && response.data['success'] == true) {
        setState(() {
          _units = (response.data['data'] as List)
              .map((json) => UnitModel.fromJson(json))
              .toList();
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error loading units: $e')),
        );
      }
    }
  }

  Future<void> _createUnit() async {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create Unit'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Unit Name'),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(labelText: 'Description'),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Create'),
          ),
        ],
      ),
    );

    if (result == true && nameController.text.isNotEmpty) {
      try {
        final response = await ApiService().post(
          ApiConstants.units(widget.project.id),
          data: {
            'name': nameController.text,
            'description': descriptionController.text.isEmpty ? null : descriptionController.text,
          },
        );

        if (response.statusCode == 201) {
          _loadUnits();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error creating unit: $e')),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Units - ${widget.project.name}'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Units',
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      // Only show create button for admin
                      Consumer<AuthProvider>(
                        builder: (context, authProvider, child) {
                          if (authProvider.isAdmin) {
                            return ElevatedButton.icon(
                              onPressed: _createUnit,
                              icon: const Icon(Icons.add),
                              label: const Text('New Unit'),
                            );
                          }
                          return const SizedBox.shrink();
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _units.isEmpty
                      ? const Center(child: Text('No units found. Create one to get started.'))
                      : ListView.builder(
                          itemCount: _units.length,
                          itemBuilder: (context, index) {
                            final unit = _units[index];
                            return Card(
                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: ListTile(
                                leading: const Icon(Icons.category, size: 40),
                                title: Text(unit.name),
                                subtitle: unit.description != null
                                    ? Text(unit.description!)
                                    : null,
                                trailing: const Icon(Icons.chevron_right),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => ScenariosScreen(
                                        project: widget.project,
                                        unit: unit,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
