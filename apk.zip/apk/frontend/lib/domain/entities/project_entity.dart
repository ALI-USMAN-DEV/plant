class ProjectEntity {
  final int id;
  final String name;
  final String? description;
  final String status;
  final int? userId;

  ProjectEntity({
    required this.id,
    required this.name,
    this.description,
    this.status = 'active',
    this.userId,
  });
}
