<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ScenarioTable extends Model
{
    protected $fillable = [
        'scenario_id',
        'table_data',
    ];

    protected $casts = [
        'table_data' => 'array',
    ];

    public function scenario(): BelongsTo
    {
        return $this->belongsTo(Scenario::class);
    }
}
