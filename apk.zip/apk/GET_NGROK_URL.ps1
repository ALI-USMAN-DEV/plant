# Get ngrok Public URL
Write-Host "Fetching ngrok public URL..." -ForegroundColor Cyan
Write-Host ""

Start-Sleep -Seconds 2

try {
    $response = Invoke-RestMethod -Uri "http://localhost:4040/api/tunnels" -Method GET -ErrorAction Stop
    
    if ($response.tunnels -and $response.tunnels.Count -gt 0) {
        $publicUrl = $response.tunnels[0].public_url
        $apiUrl = "$publicUrl/api"
        
        Write-Host "========================================" -ForegroundColor Green
        Write-Host "✅ PUBLIC URL FOUND!" -ForegroundColor Green
        Write-Host "========================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "🌐 Public URL: $publicUrl" -ForegroundColor Yellow
        Write-Host "🔗 API URL: $apiUrl" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "This URL can be accessed from anywhere!" -ForegroundColor Green
        Write-Host ""
        
        # Save to file
        $publicUrl | Out-File -FilePath "ngrok_url.txt" -Encoding UTF8
        Write-Host "URL saved to: ngrok_url.txt" -ForegroundColor Cyan
        Write-Host ""
        
        return $apiUrl
    } else {
        Write-Host "❌ No tunnels found!" -ForegroundColor Red
        Write-Host "Make sure ngrok is running: ngrok http 8000" -ForegroundColor Yellow
    }
} catch {
    Write-Host "❌ Could not connect to ngrok API" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please:" -ForegroundColor Yellow
    Write-Host "  1. Open browser: http://localhost:4040" -ForegroundColor White
    Write-Host "  2. Check 'Forwarding' section for public URL" -ForegroundColor White
    Write-Host "  3. Share the URL (starts with https://)" -ForegroundColor White
    Write-Host ""
}
