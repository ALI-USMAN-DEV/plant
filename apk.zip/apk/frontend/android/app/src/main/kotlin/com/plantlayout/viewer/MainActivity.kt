package com.plantlayout.viewer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
