# Quick Start Guide

Get the application running in 5 minutes!

## Prerequisites Check

- [ ] PHP >= 8.1 installed
- [ ] Composer installed
- [ ] MySQL installed and running
- [ ] Flutter SDK >= 3.0 installed
- [ ] Android Studio (for APK builds)

## Step 1: Backend Setup (2 minutes)

```bash
# Navigate to backend
cd backend

# Install dependencies
composer install

# Copy environment file
cp .env.example .env

# Edit .env and set:
# - DB_DATABASE=plant_layout
# - DB_USERNAME=your_username
# - DB_PASSWORD=your_password

# Generate app key
php artisan key:generate

# Create database
mysql -u root -p -e "CREATE DATABASE plant_layout CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Run migrations
php artisan migrate

# Seed sample data (optional)
php artisan db:seed

# Create storage link
php artisan storage:link

# Start server
php artisan serve
```

Backend is now running at `http://localhost:8000`

## Step 2: Frontend Setup (2 minutes)

```bash
# Navigate to frontend
cd frontend

# Install dependencies
flutter pub get

# Configure API URL (if needed)
# Edit lib/core/constants/api_constants.dart
# Change baseUrl to your backend URL

# For Android emulator: http://10.0.2.2:8000/api
# For physical device: http://YOUR_IP:8000/api

# Run app
flutter run
```

## Step 3: Test Login

**Note:** No API key needed! The app uses Leaflet maps with OpenStreetMap (free, no setup required).

Use default credentials:
- Email: `admin@example.com`
- Password: `password`

## Build APK

```bash
cd frontend
flutter build apk --release
```

APK location: `build/app/outputs/flutter-apk/app-release.apk`

## Troubleshooting

### Backend won't start
- Check PHP version: `php -v`
- Check MySQL is running
- Verify database credentials in `.env`

### Frontend won't connect
- Check backend is running
- Verify API URL in `api_constants.dart`
- Check CORS settings in Laravel

### Maps not showing
- Check internet connection (required for map tiles)
- Verify OpenStreetMap tile server is accessible

## Need Help?

See detailed guides in `docs/` directory:
- `BACKEND_SETUP.md` - Detailed backend setup
- `FRONTEND_SETUP.md` - Detailed frontend setup
- `APK_BUILD_GUIDE.md` - APK building guide

---

**You're all set!** 🎉
