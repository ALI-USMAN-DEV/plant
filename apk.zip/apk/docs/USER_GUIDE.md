# User Guide

## Getting Started

### Login
1. Open the Plant Layout Viewer app
2. Enter your email and password
3. Tap "Login"

**Default Credentials:**
- Admin: `admin@example.com` / `password`
- User: `user@example.com` / `password`

## Navigation

### Main Screen
- **Projects**: View and manage all projects
- **User Menu**: Access profile and logout

### Project Hierarchy
1. **Projects** → Contains multiple Units
2. **Units** → Contains 40-60+ Scenarios
3. **Scenarios** → Contains Tabs (Map, Text, Documents, Table)

## Working with Projects

### Create Project
1. Tap "New Project" button
2. Enter project name
3. (Optional) Add description
4. Tap "Create"

### View Units
1. Tap on a project card
2. View all units in that project

## Working with Units

### Create Unit
1. Navigate to a project
2. Tap "New Unit" button
3. Enter unit name
4. (Optional) Add description
5. Tap "Create"

### View Scenarios
1. Tap on a unit card
2. View all scenarios (40-60+ per unit)

## Working with Scenarios

### Create Scenario
1. Navigate to a unit
2. Tap "New Scenario" button
3. Enter scenario name
4. (Optional) Add description
5. Tap "Create"

### Scenario Tabs

Each scenario has 4 tabs:

#### 1. Map & Layers Tab
- **Google Map**: Interactive map view
- **Layer Controls**: Toggle visibility of:
  - Base Map
  - Layout Layer (multiple images)
  - Equipment Layer (icons)
  - Escape Route Layer (polylines)
  - Risk Zone Layer (circles)

**Adding Layers:**
- Tap "Add Layer" button
- Choose layer type:
  - **Layout Image**: Upload and overlay images
  - **Equipment Item**: Place equipment icons
  - **Escape Route**: Draw escape routes
  - **Risk Zone**: Draw risk zones with wind direction

**Layout Images:**
- Upload multiple images
- Position, scale, and rotate images
- Toggle visibility per image

**Equipment Items:**
- Upload custom icons
- Drag and drop on map
- Position anywhere

**Escape Routes:**
- Draw polylines on map
- Customize colors
- Show/hide routes

**Risk Zones:**
- Draw circles on map
- Set radius
- Configure color and opacity
- Set wind direction (rotation)
- Set wind velocity

#### 2. Text Tab
- Rich text editor
- Format text (bold, italic, lists, etc.)
- Auto-save functionality
- Tap "Save" to manually save

#### 3. Documents Tab
- Upload images, PDFs, Word files
- View uploaded documents
- Delete documents
- Tap "Upload Document" to add files

#### 4. Table Tab
- Editable table
- Add/remove rows and columns
- Edit headers
- Enter custom data
- Tap "Save" to save changes

## Generating Reports

### Unit-Level Reports
1. Navigate to a unit's scenarios list
2. Tap the PDF icon in the app bar
3. Report is generated with:
   - All scenarios in the unit
   - Maps (screenshots)
   - Text content
   - Tables
   - Images
4. Download the generated PDF

## Tips

### Map Navigation
- Pinch to zoom
- Drag to pan
- Tap markers for details
- Use layer controls to show/hide elements

### Data Entry
- Tables auto-save on cell edit
- Text editor has auto-save
- Documents upload immediately

### Performance
- Large scenarios may take time to load
- Map with many layers may be slower
- Close unused scenarios

## Troubleshooting

### Map not loading
- Check internet connection
- Verify Google Maps API key is configured
- Check location permissions

### Can't upload files
- Check file size limits
- Verify file type is supported
- Ensure storage permissions

### API errors
- Check backend is running
- Verify login credentials
- Check network connection

## Permissions

### Admin Role
- Full access to all features
- Can create/edit/delete everything
- Can manage users

### User Role
- View all projects/units/scenarios
- Edit scenarios (limited)
- Generate reports
- Cannot delete projects/units

## Support

For issues or questions:
1. Check this guide
2. Review error messages
3. Contact administrator
4. Check system logs
