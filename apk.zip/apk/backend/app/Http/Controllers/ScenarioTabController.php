<?php

namespace App\Http\Controllers;

use App\Models\Scenario;
use App\Models\ScenarioTab;
use App\Models\ScenarioText;
use App\Models\ScenarioTable;
use Illuminate\Http\Request;

class ScenarioTabController extends Controller
{
    // Helper function to check if user can access project
    private function canAccessProject($user, $project)
    {
        return $user->hasRole('admin') 
            || $project->user_id === $user->id
            || $project->assignedUsers->contains($user->id);
    }

    public function updateText(Request $request, $projectId, $unitId, $scenarioId)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($scenarioId);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'content' => 'nullable|string',
        ]);

        $text = ScenarioText::updateOrCreate(
            ['scenario_id' => $scenarioId],
            ['content' => $request->content]
        );

        return response()->json([
            'success' => true,
            'data' => $text,
            'message' => 'Text updated successfully'
        ]);
    }

    public function updateTable(Request $request, $projectId, $unitId, $scenarioId)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($scenarioId);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'table_data' => 'required|array',
            'table_data.headers' => 'required|array',
            'table_data.rows' => 'required|array',
        ]);

        $table = ScenarioTable::updateOrCreate(
            ['scenario_id' => $scenarioId],
            ['table_data' => $request->table_data]
        );

        return response()->json([
            'success' => true,
            'data' => $table,
            'message' => 'Table updated successfully'
        ]);
    }
}
