# GitHub Setup Script
# Ye script aapko GitHub pe code push karne mein help karega

Write-Host "📦 GitHub Setup Script" -ForegroundColor Cyan
Write-Host "=====================" -ForegroundColor Cyan
Write-Host ""

# Check if git is installed
$gitCheck = Get-Command git -ErrorAction SilentlyContinue
if (-not $gitCheck) {
    Write-Host "❌ Error: Git not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install Git first:" -ForegroundColor Yellow
    Write-Host "1. Download: https://git-scm.com/download/win" -ForegroundColor White
    Write-Host "2. Install Git" -ForegroundColor White
    Write-Host "3. Run this script again" -ForegroundColor White
    exit 1
}

Write-Host "✅ Git found!" -ForegroundColor Green
Write-Host ""

# Check if already a git repo
$isGitRepo = Test-Path ".git"
if ($isGitRepo) {
    Write-Host "ℹ️  Already a git repository!" -ForegroundColor Yellow
    Write-Host ""
    $continue = Read-Host "Continue with setup? (y/n)"
    if ($continue -ne "y") {
        exit 0
    }
} else {
    Write-Host "📝 Initializing git repository..." -ForegroundColor Yellow
    git init
    Write-Host "✅ Git repository initialized!" -ForegroundColor Green
    Write-Host ""
}

# Check if .gitignore exists
if (-not (Test-Path ".gitignore")) {
    Write-Host "📝 Creating .gitignore..." -ForegroundColor Yellow
    $gitignoreContent = @"
# Laravel
backend/.env
backend/vendor/
backend/storage/*.key
backend/bootstrap/cache/*
backend/storage/framework/cache/*
backend/storage/framework/sessions/*
backend/storage/framework/views/*
backend/storage/logs/*

# Flutter
frontend/.dart_tool/
frontend/.flutter-plugins
frontend/.flutter-plugins-dependencies
frontend/.packages
frontend/.pub-cache/
frontend/.pub/
frontend/build/
frontend/.flutter/
frontend/.idea/
frontend/*.iml
frontend/.metadata
frontend/.fvm/

# OS
.DS_Store
Thumbs.db
*.log

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
"@
    Set-Content -Path ".gitignore" -Value $gitignoreContent
    Write-Host "✅ .gitignore created!" -ForegroundColor Green
    Write-Host ""
}

# Check if remote exists
$remoteCheck = git remote -v 2>&1
if ($remoteCheck -match "origin") {
    Write-Host "ℹ️  Remote 'origin' already exists!" -ForegroundColor Yellow
    Write-Host "Current remote:" -ForegroundColor White
    git remote -v
    Write-Host ""
    $changeRemote = Read-Host "Change remote URL? (y/n)"
    if ($changeRemote -eq "y") {
        $newUrl = Read-Host "Enter new GitHub repository URL (e.g., https://github.com/username/repo.git)"
        git remote set-url origin $newUrl
        Write-Host "✅ Remote URL updated!" -ForegroundColor Green
    }
} else {
    Write-Host "📝 No remote repository found." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "To add GitHub remote:" -ForegroundColor Cyan
    Write-Host "1. Create a new repository on GitHub" -ForegroundColor White
    Write-Host "2. Copy the repository URL" -ForegroundColor White
    Write-Host "3. Run: git remote add origin YOUR_REPO_URL" -ForegroundColor White
    Write-Host ""
    $addRemote = Read-Host "Add remote now? (y/n)"
    if ($addRemote -eq "y") {
        $repoUrl = Read-Host "Enter GitHub repository URL (e.g., https://github.com/username/repo.git)"
        git remote add origin $repoUrl
        Write-Host "✅ Remote added!" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "📋 Next Steps:" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Add files:" -ForegroundColor Yellow
Write-Host "   git add ." -ForegroundColor White
Write-Host ""
Write-Host "2. Commit:" -ForegroundColor Yellow
Write-Host "   git commit -m 'Initial commit'" -ForegroundColor White
Write-Host ""
Write-Host "3. Push to GitHub:" -ForegroundColor Yellow
Write-Host "   git push -u origin main" -ForegroundColor White
Write-Host ""
Write-Host "4. Deploy on Railway/Render:" -ForegroundColor Yellow
Write-Host "   - Connect GitHub repo" -ForegroundColor White
Write-Host "   - Automatic deployment!" -ForegroundColor White
Write-Host ""

$doCommit = Read-Host "Add, commit, and push now? (y/n)"
if ($doCommit -eq "y") {
    Write-Host ""
    Write-Host "📦 Adding files..." -ForegroundColor Yellow
    git add .
    
    Write-Host ""
    Write-Host "💾 Committing..." -ForegroundColor Yellow
    $commitMsg = Read-Host "Enter commit message (or press Enter for default)"
    if ([string]::IsNullOrWhiteSpace($commitMsg)) {
        $commitMsg = "Initial commit"
    }
    git commit -m $commitMsg
    
    Write-Host ""
    Write-Host "🚀 Pushing to GitHub..." -ForegroundColor Yellow
    $branch = git branch --show-current
    if ($branch -eq "main" -or $branch -eq "master") {
        git push -u origin $branch
    } else {
        Write-Host "⚠️  Current branch: $branch" -ForegroundColor Yellow
        Write-Host "Switching to 'main' branch..." -ForegroundColor Yellow
        git checkout -b main
        git push -u origin main
    }
    
    Write-Host ""
    Write-Host "✅ Code pushed to GitHub!" -ForegroundColor Green
    Write-Host ""
    Write-Host "🎯 Next: Deploy on Railway or Render:" -ForegroundColor Cyan
    Write-Host "1. Railway: https://railway.app → New Project → Deploy from GitHub" -ForegroundColor White
    Write-Host "2. Render: https://render.com → New Web Service → Connect GitHub" -ForegroundColor White
}

Write-Host ""
Write-Host "✅ Setup complete!" -ForegroundColor Green
