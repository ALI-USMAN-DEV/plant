# Interactive Plant Layout & Risk Assessment Viewer

A complete full-stack application for viewing and managing plant layouts with risk assessment capabilities.

## Tech Stack
- **Frontend**: Flutter (Dart)
- **Backend**: Laravel (PHP)
- **Database**: MySQL
- **Authentication**: Laravel Sanctum
- **Maps**: Leaflet (OpenStreetMap) - No API key required!

## Project Structure

```
apk/
├── backend/          # Laravel API
├── frontend/         # Flutter application
└── docs/            # Documentation
```

## Quick Start

### Backend Setup
```bash
cd backend
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan serve
```

### Frontend Setup
```bash
cd frontend
flutter pub get
flutter run
```

## Features
- Multi-layer map system with Leaflet (OpenStreetMap)
- Scenario management with tabs
- Risk zone visualization
- Equipment placement
- Escape route planning
- PDF report generation
