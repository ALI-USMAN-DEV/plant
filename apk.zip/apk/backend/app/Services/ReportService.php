<?php

namespace App\Services;

use App\Models\Unit;
use App\Models\Report;
use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Support\Facades\Storage;

class ReportService
{
    public function generateReport(Unit $unit, $userId): Report
    {
        $scenarios = $unit->scenarios()->with([
            'tabs',
            'mapLayers.layoutLayers',
            'mapLayers.equipmentItems',
            'mapLayers.escapeRoutes',
            'mapLayers.riskZones',
            'text',
            'table',
            'documents'
        ])->get();

        $html = $this->generateHtml($unit, $scenarios);

        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isRemoteEnabled', true);

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $pdfContent = $dompdf->output();
        $fileName = 'report_' . $unit->id . '_' . time() . '.pdf';
        $filePath = 'reports/' . $fileName;

        Storage::disk('public')->put($filePath, $pdfContent);

        $report = Report::create([
            'unit_id' => $unit->id,
            'user_id' => $userId,
            'file_path' => $filePath,
            'file_name' => $fileName,
            'file_size' => strlen($pdfContent),
            'generated_at' => now(),
        ]);

        return $report;
    }

    private function generateHtml(Unit $unit, $scenarios): string
    {
        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Risk Assessment Report - ' . htmlspecialchars($unit->name) . '</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }
        h2 { color: #666; margin-top: 30px; }
        h3 { color: #888; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .scenario { margin: 30px 0; padding: 20px; border: 1px solid #ddd; }
        .section { margin: 15px 0; }
    </style>
</head>
<body>
    <h1>Risk Assessment Report</h1>
    <h2>Unit: ' . htmlspecialchars($unit->name) . '</h2>
    <p><strong>Project:</strong> ' . htmlspecialchars($unit->project->name) . '</p>
    <p><strong>Generated:</strong> ' . now()->format('Y-m-d H:i:s') . '</p>
    <hr>';

        foreach ($scenarios as $scenario) {
            $html .= '<div class="scenario">';
            $html .= '<h2>Scenario: ' . htmlspecialchars($scenario->name) . '</h2>';

            if ($scenario->description) {
                $html .= '<p>' . htmlspecialchars($scenario->description) . '</p>';
            }

            // Text Content
            if ($scenario->text && $scenario->text->content) {
                $html .= '<div class="section"><h3>Text Content</h3>';
                $html .= '<div>' . $scenario->text->content . '</div></div>';
            }

            // Table Content
            if ($scenario->table && $scenario->table->table_data) {
                $tableData = $scenario->table->table_data;
                $html .= '<div class="section"><h3>Table Data</h3>';
                $html .= '<table>';
                if (isset($tableData['headers'])) {
                    $html .= '<thead><tr>';
                    foreach ($tableData['headers'] as $header) {
                        $html .= '<th>' . htmlspecialchars($header) . '</th>';
                    }
                    $html .= '</tr></thead>';
                }
                if (isset($tableData['rows'])) {
                    $html .= '<tbody>';
                    foreach ($tableData['rows'] as $row) {
                        $html .= '<tr>';
                        foreach ($row as $cell) {
                            $html .= '<td>' . htmlspecialchars($cell) . '</td>';
                        }
                        $html .= '</tr>';
                    }
                    $html .= '</tbody>';
                }
                $html .= '</table></div>';
            }

            // Map Layers Summary
            $html .= '<div class="section"><h3>Map Layers Summary</h3>';
            $html .= '<ul>';
            foreach ($scenario->mapLayers as $layer) {
                $html .= '<li><strong>' . htmlspecialchars($layer->name) . '</strong> (' . $layer->layer_type . ')';
                if ($layer->layer_type === 'layout') {
                    $html .= ' - ' . $layer->layoutLayers->count() . ' layout(s)';
                } elseif ($layer->layer_type === 'equipment') {
                    $html .= ' - ' . $layer->equipmentItems->count() . ' equipment item(s)';
                } elseif ($layer->layer_type === 'escape_route') {
                    $html .= ' - ' . $layer->escapeRoutes->count() . ' route(s)';
                } elseif ($layer->layer_type === 'risk_zone') {
                    $html .= ' - ' . $layer->riskZones->count() . ' zone(s)';
                }
                $html .= '</li>';
            }
            $html .= '</ul></div>';

            // Documents
            if ($scenario->documents->count() > 0) {
                $html .= '<div class="section"><h3>Documents</h3><ul>';
                foreach ($scenario->documents as $doc) {
                    $html .= '<li>' . htmlspecialchars($doc->file_name) . ' (' . $doc->file_type . ')</li>';
                }
                $html .= '</ul></div>';
            }

            $html .= '</div>';
        }

        $html .= '</body></html>';

        return $html;
    }
}
