<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\ScenarioController;
use App\Http\Controllers\MapLayerController;
use App\Http\Controllers\ScenarioTabController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\ReportController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Public routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {
    // Auth routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    // Projects
    Route::apiResource('projects', ProjectController::class);
    Route::post('/projects/{id}/assign-users', [ProjectController::class, 'assignUsers']);
    Route::get('/projects/users-for-assignment', [ProjectController::class, 'getUsersForAssignment']);

    // Units (nested under projects)
    Route::prefix('projects/{projectId}')->group(function () {
        Route::apiResource('units', UnitController::class);

        // Scenarios (nested under units)
        Route::prefix('units/{unitId}')->group(function () {
            Route::apiResource('scenarios', ScenarioController::class);

            // Scenario tabs and content
            Route::prefix('scenarios/{scenarioId}')->group(function () {
                // Text tab
                Route::put('/text', [ScenarioTabController::class, 'updateText']);

                // Table tab
                Route::put('/table', [ScenarioTabController::class, 'updateTable']);

                // Documents
                Route::apiResource('documents', DocumentController::class)->only(['store', 'destroy']);

                // Map layers
                Route::prefix('map-layers')->group(function () {
                    // Layout layers
                    Route::post('/layouts', [MapLayerController::class, 'storeLayoutLayer']);
                    Route::put('/layouts/{id}', [MapLayerController::class, 'updateLayoutLayer']);
                    Route::delete('/layouts/{id}', [MapLayerController::class, 'deleteLayoutLayer']);

                    // Equipment items
                    Route::post('/equipment', [MapLayerController::class, 'storeEquipmentItem']);
                    Route::put('/equipment/{id}', [MapLayerController::class, 'updateEquipmentItem']);
                    Route::delete('/equipment/{id}', [MapLayerController::class, 'deleteEquipmentItem']);

                    // Escape routes
                    Route::post('/escape-routes', [MapLayerController::class, 'storeEscapeRoute']);
                    Route::put('/escape-routes/{id}', [MapLayerController::class, 'updateEscapeRoute']);
                    Route::delete('/escape-routes/{id}', [MapLayerController::class, 'deleteEscapeRoute']);

                    // Risk zones
                    Route::post('/risk-zones', [MapLayerController::class, 'storeRiskZone']);
                    Route::put('/risk-zones/{id}', [MapLayerController::class, 'updateRiskZone']);
                    Route::delete('/risk-zones/{id}', [MapLayerController::class, 'deleteRiskZone']);

                    // Toggle layer visibility
                    Route::put('/{layerId}/toggle', [MapLayerController::class, 'toggleLayer']);
                    // Update layer properties
                    Route::put('/{layerId}', [MapLayerController::class, 'updateLayer']);
                });
            });

            // Reports
            Route::post('/reports/generate', [ReportController::class, 'generate']);
            Route::get('/reports', [ReportController::class, 'index']);
            Route::get('/reports/{id}/download', [ReportController::class, 'download']);
        });
    });
});
