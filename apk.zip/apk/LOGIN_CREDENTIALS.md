# Login Credentials 🔐

## Default Login Credentials

### Admin Account (Full Access)
- **Email:** `admin@example.com`
- **Password:** `password`
- **Role:** Administrator

### Regular User Account
- **Email:** `user@example.com`
- **Password:** `password`
- **Role:** User

## 📱 How to Login

1. Open the app on your device
2. Enter email: `admin@example.com`
3. Enter password: `password`
4. Tap "Login"

## ✅ After Login

You'll have access to:
- ✅ All projects
- ✅ Create/Edit/Delete projects
- ✅ Manage units and scenarios
- ✅ All map features
- ✅ Reports generation

## 🔒 Security Note

**Important:** These are default credentials for testing. 

For production:
- Change admin password immediately
- Create new user accounts
- Use strong passwords
- Enable additional security features

## 🆕 Create New User

You can also register a new user:
1. Tap "Register" on login screen
2. Fill in details
3. New user will have "user" role by default

---

**Login karne ke liye:**
- **Email:** `admin@example.com`
- **Password:** `password`
