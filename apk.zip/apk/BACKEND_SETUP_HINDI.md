# Backend Setup Guide - Step by Step (Hindi/Roman English)

## Prerequisites (Pehle Ye Chahiye)

1. **PHP 8.1+** installed
2. **Composer** installed
3. **MySQL** installed aur running
4. **XAMPP/WAMP** (agar Windows use kar rahe ho)

## Step-by-Step Setup

### Step 1: Composer Install (Agar nahi hai)

#### Windows ke liye:
1. https://getcomposer.org/download/ se download karo
2. `Composer-Setup.exe` run karo
3. Install karo
4. Verify: `composer --version`

#### Manual Install:
```bash
# PowerShell mein
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
php composer-setup.php
php -r "unlink('composer-setup.php');"
```

### Step 2: Backend Dependencies Install

```bash
# Terminal/PowerShell mein
cd backend
composer install
```

**Agar composer nahi mila:**
- Composer install karo (Step 1 dekho)
- Ya manually vendor folder create karo

### Step 3: .env File Create Karo

#### Option A: Copy from .env.example
```bash
cd backend
copy .env.example .env
```

#### Option B: Manually Create
`backend/.env` file create karo aur ye add karo:

```env
APP_NAME="Plant Layout API"
APP_ENV=local
APP_KEY=
APP_DEBUG=true
APP_URL=http://localhost:8000

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=plant_layout
DB_USERNAME=root
DB_PASSWORD=your_password_here
```

**Important**: `DB_PASSWORD` mein apna MySQL password dalo!

### Step 4: App Key Generate Karo

```bash
cd backend
php artisan key:generate
```

Ye automatically `.env` file mein `APP_KEY` add kar dega.

### Step 5: Database Create Karo

#### Option A: MySQL Command Line
```bash
mysql -u root -p
```

Phir MySQL mein:
```sql
CREATE DATABASE plant_layout CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;
```

#### Option B: phpMyAdmin
1. http://localhost/phpmyadmin open karo
2. "New" click karo
3. Database name: `plant_layout`
4. Collation: `utf8mb4_unicode_ci`
5. "Create" click karo

### Step 6: Migrations Run Karo

```bash
cd backend
php artisan migrate
```

Ye sab tables create kar dega (16 tables).

### Step 7: Seed Database (Optional but Recommended)

```bash
php artisan db:seed
```

Ye create karega:
- Admin user: `admin@example.com` / `password`
- Regular user: `user@example.com` / `password`
- Sample project with 50 scenarios

### Step 8: Storage Link Create Karo

```bash
php artisan storage:link
```

Ye `storage/app/public` ko `public/storage` se link karega.

### Step 9: Server Start Karo

```bash
php artisan serve
```

Backend ab `http://localhost:8000` par chalega!

## ✅ Verification

### Backend Check Karein

Browser mein open karo: `http://localhost:8000`

Agar ye message dikhe to sahi hai:
```json
{
  "message": "Plant Layout & Risk Assessment API",
  "version": "1.0.0"
}
```

### API Test Karein

Postman ya browser mein:
```
POST http://localhost:8000/api/login
Content-Type: application/json

{
  "email": "admin@example.com",
  "password": "password"
}
```

Agar token mil jaye to sab theek hai!

## 🐛 Common Issues & Solutions

### Issue 1: "composer: command not found"
**Solution:**
- Composer install karo
- Ya `php composer.phar install` use karo

### Issue 2: "PHP not found"
**Solution:**
- PHP install karo
- PATH mein add karo
- Ya XAMPP use karo

### Issue 3: "Database connection refused"
**Solution:**
- MySQL running hai check karo
- `.env` mein credentials sahi hain check karo
- MySQL service start karo

### Issue 4: "Migration failed"
**Solution:**
```bash
# Fresh start
php artisan migrate:fresh
php artisan db:seed
```

### Issue 5: "Storage link failed"
**Solution:**
```bash
# Manually link karo
mklink /D public\storage ..\storage\app\public
```

## 📋 Quick Checklist

- [ ] Composer installed
- [ ] `composer install` run kiya
- [ ] `.env` file created
- [ ] `APP_KEY` generated
- [ ] Database `plant_layout` created
- [ ] Migrations run kiye
- [ ] Database seeded (optional)
- [ ] Storage link created
- [ ] Server started on port 8000

## 🚀 Next Steps

Backend start hone ke baad:

1. **Frontend Configure**: `frontend/lib/core/constants/api_constants.dart` mein API URL set karo
2. **Frontend Run**: `cd frontend && flutter run`
3. **Test**: Login karo aur sab features test karo!

---

**Backend setup complete hone ke baad batao, main frontend setup help karunga!** 🚀
