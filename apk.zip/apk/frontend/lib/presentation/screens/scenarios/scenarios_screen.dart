import 'package:flutter/material.dart';
import 'package:plant_layout_viewer/data/models/project_model.dart';
import 'package:plant_layout_viewer/data/models/unit_model.dart';
import 'package:plant_layout_viewer/data/models/scenario_model.dart';
import 'package:plant_layout_viewer/data/services/api_service.dart';
import 'package:plant_layout_viewer/core/constants/api_constants.dart';
import 'package:plant_layout_viewer/presentation/screens/scenarios/scenario_detail_screen.dart';

class ScenariosScreen extends StatefulWidget {
  final ProjectModel project;
  final UnitModel unit;

  const ScenariosScreen({
    super.key,
    required this.project,
    required this.unit,
  });

  @override
  State<ScenariosScreen> createState() => _ScenariosScreenState();
}

class _ScenariosScreenState extends State<ScenariosScreen> {
  List<ScenarioModel> _scenarios = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadScenarios();
  }

  Future<void> _loadScenarios() async {
    setState(() => _isLoading = true);
    try {
      final response = await ApiService().get(
        ApiConstants.scenarios(widget.project.id, widget.unit.id),
      );
      if (response.statusCode == 200 && response.data['success'] == true) {
        setState(() {
          _scenarios = (response.data['data'] as List)
              .map((json) => ScenarioModel.fromJson(json))
              .toList();
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error loading scenarios: $e')),
        );
      }
    }
  }

  Future<void> _createScenario() async {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create Scenario'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Scenario Name'),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(labelText: 'Description'),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Create'),
          ),
        ],
      ),
    );

    if (result == true && nameController.text.isNotEmpty) {
      try {
        final response = await ApiService().post(
          ApiConstants.scenarios(widget.project.id, widget.unit.id),
          data: {
            'name': nameController.text,
            'description': descriptionController.text.isEmpty ? null : descriptionController.text,
          },
        );

        if (response.statusCode == 201) {
          _loadScenarios();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error creating scenario: $e')),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Scenarios - ${widget.unit.name}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: () {
              // Generate report
              _generateReport();
            },
            tooltip: 'Generate Report',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Scenarios (${_scenarios.length})',
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      ElevatedButton.icon(
                        onPressed: _createScenario,
                        icon: const Icon(Icons.add),
                        label: const Text('New Scenario'),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _scenarios.isEmpty
                      ? const Center(child: Text('No scenarios found. Create one to get started.'))
                      : ListView.builder(
                          itemCount: _scenarios.length,
                          itemBuilder: (context, index) {
                            final scenario = _scenarios[index];
                            return Card(
                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: ListTile(
                                leading: const Icon(Icons.map, size: 40),
                                title: Text(scenario.name),
                                subtitle: scenario.description != null
                                    ? Text(scenario.description!)
                                    : null,
                                trailing: const Icon(Icons.chevron_right),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => ScenarioDetailScreen(
                                        project: widget.project,
                                        unit: widget.unit,
                                        scenario: scenario,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }

  Future<void> _generateReport() async {
    try {
      final response = await ApiService().post(
        ApiConstants.generateReport(widget.project.id, widget.unit.id),
      );

      if (response.statusCode == 201 && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Report generated successfully!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error generating report: $e')),
        );
      }
    }
  }
}
