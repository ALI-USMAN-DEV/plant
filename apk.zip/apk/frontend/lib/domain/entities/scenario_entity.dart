class ScenarioEntity {
  final int id;
  final String name;
  final String? description;
  final int? unitId;
  final double? mapCenterLat;
  final double? mapCenterLng;
  final double mapZoom;

  ScenarioEntity({
    required this.id,
    required this.name,
    this.description,
    this.unitId,
    this.mapCenterLat,
    this.mapCenterLng,
    this.mapZoom = 15.0,
  });
}
