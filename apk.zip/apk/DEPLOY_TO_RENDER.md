# Render.com Deployment Guide - Step by Step 🚀

## Prerequisites
- GitHub account
- Backend code GitHub pe push ho chuka hai
- Render.com account (free)

---

## Step 1: Render Account Setup

1. https://render.com pe jao
2. **"Get Started for Free"** click karo
3. **"Sign up with GitHub"** select karo (recommended)
4. GitHub se authorize karo

---

## Step 2: Database Create Karo

### Option A: PostgreSQL (Free)
1. Render dashboard mein **"New +"** click karo
2. **"PostgreSQL"** select karo
3. Settings:
   - **Name:** `plant-layout-db`
   - **Database:** `plant_layout_db`
   - **User:** `plant_user` (auto-generated)
   - **Region:** Choose closest
   - **Plan:** Free
4. **"Create Database"** click karo
5. Wait karo (2-3 minutes)
6. Database ready hone ke baad, **"Connect"** tab mein connection string copy karo

### Option B: MySQL (Paid - ya PlanetScale use karo)
Agar MySQL chahiye to PlanetScale (free) use karo:
1. https://planetscale.com pe account banao
2. New database create karo
3. Connection string copy karo

---

## Step 3: Backend Deploy Karo

1. Render dashboard mein **"New +"** → **"Web Service"**
2. **"Connect GitHub"** click karo (pehli baar)
3. Repository select karo
4. Settings configure karo:

### Basic Settings:
- **Name:** `plant-layout-api`
- **Region:** Same as database
- **Branch:** `main` (ya `master`)
- **Root Directory:** `backend`
- **Environment:** `PHP`
- **Build Command:**
  ```bash
  composer install --no-dev --optimize-autoloader && php artisan key:generate --force && php artisan migrate --force && php artisan db:seed --force
  ```
- **Start Command:**
  ```bash
  php artisan serve --host=0.0.0.0 --port=$PORT
  ```

### Environment Variables:
**"Environment"** tab mein ye variables add karo:

```
APP_NAME=Plant Layout API
APP_ENV=production
APP_DEBUG=false
APP_URL=https://your-app-name.onrender.com

# Database (PostgreSQL example)
DB_CONNECTION=pgsql
DB_HOST=YOUR_DB_HOST
DB_PORT=5432
DB_DATABASE=plant_layout_db
DB_USERNAME=YOUR_DB_USER
DB_PASSWORD=YOUR_DB_PASSWORD

# Laravel
APP_KEY=base64:YOUR_KEY_HERE
# (Pehle build command se generate hoga, ya manually add karo)

# CORS
CORS_ALLOWED_ORIGINS=*
```

**Important:** Database variables ko Render database se automatically mil sakte hain:
- Database service pe jao
- **"Connect"** tab mein **"Internal Database URL"** copy karo
- Ya individual variables copy karo

5. **"Create Web Service"** click karo
6. Deploy start ho jayega (5-10 minutes)

---

## Step 4: Deploy Status Check Karo

1. **"Events"** tab mein logs dekh sakte ho
2. **"Logs"** tab mein real-time logs
3. Deploy complete hone ka wait karo
4. Status **"Live"** ho jana chahiye

---

## Step 5: URL Copy Karo

1. Deploy complete hone ke baad
2. Top pe **URL** dikhega: `https://your-app-name.onrender.com`
3. Ye URL copy karo
4. API URL hoga: `https://your-app-name.onrender.com/api`

---

## Step 6: Test Karo

Browser mein test karo:
```
https://your-app-name.onrender.com/api
```

Response aana chahiye (JSON format mein).

---

## Step 7: API URL Update Karo

### Method 1: Script Use Karo
```powershell
.\UPDATE_API_URL.ps1 -Url "https://your-app-name.onrender.com/api"
```

### Method 2: Manual
1. `frontend/lib/core/constants/api_constants.dart` open karo
2. Line 15 update karo:
   ```dart
   static const String baseUrl = 'https://your-app-name.onrender.com/api';
   ```

---

## Step 8: APK Rebuild Karo

```powershell
.\REBUILD_APK.ps1
```

Ya manually:
```powershell
cd frontend
flutter clean
flutter pub get
flutter build apk --release
```

---

## Step 9: APK Test Karo

1. APK install karo device pe
2. Login try karo
3. Features test karo
4. Sab kuch kaam karna chahiye! ✅

---

## 🎉 Done!

Ab aapka APK kahin se bhi chalega! 

---

## ⚠️ Important Notes

1. **Free Tier Sleep:**
   - Agar 15 minutes inactive ho to service sleep ho jayega
   - Pehli request slow ho sakti hai (wake up time)
   - Solution: Paid plan ya cron job se keep-alive

2. **Database:**
   - PostgreSQL free tier available hai
   - MySQL ke liye PlanetScale (free) use karo

3. **Environment Variables:**
   - Sensitive data ko environment variables mein rakho
   - `.env` file mat commit karo GitHub pe

4. **CORS:**
   - Mobile app ke liye CORS allow karna zaroori hai
   - Production mein specific origins allow karo

---

## 🆘 Troubleshooting

### Build Fail
- Check build logs
- Composer dependencies sahi hain?
- PHP version compatible hai?

### Database Connection Error
- Database variables sahi hain?
- Database service running hai?
- Internal URL use kar rahe ho?

### 500 Error
- Check application logs
- `APP_DEBUG=true` temporarily karo (debugging ke liye)
- Database migrations run huye hain?

---

**Happy Deploying! 🚀**
