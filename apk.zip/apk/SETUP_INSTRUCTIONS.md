# Backend Setup - Complete Instructions

## 🎯 Current Status

✅ **Completed:**
- `.env` file structure ready
- Setup scripts created
- Documentation complete

⏳ **Required:**
- XAMPP installation (PHP + MySQL)
- Composer installation
- Database creation

## 📥 Step 1: Install XAMPP (5 minutes)

### Download
1. Go to: https://www.apachefriends.org/
2. Click "Download" (Windows)
3. Download latest version

### Install
1. Run downloaded `.exe` file
2. Click through installer
3. Install to `C:\xampp` (default)

### Start Services
1. Open XAMPP Control Panel
2. Click "Start" for **Apache**
3. Click "Start" for **MySQL**

### Verify
- Open browser: http://localhost/phpmyadmin
- Should see phpMyAdmin interface

## 📦 Step 2: Install Composer (3 minutes)

### Download
1. Go to: https://getcomposer.org/download/
2. Download `Composer-Setup.exe`

### Install
1. Run `Composer-Setup.exe`
2. **Important:** When asked for PHP, select: `C:\xampp\php\php.exe`
3. Complete installation

### Verify
Open new terminal/PowerShell:
```bash
composer --version
```
Should show Composer version

## 🚀 Step 3: Run Setup Script

### Option A: Automated Script (Recommended)
```powershell
cd C:\Users\ah516\Desktop\apk\backend
.\SETUP_BACKEND.ps1
```

### Option B: Manual Commands
```bash
cd backend

# Install dependencies
composer install

# Generate app key
php artisan key:generate

# Create database in phpMyAdmin:
# 1. Open: http://localhost/phpmyadmin
# 2. Click "New"
# 3. Database name: plant_layout
# 4. Collation: utf8mb4_unicode_ci
# 5. Click "Create"

# Run migrations
php artisan migrate

# Seed database (optional)
php artisan db:seed

# Create storage link
php artisan storage:link

# Start server
php artisan serve
```

## ✅ Verification

### Check Backend
Open browser: `http://localhost:8000`

Should see API response or Laravel welcome page.

### Test API
```bash
# Login test
POST http://localhost:8000/api/login
Content-Type: application/json

{
  "email": "admin@example.com",
  "password": "password"
}
```

## 🐛 Troubleshooting

### XAMPP Apache Won't Start
- Port 80 already in use
- Solution: Change port to 8080 in XAMPP config

### MySQL Won't Start
- Port 3306 already in use
- Solution: Stop other MySQL service or change port

### Composer Not Found
- Add Composer to PATH
- Or reinstall Composer

### Database Connection Failed
- Check MySQL is running
- Check `.env` file credentials
- Verify database `plant_layout` exists

## 📋 Final Checklist

- [ ] XAMPP installed and running
- [ ] Apache started
- [ ] MySQL started
- [ ] Composer installed
- [ ] `composer install` completed
- [ ] `.env` file created
- [ ] `php artisan key:generate` done
- [ ] Database `plant_layout` created
- [ ] `php artisan migrate` done
- [ ] `php artisan db:seed` done (optional)
- [ ] `php artisan storage:link` done
- [ ] `php artisan serve` running
- [ ] Backend accessible at http://localhost:8000

## 🎯 Next Steps

After backend is running:

1. **Frontend Configure:**
   - Edit `frontend/lib/core/constants/api_constants.dart`
   - Set: `http://10.0.2.2:8000/api` (emulator)
   - Or: `http://YOUR_IP:8000/api` (device)

2. **Frontend Run:**
   ```bash
   cd frontend
   flutter run
   ```

3. **Test:**
   - Login: `admin@example.com` / `password`
   - Test all features!

---

**Follow these steps and backend will be ready!** 🚀
