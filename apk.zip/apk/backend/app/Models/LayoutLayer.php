<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LayoutLayer extends Model
{
    protected $fillable = [
        'map_layer_id',
        'file_path',
        'file_name',
        'position_lat',
        'position_lng',
        'scale_x',
        'scale_y',
        'rotation',
        'width',
        'height',
        'is_visible',
    ];

    protected $casts = [
        'position_lat' => 'decimal:8',
        'position_lng' => 'decimal:8',
        'scale_x' => 'decimal:2',
        'scale_y' => 'decimal:2',
        'rotation' => 'decimal:2',
        'is_visible' => 'boolean',
    ];

    public function mapLayer(): BelongsTo
    {
        return $this->belongsTo(MapLayer::class);
    }
}
