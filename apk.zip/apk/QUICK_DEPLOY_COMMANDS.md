# Quick Deploy Commands - Copy Paste Ready 📋

## Part 1: GitHub Setup

### Git Initialize
```powershell
cd c:\Users\ah516\Desktop\apk
git init
git add .
git commit -m "Initial commit - Plant Layout Viewer project"
```

### GitHub Repository Create
1. https://github.com pe jao
2. "New repository" click karo
3. Repository name: `plant-layout-viewer`
4. "Create repository" click karo

### Connect & Push
```powershell
git remote add origin https://github.com/YOUR_USERNAME/plant-layout-viewer.git
git branch -M main
git push -u origin main
```

**Note:** Agar password error aaye to Personal Access Token use karo.

---

## Part 2: Railway Deploy

### Railway Setup
1. https://railway.app pe jao
2. "Sign up with GitHub" karo
3. "New Project" → "Deploy from GitHub repo"
4. Aapka repository select karo

### Service Configuration

**Settings Tab:**
- **Root Directory:** `backend`

**Deploy Tab:**
- **Build Command:**
  ```bash
  cd backend && composer install --no-dev --optimize-autoloader
  ```
- **Start Command:**
  ```bash
  php artisan key:generate --force && php artisan migrate --force && php artisan db:seed --force && php artisan serve --host=0.0.0.0 --port=$PORT
  ```

### Database Add
1. "New" → "Database" → "Add MySQL"
2. Database automatically create ho jayega

### Environment Variables
**Variables Tab mein add karo:**
```
APP_NAME=Plant Layout API
APP_ENV=production
APP_DEBUG=false
APP_URL=https://your-app.railway.app
DB_CONNECTION=mysql
DB_HOST=YOUR_DB_HOST
DB_PORT=3306
DB_DATABASE=YOUR_DB_NAME
DB_USERNAME=YOUR_DB_USER
DB_PASSWORD=YOUR_DB_PASSWORD
CORS_ALLOWED_ORIGINS=*
```

**Note:** Database variables Database service se copy karo.

---

## Part 3: API URL Update

### Method 1: Script
```powershell
.\UPDATE_API_URL.ps1 -Url "https://your-app.railway.app/api"
```

### Method 2: Manual
**File:** `frontend/lib/core/constants/api_constants.dart`
**Line 15:**
```dart
static const String baseUrl = 'https://your-app.railway.app/api';
```

### Push to GitHub
```powershell
git add frontend/lib/core/constants/api_constants.dart
git commit -m "Update API URL to Railway"
git push
```

---

## Part 4: APK Rebuild

```powershell
cd frontend
flutter clean
flutter pub get
flutter build apk --release
```

**Ya script:**
```powershell
.\REBUILD_APK.ps1
```

**APK Location:**
```
frontend\build\app\outputs\flutter-apk\app-release.apk
```

---

## ✅ Quick Checklist

- [ ] Git installed
- [ ] GitHub repository created
- [ ] Code pushed to GitHub
- [ ] Railway account created
- [ ] Repository connected
- [ ] Root directory set (`backend`)
- [ ] Build/Start commands set
- [ ] Database created
- [ ] Environment variables set
- [ ] Deploy successful
- [ ] URL received
- [ ] API URL updated
- [ ] APK rebuilt

---

**Detailed Guide:** `GITHUB_RAILWAY_DEPLOY_STEPS.md` padho
