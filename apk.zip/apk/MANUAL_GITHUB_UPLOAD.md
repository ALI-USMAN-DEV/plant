# GitHub Pe Manual Upload - Git Bash Ke Bina 🚀

## ✅ Git Bash Ki Zaroorat Nahi!

Aap **directly browser se** files upload kar sakte hain - Git bash ki zaroorat nahi!

---

## 📋 Step-by-Step Guide

### Step 1: GitHub Pe Account Banao (Agar Nahi Hai)

1. **https://github.com** pe jao
2. **"Sign up" click karo**
3. **Email, password, username** enter karo
4. **Account verify karo** (email check karo)

### Step 2: New Repository Banao

1. **GitHub pe login karo**
2. **Top right corner mein "+" icon click karo**
3. **"New repository" select karo**

### Step 3: Repository Settings

**Form fill karo:**
- **Repository name:** `plant-layout-viewer` (ya koi bhi naam)
- **Description:** (Optional) "Plant Layout and Risk Assessment Viewer"
- **Public ya Private:** 
  - ✅ **Public** = Sab dekh sakte hain (free, recommended)
  - 🔒 **Private** = Sirf aap dekh sakte ho (paid plan chahiye)
- **❌ "Initialize with README" mat check karo**
- **❌ "Add .gitignore" mat select karo**
- **❌ "Choose a license" mat select karo**

4. **"Create repository" button click karo**

### Step 4: Repository Page Pe Jao

**Repository create hone ke baad, aapko empty repository page dikhega:**
- Message dikhega: "Quick setup — if you've done this kind of thing before"
- **"uploading an existing file" link click karo**

**Ya:**
- **"Add file" button click karo** (top right)
- **"Upload files" select karo**

### Step 5: Files Select Karo

**Important: Pehle yeh files/folders EXCLUDE karo (mat upload karo):**

❌ **Mat Upload Karo:**
- `backend/.env` (sensitive data)
- `backend/vendor/` folder (bahut bada hai, composer install se mil jayega)
- `backend/storage/logs/` (log files)
- `frontend/build/` folder (build files)
- `frontend/.dart_tool/` folder (temporary files)
- `frontend/.flutter/` folder
- `.idea/` folder (IDE settings)
- `.vscode/` folder (IDE settings)
- `*.log` files (log files)

✅ **Upload Karna Hai:**
- `backend/` folder (except excluded files)
- `frontend/` folder (except excluded files)
- Root files (`.gitignore`, `README.md`, documentation files)

### Step 6: Files Upload Karo

**Method A: Drag & Drop (Easiest)**

1. **Windows Explorer mein project folder open karo:**
   ```
   c:\Users\ah516\Desktop\apk
   ```

2. **Folders select karo:**
   - `backend` folder (right-click → Copy)
   - `frontend` folder (right-click → Copy)
   - Root files (`.gitignore`, etc.)

3. **GitHub upload page pe:**
   - **Drag & drop area mein folders drop karo**
   - Ya **"choose your files" click karo** aur manually select karo

**Method B: Manual Selection**

1. **"choose your files" button click karo**
2. **File Explorer open hoga**
3. **Folders select karo:**
   - `backend` folder
   - `frontend` folder
   - Root files
4. **"Open" click karo**

### Step 7: Files Upload Wait Karo

**Upload progress dikhega:**
- Files upload ho rahi hain
- Large files ke liye time lagega
- **Wait karo** - page refresh mat karo!

### Step 8: Commit Changes

**Upload complete hone ke baad:**

1. **Bottom pe "Commit changes" section dikhega**

2. **Commit message dalo:**
   ```
   Initial commit - Plant Layout Viewer project
   ```

3. **"Commit changes" button click karo**

**✅ Files upload ho gayi!**

---

## 📁 Kya Upload Karna Hai - Detailed List

### ✅ Backend Folder (Upload Karna Hai)

**Upload karo:**
- ✅ `backend/app/` folder
- ✅ `backend/bootstrap/` folder
- ✅ `backend/config/` folder
- ✅ `backend/database/` folder
- ✅ `backend/public/` folder
- ✅ `backend/resources/` folder
- ✅ `backend/routes/` folder
- ✅ `backend/storage/` folder (except logs)
- ✅ `backend/.htaccess` file
- ✅ `backend/artisan` file
- ✅ `backend/composer.json` file
- ✅ `backend/composer.lock` file
- ✅ `backend/phpunit.xml` file

**Mat upload karo:**
- ❌ `backend/.env` file
- ❌ `backend/vendor/` folder
- ❌ `backend/storage/logs/` folder
- ❌ `backend/storage/framework/cache/` folder
- ❌ `backend/storage/framework/sessions/` folder

### ✅ Frontend Folder (Upload Karna Hai)

**Upload karo:**
- ✅ `frontend/lib/` folder (sab code)
- ✅ `frontend/android/` folder
- ✅ `frontend/ios/` folder (agar hai)
- ✅ `frontend/web/` folder (agar hai)
- ✅ `frontend/pubspec.yaml` file
- ✅ `frontend/pubspec.lock` file
- ✅ `frontend/README.md` file (agar hai)

**Mat upload karo:**
- ❌ `frontend/build/` folder
- ❌ `frontend/.dart_tool/` folder
- ❌ `frontend/.flutter/` folder
- ❌ `frontend/.idea/` folder
- ❌ `frontend/.vscode/` folder

### ✅ Root Files (Upload Karna Hai)

**Upload karo:**
- ✅ `.gitignore` file (agar hai)
- ✅ `README.md` file (agar hai)
- ✅ Documentation files (`.md` files)

---

## 🎯 Easy Method: Folder Structure

**Agar confusion ho to:**

1. **Pehle `backend` folder upload karo** (excluded files ke bina)
2. **Phir `frontend` folder upload karo** (excluded files ke bina)
3. **Phir root files upload karo**

**Ya:**
- **Sab folders ek saath select karo** aur upload karo
- GitHub automatically structure maintain karega

---

## ⚠️ Important Notes

### File Size Limit
- **GitHub 100MB per file limit hai**
- Agar koi file 100MB se badi hai, to exclude karo
- `vendor/` folder usually bahut bada hota hai (isliye exclude karo)

### Upload Time
- **Large projects ke liye time lagega**
- Internet speed ke according 5-30 minutes lag sakte hain
- **Page refresh mat karo** upload ke dauran!

### Multiple Uploads
- **Agar ek baar mein sab nahi ho raha:**
  - Pehle `backend` folder upload karo
  - Phir `frontend` folder upload karo
  - Har upload ke baad "Commit changes" karo

---

## 🔍 Verify Karo

**Upload complete hone ke baad:**

1. **Repository page refresh karo**
2. **Check karo:**
   - ✅ `backend/` folder dikh raha hai?
   - ✅ `frontend/` folder dikh raha hai?
   - ✅ Files properly organized hain?

3. **Folder click karo:**
   - Files properly dikh rahi hain?
   - Code readable hai?

---

## 🆘 Common Issues & Solutions

### Issue: Upload Slow Hai

**Solution:**
- Internet connection check karo
- Large files exclude karo (`vendor/`, `build/`)
- Patience rakho - time lagega

### Issue: Upload Fail Ho Raha Hai

**Solution:**
- File size check karo (100MB limit)
- Internet connection stable hai?
- Browser refresh karo aur phir try karo
- Small batches mein upload karo

### Issue: Files Missing Hai

**Solution:**
- Excluded files check karo (`.env`, `vendor/`, etc.)
- Agar zaroori files missing hain, to manually add karo
- "Add file" → "Create new file" se add kar sakte ho

### Issue: Folder Structure Galat Hai

**Solution:**
- GitHub automatically structure maintain karta hai
- Agar issue hai, to manually organize karo
- "Add file" se folders create kar sakte ho

---

## ✅ After Upload - Next Steps

**Upload complete hone ke baad:**

1. **Railway pe deploy karo:**
   - `GITHUB_RAILWAY_DEPLOY_STEPS.md` follow karo
   - Railway GitHub se directly connect kar lega

2. **API URL update karo:**
   - Railway URL milne ke baad
   - `frontend/lib/core/constants/api_constants.dart` update karo

3. **APK rebuild karo:**
   - Updated API URL ke saath
   - `REBUILD_APK.ps1` run karo

---

## 📝 Quick Summary

1. ✅ GitHub pe repository banao
2. ✅ "Upload files" click karo
3. ✅ `backend` aur `frontend` folders select karo (excluded files ke bina)
4. ✅ Upload wait karo
5. ✅ "Commit changes" click karo
6. ✅ Done! 🎉

---

**Git bash ki zaroorat nahi - sab browser se ho jayega!** 🚀
