class ApiConstants {
  // Base URL - Change this to your server IP for Android device
  // For emulator: http://10.0.2.2:8000/api
  // For physical device: http://YOUR_COMPUTER_IP:8000/api
  // For localhost (web): http://localhost:8000/api
  // 
  // IMPORTANT: Use your computer's IP address for physical device!
  // Find IP: ipconfig (Windows) or ifconfig (Mac/Linux)
  // Example: http://192.168.1.100:8000/api
  // Your IP: 192.168.100.15 (update this!)
  // PUBLIC URL - Update this with your ngrok URL or cloud hosting URL
  // Format: https://your-domain.com/api
  // Example ngrok: https://abc123.ngrok-free.app/api
  // Example cloud: https://your-app.onrender.com/api
  static const String baseUrl = 'http://192.168.100.137:8000/api';  // Computer IP for physical device

  // Authentication
  static const String login = '/login';
  static const String register = '/register';
  static const String logout = '/logout';
  static const String me = '/me';

  // Projects
  static String projects() => '$baseUrl/projects';
  static String project(int id) => '$baseUrl/projects/$id';
  static String assignProjectUsers(int id) => '$baseUrl/projects/$id/assign-users';
  static String usersForAssignment() => '$baseUrl/projects/users-for-assignment';

  // Units
  static String units(int projectId) => '$baseUrl/projects/$projectId/units';
  static String unit(int projectId, int unitId) => '$baseUrl/projects/$projectId/units/$unitId';

  // Scenarios
  static String scenarios(int projectId, int unitId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios';
  static String scenario(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId';

  // Map Layers
  static String mapLayers(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/map-layers';
  static String mapLayer(int projectId, int unitId, int scenarioId, int layerId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/map-layers/$layerId';

  // Layout Layers
  static String layoutLayers(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/layout-layers';
  static String layoutLayer(int projectId, int unitId, int scenarioId, int layerId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/layout-layers/$layerId';

  // Equipment Items
  static String equipmentItems(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/equipment-items';
  static String equipmentItem(int projectId, int unitId, int scenarioId, int itemId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/equipment-items/$itemId';

  // Escape Routes
  static String escapeRoutes(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/escape-routes';
  static String escapeRoute(int projectId, int unitId, int scenarioId, int routeId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/escape-routes/$routeId';

  // Risk Zones
  static String riskZones(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/risk-zones';
  static String riskZone(int projectId, int unitId, int scenarioId, int zoneId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/risk-zones/$zoneId';

  // Scenario Tabs
  static String scenarioTabs(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/tabs';
  static String scenarioTab(int projectId, int unitId, int scenarioId, int tabId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/tabs/$tabId';

  // Documents
  static String documents(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/documents';
  static String document(int projectId, int unitId, int scenarioId, int docId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/documents/$docId';
  static String uploadDocument(int projectId, int unitId, int scenarioId) => '$baseUrl/projects/$projectId/units/$unitId/scenarios/$scenarioId/documents/upload';

  // Reports
  static String reports(int projectId, int unitId) => '$baseUrl/projects/$projectId/units/$unitId/reports';
  static String generateReport(int projectId, int unitId) => '$baseUrl/projects/$projectId/units/$unitId/reports/generate';
  static String downloadReport(int projectId, int unitId, int reportId) => '$baseUrl/projects/$projectId/units/$unitId/reports/$reportId/download';
}
