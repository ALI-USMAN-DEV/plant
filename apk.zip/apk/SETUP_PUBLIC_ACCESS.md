# Public Access Setup Guide 🌐

## Client Kahin Se Bhi APK Use Kar Sakta Hai!

### Step 1: ngrok URL Get Karo

1. **Browser me open karo:**
   ```
   http://localhost:4040
   ```

2. **"Forwarding" section me URL dekho:**
   - Kuch aisa dikhega: `https://abc123.ngrok-free.app`
   - Ye hi public URL hai!

3. **URL yahan share karo:**
   - Example: `https://abc123.ngrok-free.app`
   - Main automatically API constants update kar dunga

### Step 2: Automatic Update (Agar URL mil jaye)

Jab URL mil jaye, main:
1. ✅ API constants update kar dunga
2. ✅ APK rebuild kar dunga  
3. ✅ Naya APK ready ho jayega

### Step 3: APK Distribute Karo

- Naya APK kahin se bhi install karke use kar sakte hain
- Backend server publicly accessible hoga
- Client ko sirf APK chahiye, kuch aur setup nahi!

---

## Current Status

- ✅ ngrok installed
- ✅ Backend server running on port 8000
- ⏳ Waiting for ngrok public URL

---

## Manual Method (Agar automatic nahi ho)

1. **ngrok URL get karo** (http://localhost:4040)
2. **File edit karo:** `frontend/lib/core/constants/api_constants.dart`
3. **Line 11 update karo:**
   ```dart
   static const String baseUrl = 'https://YOUR_NGROK_URL.ngrok-free.app/api';
   ```
4. **APK rebuild karo:**
   ```bash
   cd frontend
   flutter clean
   flutter pub get
   flutter build apk --release
   ```

---

**Note:** ngrok free account me URL har baar restart par change hota hai. Production ke liye proper hosting (AWS, Heroku, etc.) use karein.
