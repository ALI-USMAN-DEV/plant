# Deployment Guide

## Backend Deployment (Laravel)

### Production Environment Setup

1. **Server Requirements**
   - PHP >= 8.1 with extensions: BCMath, Ctype, Fileinfo, JSON, Mbstring, OpenSSL, PDO, Tokenizer, XML
   - MySQL >= 5.7 or MariaDB >= 10.3
   - Composer
   - Web server (Apache/Nginx)

2. **Environment Configuration**

   ```bash
   # Set production environment
   APP_ENV=production
   APP_DEBUG=false
   
   # Generate secure key
   php artisan key:generate
   
   # Optimize for production
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   ```

3. **Database Setup**

   ```bash
   # Run migrations
   php artisan migrate --force
   
   # Optional: Seed initial data
   php artisan db:seed --force
   ```

4. **File Permissions**

   ```bash
   chmod -R 755 storage
   chmod -R 755 bootstrap/cache
   ```

5. **Web Server Configuration**

   **Nginx Example:**
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;
       root /path/to/backend/public;

       add_header X-Frame-Options "SAMEORIGIN";
       add_header X-Content-Type-Options "nosniff";

       index index.php;

       charset utf-8;

       location / {
           try_files $uri $uri/ /index.php?$query_string;
       }

       location = /favicon.ico { access_log off; log_not_found off; }
       location = /robots.txt  { access_log off; log_not_found off; }

       error_page 404 /index.php;

       location ~ \.php$ {
           fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
           fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
           include fastcgi_params;
       }

       location ~ /\.(?!well-known).* {
           deny all;
       }
   }
   ```

## Frontend Deployment (Flutter APK)

### Building Production APK

1. **Configure Release Build**

   ```bash
   cd frontend
   flutter build apk --release
   ```

2. **APK Location**

   Output: `build/app/outputs/flutter-apk/app-release.apk`

3. **Distribute APK**

   - Upload to Google Play Store (requires Play Console account)
   - Distribute via direct download
   - Use internal testing track for beta testing

### Google Play Store Submission

1. **Prepare Assets**
   - App icon (512x512)
   - Feature graphic (1024x500)
   - Screenshots (phone and tablet)

2. **Create Release**
   - Upload signed APK/AAB
   - Fill in release notes
   - Set content rating
   - Complete store listing

3. **Testing**
   - Use internal testing track first
   - Test on multiple devices
   - Verify all features work

## Security Checklist

### Backend
- [ ] Set `APP_DEBUG=false` in production
- [ ] Use strong database passwords
- [ ] Enable HTTPS/SSL
- [ ] Configure CORS properly
- [ ] Set up firewall rules
- [ ] Regular security updates
- [ ] Backup database regularly

### Frontend
- [ ] Obfuscate code (optional)
- [ ] Use ProGuard/R8 for Android
- [ ] Secure API keys
- [ ] Implement certificate pinning (optional)
- [ ] Test on various Android versions

## Performance Optimization

### Backend
- Enable OPcache
- Use Redis for caching
- Optimize database queries
- Compress responses
- Use CDN for static assets

### Frontend
- Enable R8/ProGuard
- Use code splitting
- Optimize images
- Minimize bundle size
- Test on low-end devices

## Monitoring

### Recommended Tools
- Laravel Telescope (development)
- Laravel Log (production)
- Google Analytics (app usage)
- Firebase Crashlytics (error tracking)

## Backup Strategy

1. **Database Backups**
   ```bash
   mysqldump -u username -p plant_layout > backup_$(date +%Y%m%d).sql
   ```

2. **File Backups**
   - Backup `storage/app/public/` directory
   - Include uploaded files and generated reports

3. **Automated Backups**
   - Set up cron job for daily backups
   - Store backups off-server
   - Test restore procedures

## Maintenance

### Regular Tasks
- Update dependencies monthly
- Review security advisories
- Monitor server resources
- Check error logs
- Update documentation

### Version Updates
- Test in staging first
- Backup before updates
- Document changes
- Communicate with users
