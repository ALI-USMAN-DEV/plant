# APK Rebuild Script
# Rebuilds APK with updated API URL

Write-Host "🔨 Rebuilding APK..." -ForegroundColor Cyan
Write-Host ""

$frontendDir = "frontend"

if (-not (Test-Path $frontendDir)) {
    Write-Host "❌ Error: frontend directory not found!" -ForegroundColor Red
    exit 1
}

# Check if Flutter is installed
$flutterCheck = Get-Command flutter -ErrorAction SilentlyContinue
if (-not $flutterCheck) {
    Write-Host "❌ Error: Flutter not found in PATH!" -ForegroundColor Red
    Write-Host "Please install Flutter or add it to PATH." -ForegroundColor Yellow
    exit 1
}

# Navigate to frontend
Push-Location $frontendDir

try {
    Write-Host "🧹 Cleaning previous build..." -ForegroundColor Yellow
    flutter clean
    
    Write-Host ""
    Write-Host "📦 Getting dependencies..." -ForegroundColor Yellow
    flutter pub get
    
    Write-Host ""
    Write-Host "🏗️  Building APK (this may take a few minutes)..." -ForegroundColor Yellow
    flutter build apk --release
    
    Write-Host ""
    Write-Host "✅ APK built successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "📱 APK Location:" -ForegroundColor Cyan
    $apkPath = "build\app\outputs\flutter-apk\app-release.apk"
    if (Test-Path $apkPath) {
        $fullPath = (Resolve-Path $apkPath).Path
        Write-Host $fullPath -ForegroundColor White
        Write-Host ""
        Write-Host "📋 Next Steps:" -ForegroundColor Cyan
        Write-Host "1. Install on device: adb install -r $apkPath" -ForegroundColor White
        Write-Host "2. Or copy APK to device and install manually" -ForegroundColor White
    } else {
        Write-Host "⚠️  Warning: APK file not found at expected location!" -ForegroundColor Yellow
    }
} catch {
    Write-Host ""
    Write-Host "❌ Error building APK!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
} finally {
    Pop-Location
}
