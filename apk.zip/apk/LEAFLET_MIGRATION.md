# Leaflet Maps Migration Guide

## Changes Made

The application has been migrated from **Google Maps** to **Leaflet Maps** (OpenStreetMap).

## Benefits

✅ **No API Key Required** - Free to use, no Google Cloud account needed
✅ **Open Source** - OpenStreetMap tiles
✅ **Better Layer Control** - Native Leaflet layer management
✅ **Cost Effective** - No usage limits or billing
✅ **Privacy Friendly** - No tracking by Google

## Technical Changes

### Frontend Dependencies

**Removed:**
- `google_maps_flutter: ^2.5.0`

**Added:**
- `flutter_map: ^7.0.2` - Flutter implementation of Leaflet
- `latlong2: ^0.9.1` - LatLng coordinates for Leaflet

### Code Changes

1. **MapTab Implementation**
   - Replaced `GoogleMap` widget with `FlutterMap`
   - Implemented Leaflet layer system:
     - `TileLayer` for base map (OpenStreetMap)
     - `OverlayImageLayer` for layout images
     - `MarkerLayer` for equipment items
     - `PolylineLayer` for escape routes
     - `CircleLayer` for risk zones

2. **Android Manifest**
   - Removed Google Maps API key requirement
   - No special configuration needed

3. **Layer Management**
   - Native Leaflet layer toggling
   - Better performance with layer groups
   - Individual layer visibility controls

## Map Features

### Base Map
- **Provider**: OpenStreetMap
- **Tile URL**: `https://tile.openstreetmap.org/{z}/{x}/{y}.png`
- **Free**: No API key needed
- **Customizable**: Can switch to other tile providers

### Layer System

All layers are toggleable via the layer control panel:

1. **Base Map Layer**
   - OpenStreetMap tiles
   - Standard map view

2. **Layout Layer**
   - Image overlays
   - Position, scale, rotate support
   - Multiple images per scenario

3. **Equipment Layer**
   - Custom markers with icons
   - Clickable for details
   - Customizable size and rotation

4. **Escape Route Layer**
   - Polylines with custom colors
   - Adjustable width
   - Multiple routes per scenario

5. **Risk Zone Layer**
   - Circles with radius
   - Custom colors and opacity
   - Wind direction indicators
   - Stroke customization

## Customization

### Change Tile Provider

Edit `map_tab.dart`:

```dart
TileLayer(
  urlTemplate: 'YOUR_TILE_PROVIDER_URL/{z}/{x}/{y}.png',
  // Examples:
  // OpenStreetMap: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
  // CartoDB: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png'
  // Mapbox: 'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}'
)
```

### Add Custom Layers

Leaflet supports adding custom layers easily:

```dart
// Add custom tile layer
TileLayer(
  urlTemplate: 'your-custom-tiles/{z}/{x}/{y}.png',
  // Additional options
)
```

## Migration Notes

### For Existing Users

1. **No Backend Changes Required**
   - All API endpoints remain the same
   - Database schema unchanged
   - File uploads work as before

2. **Data Compatibility**
   - All existing map data works with Leaflet
   - Coordinates (lat/lng) are compatible
   - Layer data structure unchanged

3. **Performance**
   - Leaflet is lightweight and fast
   - Better performance on low-end devices
   - Efficient tile caching

## Troubleshooting

### Maps Not Loading

1. **Check Internet Connection**
   - Leaflet requires internet for tile loading
   - OpenStreetMap tiles are loaded from internet

2. **Check Tile Server**
   - Verify OpenStreetMap is accessible
   - Try different tile provider if needed

3. **Network Permissions**
   - Ensure `INTERNET` permission in AndroidManifest.xml
   - Check firewall settings

### Layer Not Showing

1. **Check Layer Visibility**
   - Toggle layer in control panel
   - Verify `_layerVisibility` state

2. **Check Data**
   - Verify data is loaded from API
   - Check console for errors

3. **Check Coordinates**
   - Ensure lat/lng are valid
   - Check bounds calculation

## Future Enhancements

Possible improvements:
- Offline map support
- Custom tile caching
- More tile providers
- Vector tiles support
- 3D terrain (with plugins)

## Resources

- [Flutter Map Documentation](https://docs.fleaflet.dev/)
- [Leaflet.js Documentation](https://leafletjs.com/)
- [OpenStreetMap](https://www.openstreetmap.org/)
- [Tile Providers List](https://wiki.openstreetmap.org/wiki/Tile_servers)
