import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:plant_layout_viewer/data/models/project_model.dart';
import 'package:plant_layout_viewer/data/models/unit_model.dart';
import 'package:plant_layout_viewer/data/models/scenario_model.dart';
import 'package:plant_layout_viewer/data/services/api_service.dart';
import 'package:plant_layout_viewer/core/constants/api_constants.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:dio/dio.dart';
import 'dart:io';

class MapTab extends StatefulWidget {
  final ProjectModel project;
  final UnitModel unit;
  final ScenarioModel scenario;

  const MapTab({
    super.key,
    required this.project,
    required this.unit,
    required this.scenario,
  });

  @override
  State<MapTab> createState() => _MapTabState();
}

class _MapTabState extends State<MapTab> {
  final MapController _mapController = MapController();
  
  // Layer visibility controls
  Map<String, bool> _layerVisibility = {
    'base': true,
    'layout': true,
    'equipment': true,
    'escape_route': true,
    'risk_zone': true,
  };

  // Data storage
  List<Map<String, dynamic>> _layoutLayers = [];
  List<Map<String, dynamic>> _equipmentItems = [];
  List<Map<String, dynamic>> _escapeRoutes = [];
  List<Map<String, dynamic>> _riskZones = [];
  List<MapLayer>? _mapLayersList;
  
  bool _isLoading = true;
  String? _drawingMode; // 'equipment', 'escape_route', 'risk_zone'
  List<LatLng> _currentRoutePoints = [];
  LatLng? _riskZoneCenter;

  @override
  void initState() {
    super.initState();
    _loadMapData();
  }

  Future<void> _loadMapData() async {
    setState(() => _isLoading = true);
    try {
      final response = await ApiService().get(
        ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id),
      );

      if (response.statusCode == 200 && response.data['success'] == true) {
        final data = response.data['data'];
        final mapLayers = data['map_layers'] as List?;

        if (mapLayers != null) {
          setState(() {
            _layoutLayers = [];
            _equipmentItems = [];
            _escapeRoutes = [];
            _riskZones = [];
            _mapLayersList = mapLayers.map((l) => MapLayer.fromJson(l)).toList();

            for (var layer in mapLayers) {
              final layerType = layer['layer_type'] as String;
              
              // Load layout layers
              if (layerType == 'layout' && layer['layout_layers'] != null) {
                final layoutLayersList = layer['layout_layers'] as List;
                for (var layoutItem in layoutLayersList) {
                  if (layoutItem is Map<String, dynamic>) {
                    // Ensure is_visible defaults to true if not set
                    if (!layoutItem.containsKey('is_visible')) {
                      layoutItem['is_visible'] = true;
                    }
                    _layoutLayers.add(layoutItem);
                  }
                }
              }

              // Load equipment items
              if (layerType == 'equipment' && layer['equipment_items'] != null) {
                _equipmentItems.addAll(
                  (layer['equipment_items'] as List).map((item) => item as Map<String, dynamic>).toList(),
                );
              }

              // Load escape routes
              if (layerType == 'escape_route' && layer['escape_routes'] != null) {
                _escapeRoutes.addAll(
                  (layer['escape_routes'] as List).map((item) => item as Map<String, dynamic>).toList(),
                );
              }

              // Load risk zones
              if (layerType == 'risk_zone' && layer['risk_zones'] != null) {
                _riskZones.addAll(
                  (layer['risk_zones'] as List).map((item) => item as Map<String, dynamic>).toList(),
                );
              }
            }
            _isLoading = false;
          });
        } else {
          setState(() => _isLoading = false);
        }
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading map data: $e')),
        );
      }
    }
  }

  Color _parseColor(String hexColor) {
    final hex = hexColor.replaceAll('#', '');
    return Color(int.parse('FF$hex', radix: 16));
  }

  // Build ordered layers based on z-index
  List<Widget> _buildOrderedLayers() {
    final layers = <Widget>[];

    // Base Tile Layer (always first, z-index: 0)
    if (_layerVisibility['base'] == true) {
      layers.add(
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.plantlayout.viewer',
          maxZoom: 19,
        ),
      );
    }

    // Get all map layers and sort by z-index
    final sortedLayers = <MapLayer>[];
    if (_mapLayersList != null) {
      sortedLayers.addAll(_mapLayersList!);
      sortedLayers.sort((a, b) {
        final aZ = a.zIndex ?? 0;
        final bZ = b.zIndex ?? 0;
        return aZ.compareTo(bZ);
      });
    }

    // Add layers in z-index order
    for (var layer in sortedLayers) {
      if (!layer.isVisible) continue;

      // Layout Image Overlays Layer
      if (layer.layerType == 'layout' && _layerVisibility['layout'] == true) {
        final overlayImages = _buildLayoutOverlayImages(layerOpacity: layer.opacity);
        if (overlayImages.isNotEmpty) {
          layers.add(
            OverlayImageLayer(
              overlayImages: overlayImages,
            ),
          );
        }
        // Add invisible markers for layout images so they can be tapped
        final layoutMarkers = _buildLayoutMarkers();
        if (layoutMarkers.isNotEmpty) {
          layers.add(
            MarkerLayer(
              markers: layoutMarkers,
            ),
          );
        }
      }

      // Equipment Markers Layer
      if (layer.layerType == 'equipment' && _layerVisibility['equipment'] == true && _equipmentItems.isNotEmpty) {
        layers.add(
          MarkerLayer(
            markers: _buildEquipmentMarkers(),
          ),
        );
      }

      // Escape Routes Layer
      if (layer.layerType == 'escape_route' && _layerVisibility['escape_route'] == true) {
        layers.add(
          PolylineLayer(
            polylines: [
              ..._buildEscapeRoutePolylines(),
              // Show current route being drawn
              if (_drawingMode == 'escape_route' && _currentRoutePoints.length > 1)
                Polyline(
                  points: _currentRoutePoints,
                  strokeWidth: 3,
                  color: Colors.blue,
                ),
            ],
          ),
        );
      }

      // Risk Zones Layer
      if (layer.layerType == 'risk_zone' && _layerVisibility['risk_zone'] == true && _riskZones.isNotEmpty) {
        layers.add(
          CircleLayer(
            circles: _buildRiskZoneCircles(),
          ),
        );
      }
    }

    return layers;
  }

  LatLng _getInitialPosition() {
    if (widget.scenario.mapCenterLat != null && widget.scenario.mapCenterLng != null) {
      return LatLng(widget.scenario.mapCenterLat!, widget.scenario.mapCenterLng!);
    }
    return const LatLng(40.7128, -74.0060); // Default position - Default jagah
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    return Stack(
      children: [
        FlutterMap(
          mapController: _mapController,
          options: MapOptions(
            initialCenter: _getInitialPosition(),
            initialZoom: widget.scenario.mapZoom,
            minZoom: 3.0,
            maxZoom: 18.0,
            onTap: _onMapTap,
          ),
          children: _buildOrderedLayers(),
        ),

        // Layer Control Panel - Layer control panel
        Positioned(
          top: 16,
          right: 16,
          child: Card(
            elevation: 4,
            child: Container(
              width: 200,
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Layer Controls',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      // Admin Layer Management Button
                      IconButton(
                        icon: const Icon(Icons.settings, size: 18),
                        tooltip: 'Layer Settings',
                        onPressed: () => _showLayerManagementDialog(),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                      ),
                    ],
                  ),
                  const Divider(),
                  _buildLayerToggle('Base Map', 'base'),
                  _buildLayerToggle('Layout Images', 'layout'),
                  _buildLayerToggle('Equipment', 'equipment'),
                  _buildLayerToggle('Escape Routes', 'escape_route'),
                  _buildLayerToggle('Risk Zones', 'risk_zone'),
                ],
              ),
            ),
          ),
        ),

        // Add Layer Button
        Positioned(
          bottom: 16,
          right: 16,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              // Complete Escape Route Button
              if (_drawingMode == 'escape_route')
                Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: FloatingActionButton(
                    onPressed: _completeEscapeRoute,
                    backgroundColor: Colors.green,
                    child: const Icon(Icons.check),
                    tooltip: 'Complete Route',
                  ),
                ),
              // Cancel Drawing Button
              if (_drawingMode != null && _drawingMode != 'escape_route')
                Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: FloatingActionButton(
                    onPressed: () {
                      setState(() {
                        _drawingMode = null;
                        _currentRoutePoints = [];
                        _riskZoneCenter = null;
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Drawing cancelled')),
                      );
                    },
                    backgroundColor: Colors.red,
                    child: const Icon(Icons.close),
                    tooltip: 'Cancel',
                  ),
                ),
              // Main Add Layer Button
              FloatingActionButton.extended(
                onPressed: () {
                  if (_drawingMode != null) {
                    setState(() {
                      _drawingMode = null;
                      _currentRoutePoints = [];
                      _riskZoneCenter = null;
                    });
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Drawing cancelled')),
                    );
                  } else {
                    _showAddLayerDialog();
                  }
                },
                icon: Icon(_drawingMode != null ? Icons.close : Icons.add),
                label: Text(_drawingMode != null ? 'Cancel' : 'Add Layer'),
              ),
            ],
          ),
        ),
        
        // Show current route points count while drawing
        if (_drawingMode == 'escape_route' && _currentRoutePoints.isNotEmpty)
          Positioned(
            top: 80,
            right: 16,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Points: ${_currentRoutePoints.length}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
      ],
    );
  }

  List<OverlayImage> _buildLayoutOverlayImages({double? layerOpacity}) {
    if (_layoutLayers.isEmpty) {
      if (kDebugMode) {
        print('No layout layers to display');
      }
      return [];
    }
    
    final overlayImages = <OverlayImage>[];
    
    for (var layer in _layoutLayers) {
      try {
        // Check if layer is visible (default to true if not set)
        final isVisible = layer['is_visible'];
        if (isVisible == false || isVisible == 0) {
          continue;
        }
        
        final lat = double.tryParse(layer['position_lat'].toString());
        final lng = double.tryParse(layer['position_lng'].toString());
        final filePath = layer['file_path'] as String?;
        
        if (lat == null || lng == null || filePath == null || filePath.isEmpty) {
          if (kDebugMode) {
            print('Invalid layout layer data: lat=$lat, lng=$lng, filePath=$filePath');
          }
          continue;
        }
        
        final scaleX = double.tryParse((layer['scale_x'] ?? 1.0).toString()) ?? 1.0;
        final scaleY = double.tryParse((layer['scale_y'] ?? 1.0).toString()) ?? 1.0;
        final itemOpacity = layer['opacity'] != null 
            ? double.tryParse(layer['opacity'].toString()) 
            : null;
        
        // Build full URL - Remove /api and add /storage
        final baseUrl = ApiConstants.baseUrl.replaceAll('/api', '');
        final imageUrl = '$baseUrl/storage/$filePath';
        
        if (kDebugMode) {
          print('Loading layout image: $imageUrl at ($lat, $lng)');
        }

        // Calculate bounds for overlay
        // Use actual image dimensions if available, otherwise use scale-based calculation
        final width = layer['width'] != null ? double.tryParse(layer['width'].toString()) : null;
        final height = layer['height'] != null ? double.tryParse(layer['height'].toString()) : null;
        
        double offset;
        if (width != null && height != null && width! > 0 && height! > 0) {
          // Use actual dimensions - approximate calculation
          // At zoom 15, 1 degree ≈ 111km, so 1 pixel ≈ 0.00001 degrees for a 1000px image
          final avgDimension = (width! + height!) / 2;
          offset = (avgDimension * 0.00001 * (scaleX + scaleY) / 2) / 2;
        } else {
          // Default: 0.01 degrees ≈ 1km, scaled by scale factor
          offset = 0.01 * (scaleX + scaleY) / 2;
        }
        
        // Ensure offset is reasonable
        if (offset < 0.0001) offset = 0.0001;
        if (offset > 0.1) offset = 0.1;
        
        // Use layer opacity, item opacity, or default
        final opacity = layerOpacity ?? itemOpacity ?? 0.8;
        
        overlayImages.add(
          OverlayImage(
            bounds: LatLngBounds(
              LatLng(lat - offset, lng - offset),
              LatLng(lat + offset, lng + offset),
            ),
            imageProvider: CachedNetworkImageProvider(imageUrl),
            opacity: opacity,
          ),
        );
      } catch (e) {
        if (kDebugMode) {
          print('Error building overlay image: $e');
        }
        continue;
      }
    }
    
    if (kDebugMode) {
      print('Built ${overlayImages.length} overlay images from ${_layoutLayers.length} layout layers');
    }
    
    return overlayImages;
  }

  List<Marker> _buildLayoutMarkers() {
    return _layoutLayers.map((layer) {
      try {
        final lat = double.tryParse(layer['position_lat'].toString());
        final lng = double.tryParse(layer['position_lng'].toString());
        final id = layer['id'];
        
        if (lat == null || lng == null || id == null) {
          return null;
        }
        
        // Check if layer is visible
        final isVisible = layer['is_visible'];
        if (isVisible == false || isVisible == 0) {
          return null;
        }
        
        return Marker(
          point: LatLng(lat, lng),
          width: 30,
          height: 30,
          child: GestureDetector(
            onTap: () {
              _showLayoutImageEditDialog(layer);
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                shape: BoxShape.circle,
              ),
              // Invisible but tappable
              child: const SizedBox(width: 30, height: 30),
            ),
          ),
        );
      } catch (e) {
        return null;
      }
    }).whereType<Marker>().toList();
  }

  List<Marker> _buildEquipmentMarkers() {
    return _equipmentItems.map((item) {
      final lat = double.parse(item['position_lat'].toString());
      final lng = double.parse(item['position_lng'].toString());
      final name = item['name'] as String? ?? 'Equipment';
      final iconPath = item['icon_path'] as String?;

      return Marker(
        point: LatLng(lat, lng),
        width: 40,
        height: 40,
        child: GestureDetector(
          onTap: () {
            _showEquipmentInfo(item);
          },
          child: Container(
            decoration: BoxDecoration(
              color: Colors.blue,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: iconPath != null && iconPath.isNotEmpty
                ? ClipOval(
                    child: CachedNetworkImage(
                      imageUrl: '${ApiConstants.baseUrl.replaceAll('/api', '')}/storage/$iconPath',
                      fit: BoxFit.cover,
                      width: 40,
                      height: 40,
                      errorWidget: (context, url, error) => const Icon(Icons.location_on, color: Colors.white, size: 24),
                      placeholder: (context, url) => const Center(child: CircularProgressIndicator(strokeWidth: 2)),
                    ),
                  )
                : const Icon(Icons.location_on, color: Colors.white, size: 24),
          ),
        ),
      );
    }).toList();
  }

  List<Polyline> _buildEscapeRoutePolylines() {
    return _escapeRoutes
        .where((route) => route['is_visible'] == true)
        .map((route) {
      final pathData = route['path_data'] as List;
      final color = _parseColor(route['color'] ?? '#FF0000');
      final width = (route['width'] ?? 3).toDouble();

      if (pathData.isEmpty) {
        return Polyline(
          points: [],
          strokeWidth: width,
          color: color,
        );
      }

      return Polyline(
        points: pathData.map((point) {
          return LatLng(
            double.parse(point['lat'].toString()),
            double.parse(point['lng'].toString()),
          );
        }).toList(),
        strokeWidth: width,
        color: color,
      );
    }).toList();
  }

  List<CircleMarker> _buildRiskZoneCircles() {
    return _riskZones
        .where((zone) => zone['is_visible'] == true)
        .map((zone) {
      final lat = double.parse(zone['center_lat'].toString());
      final lng = double.parse(zone['center_lng'].toString());
      final radius = double.parse(zone['radius_meters'].toString());
      final color = _parseColor(zone['color'] ?? '#FF0000');
      final strokeColor = _parseColor(zone['stroke_color'] ?? '#000000');
      final opacity = double.parse((zone['opacity'] ?? 0.5).toString());
      final strokeWidth = (zone['stroke_width'] ?? 2).toDouble();

      return CircleMarker(
        point: LatLng(lat, lng),
        radius: radius,
        useRadiusInMeter: true,
        color: color.withOpacity(opacity),
        borderColor: strokeColor,
        borderStrokeWidth: strokeWidth,
      );
    }).toList();
  }

  Widget _buildLayerToggle(String label, String layerKey) {
    return CheckboxListTile(
      title: Text(label),
      value: _layerVisibility[layerKey] ?? false,
      onChanged: (value) {
        setState(() {
          _layerVisibility[layerKey] = value ?? false;
        });
      },
      dense: true,
      contentPadding: EdgeInsets.zero,
    );
  }

  void _showLayerManagementDialog() {
    showDialog(
      context: context,
      builder: (context) => _LayerManagementDialog(
        mapLayers: _mapLayersList ?? [],
        projectId: widget.project.id,
        unitId: widget.unit.id,
        scenarioId: widget.scenario.id,
        onUpdate: () {
          _loadMapData(); // Reload data after update
        },
      ),
    );
  }

  void _showLayoutImageEditDialog(Map<String, dynamic> layoutLayer) {
    showDialog(
      context: context,
      builder: (context) => _LayoutImageEditDialog(
        layoutLayer: layoutLayer,
        projectId: widget.project.id,
        unitId: widget.unit.id,
        scenarioId: widget.scenario.id,
        onUpdate: () {
          _loadMapData(); // Reload data after update
        },
      ),
    );
  }

  void _showAddLayerDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Layer'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.image),
              title: const Text('Layout Image'),
              onTap: () {
                Navigator.pop(context);
                _uploadLayoutImage();
              },
            ),
            ListTile(
              leading: const Icon(Icons.location_on),
              title: const Text('Equipment Item'),
              onTap: () {
                Navigator.pop(context);
                _addEquipmentItem();
              },
            ),
            ListTile(
              leading: const Icon(Icons.route),
              title: const Text('Escape Route'),
              onTap: () {
                Navigator.pop(context);
                _addEscapeRoute();
              },
            ),
            ListTile(
              leading: const Icon(Icons.warning),
              title: const Text('Risk Zone'),
              onTap: () {
                Navigator.pop(context);
                _addRiskZone();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showEquipmentInfo(Map<String, dynamic> item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(item['name'] ?? 'Equipment'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('ID: ${item['id']}'),
            if (item['icon_path'] != null)
              Text('Icon: ${item['icon_path']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Future<void> _uploadLayoutImage() async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: ImageSource.gallery);
      
      if (image == null) return;

      // Find layout layer
      final layoutLayer = _mapLayersList?.firstWhere(
        (layer) => layer.layerType == 'layout',
        orElse: () => throw Exception('Layout layer not found'),
      );

      if (layoutLayer == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Layout layer not found')),
        );
        return;
      }

      // Get current map center for position
      final center = _mapController.camera.center;
      
      // Show dialog for position and scale
      final result = await showDialog<Map<String, dynamic>>(
        context: context,
        builder: (context) => _LayoutImageDialog(
          initialLat: center.latitude,
          initialLng: center.longitude,
        ),
      );

      if (result == null) return;

      // Upload to backend
      final apiService = ApiService();
      final formData = FormData.fromMap({
        'map_layer_id': layoutLayer.id,
        'file': await MultipartFile.fromFile(image.path),
        'position_lat': result['lat'],
        'position_lng': result['lng'],
        'scale_x': result['scale_x'] ?? 1.0,
        'scale_y': result['scale_y'] ?? 1.0,
        'rotation': result['rotation'] ?? 0.0,
      });

      final response = await apiService.post(
        '${ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id)}/map-layers/layouts',
        data: formData,
      );

      if (response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Layout image uploaded successfully')),
        );
        // Reload data after a short delay to ensure backend has processed
        await Future.delayed(const Duration(milliseconds: 500));
        _loadMapData(); // Reload data
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> _addEquipmentItem() async {
    try {
      // Find equipment layer
      final equipmentLayer = _mapLayersList?.firstWhere(
        (layer) => layer.layerType == 'equipment',
        orElse: () => throw Exception('Equipment layer not found'),
      );

      if (equipmentLayer == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Equipment layer not found')),
        );
        return;
      }

      final center = _mapController.camera.center;
      
      // Enable drawing mode for equipment
      setState(() {
        _drawingMode = 'equipment';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tap on map to select equipment position'),
          duration: Duration(seconds: 3),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> _addEquipmentAtPoint(LatLng point) async {
    try {
      final equipmentLayer = _mapLayersList?.firstWhere(
        (layer) => layer.layerType == 'equipment',
      );

      if (equipmentLayer == null) return;

      setState(() {
        _drawingMode = null;
      });

      final result = await showDialog<Map<String, dynamic>>(
        context: context,
        builder: (context) => _EquipmentItemDialog(
          initialLat: point.latitude,
          initialLng: point.longitude,
        ),
      );

      if (result == null) return;

      final apiService = ApiService();
      
      // Build FormData with file if icon is provided
      FormData formData;
      if (result['icon'] != null && result['icon'] is String) {
        final iconFile = File(result['icon']);
        if (await iconFile.exists()) {
          // Create FormData with icon file
          formData = FormData.fromMap({
            'map_layer_id': equipmentLayer.id,
            'name': result['name'],
            'position_lat': result['lat'] ?? point.latitude,
            'position_lng': result['lng'] ?? point.longitude,
            'rotation': result['rotation'] ?? 0.0,
            'size': result['size'] ?? 32,
            'icon': await MultipartFile.fromFile(
              result['icon'],
              filename: result['icon'].split('/').last,
            ),
          });
        } else {
          // Icon file doesn't exist, create without icon
          formData = FormData.fromMap({
            'map_layer_id': equipmentLayer.id,
            'name': result['name'],
            'position_lat': result['lat'] ?? point.latitude,
            'position_lng': result['lng'] ?? point.longitude,
            'rotation': result['rotation'] ?? 0.0,
            'size': result['size'] ?? 32,
          });
        }
      } else {
        // No icon provided
        formData = FormData.fromMap({
          'map_layer_id': equipmentLayer.id,
          'name': result['name'],
          'position_lat': result['lat'] ?? point.latitude,
          'position_lng': result['lng'] ?? point.longitude,
          'rotation': result['rotation'] ?? 0.0,
          'size': result['size'] ?? 32,
        });
      }

      // Use longer timeout for file uploads
      final response = await apiService.post(
        '${ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id)}/map-layers/equipment',
        data: formData,
      );

      if (response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Equipment item added successfully')),
        );
        _loadMapData();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> _addEscapeRoute() async {
    try {
      final equipmentLayer = _mapLayersList?.firstWhere(
        (layer) => layer.layerType == 'escape_route',
        orElse: () => throw Exception('Escape route layer not found'),
      );

      if (equipmentLayer == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Escape route layer not found')),
        );
        return;
      }

      setState(() {
        _drawingMode = 'escape_route';
        _currentRoutePoints = [];
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tap on map to draw route. Click complete button to finish.'),
          duration: Duration(seconds: 3),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> _addRiskZone() async {
    try {
      final riskZoneLayer = _mapLayersList?.firstWhere(
        (layer) => layer.layerType == 'risk_zone',
        orElse: () => throw Exception('Risk zone layer not found'),
      );

      if (riskZoneLayer == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Risk zone layer not found')),
        );
        return;
      }

      final center = _mapController.camera.center;
      
      // Enable drawing mode for risk zone
      setState(() {
        _drawingMode = 'risk_zone';
        _riskZoneCenter = center;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tap on map to select risk zone center'),
          duration: Duration(seconds: 3),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> _addRiskZoneAtPoint(LatLng point) async {
    try {
      final riskZoneLayer = _mapLayersList?.firstWhere(
        (layer) => layer.layerType == 'risk_zone',
      );

      if (riskZoneLayer == null) return;

      setState(() {
        _drawingMode = null;
        _riskZoneCenter = null;
      });
      
      final result = await showDialog<Map<String, dynamic>>(
        context: context,
        builder: (context) => _RiskZoneDialog(
          initialLat: point.latitude,
          initialLng: point.longitude,
        ),
      );

      if (result == null) return;

      final apiService = ApiService();
      final response = await apiService.post(
        '${ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id)}/map-layers/risk-zones',
        data: {
          'map_layer_id': riskZoneLayer.id,
          'name': result['name'],
          'center_lat': result['lat'],
          'center_lng': result['lng'],
          'radius_meters': result['radius'],
          'color': result['color'],
          'stroke_color': result['stroke_color'],
          'opacity': result['opacity'],
          'wind_direction': result['wind_direction'],
          'wind_velocity': result['wind_velocity'],
        },
      );

      if (response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Risk zone added successfully')),
        );
        _loadMapData();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  void _onMapTap(TapPosition tapPosition, LatLng point) {
    if (_drawingMode == 'escape_route') {
      setState(() {
        _currentRoutePoints.add(point);
      });
    } else if (_drawingMode == 'risk_zone') {
      // Update risk zone center when map is tapped
      setState(() {
        _riskZoneCenter = point;
        _drawingMode = null;
      });
      _addRiskZoneAtPoint(point);
    } else if (_drawingMode == 'equipment') {
      // Update equipment position when map is tapped
      setState(() {
        _drawingMode = null;
      });
      _addEquipmentAtPoint(point);
    }
  }

  void _completeEscapeRoute() async {
    if (_currentRoutePoints.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('At least 2 points required')),
      );
      return;
    }

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => _EscapeRouteDialog(),
    );

    if (result == null) {
      setState(() {
        _drawingMode = null;
        _currentRoutePoints = [];
      });
      return;
    }

    try {
      final escapeRouteLayer = _mapLayersList?.firstWhere(
        (layer) => layer.layerType == 'escape_route',
      );

      if (escapeRouteLayer == null) return;

      final apiService = ApiService();
      final pathData = _currentRoutePoints.map((p) => {
        'lat': p.latitude,
        'lng': p.longitude,
      }).toList();

      final response = await apiService.post(
        '${ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id)}/map-layers/escape-routes',
        data: {
          'map_layer_id': escapeRouteLayer.id,
          'name': result['name'],
          'color': result['color'] ?? '#FF0000',
          'width': result['width'] ?? 3,
          'path_data': pathData,
        },
      );

      if (response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Escape route added successfully')),
        );
        setState(() {
          _drawingMode = null;
          _currentRoutePoints = [];
        });
        _loadMapData();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }
}

// Helper class for map layer
class MapLayer {
  final int id;
  final String layerType;
  final String? name;
  final bool isVisible;
  final double? opacity;
  final int? zIndex;

  MapLayer({
    required this.id,
    required this.layerType,
    this.name,
    this.isVisible = true,
    this.opacity,
    this.zIndex,
  });

  factory MapLayer.fromJson(Map<String, dynamic> json) {
    return MapLayer(
      id: json['id'],
      layerType: json['layer_type'],
      name: json['name'],
      isVisible: json['is_visible'] ?? true,
      opacity: json['opacity'] != null ? double.tryParse(json['opacity'].toString()) : null,
      zIndex: json['z_index'] != null ? int.tryParse(json['z_index'].toString()) : null,
    );
  }
}

// Dialog widgets
class _LayoutImageDialog extends StatefulWidget {
  final double initialLat;
  final double initialLng;

  const _LayoutImageDialog({required this.initialLat, required this.initialLng});

  @override
  State<_LayoutImageDialog> createState() => _LayoutImageDialogState();
}

class _LayoutImageDialogState extends State<_LayoutImageDialog> {
  final _latController = TextEditingController();
  final _lngController = TextEditingController();
  final _scaleXController = TextEditingController(text: '1.0');
  final _scaleYController = TextEditingController(text: '1.0');
  final _rotationController = TextEditingController(text: '0.0');

  @override
  void initState() {
    super.initState();
    _latController.text = widget.initialLat.toString();
    _lngController.text = widget.initialLng.toString();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Layout Image Position'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _latController,
              decoration: const InputDecoration(
                labelText: 'Latitude',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _lngController,
              decoration: const InputDecoration(
                labelText: 'Longitude',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _scaleXController,
              decoration: const InputDecoration(
                labelText: 'Scale X',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _scaleYController,
              decoration: const InputDecoration(
                labelText: 'Scale Y',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _rotationController,
              decoration: const InputDecoration(
                labelText: 'Rotation (degrees)',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            Navigator.pop(context, {
              'lat': double.tryParse(_latController.text),
              'lng': double.tryParse(_lngController.text),
              'scale_x': double.tryParse(_scaleXController.text),
              'scale_y': double.tryParse(_scaleYController.text),
              'rotation': double.tryParse(_rotationController.text),
            });
          },
          child: const Text('OK'),
        ),
      ],
    );
  }
}

class _EquipmentItemDialog extends StatefulWidget {
  final double? initialLat;
  final double? initialLng;

  const _EquipmentItemDialog({this.initialLat, this.initialLng});

  @override
  State<_EquipmentItemDialog> createState() => _EquipmentItemDialogState();
}

class _EquipmentItemDialogState extends State<_EquipmentItemDialog> {
  final _nameController = TextEditingController();
  final _latController = TextEditingController();
  final _lngController = TextEditingController();
  String? _iconPath;

  @override
  void initState() {
    super.initState();
    if (widget.initialLat != null) {
      _latController.text = widget.initialLat!.toStringAsFixed(8);
    }
    if (widget.initialLng != null) {
      _lngController.text = widget.initialLng!.toStringAsFixed(8);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;
    
    return AlertDialog(
      title: const Text('Add Equipment Item'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: isMobile ? double.maxFinite : 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 8),
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Equipment Name',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _latController,
                decoration: const InputDecoration(
                  labelText: 'Latitude',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _lngController,
                decoration: const InputDecoration(
                  labelText: 'Longitude',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () async {
                  final ImagePicker picker = ImagePicker();
                  final XFile? image = await picker.pickImage(source: ImageSource.gallery);
                  if (image != null) {
                    setState(() => _iconPath = image.path);
                  }
                },
                icon: const Icon(Icons.image),
                label: Text(_iconPath != null ? 'Icon Selected' : 'Select Icon'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context, {
              'name': _nameController.text,
              'lat': double.tryParse(_latController.text),
              'lng': double.tryParse(_lngController.text),
              'icon': _iconPath,
            });
          },
          child: const Text('Add'),
        ),
      ],
    );
  }
}

class _EscapeRouteDialog extends StatefulWidget {
  @override
  State<_EscapeRouteDialog> createState() => _EscapeRouteDialogState();
}

class _EscapeRouteDialogState extends State<_EscapeRouteDialog> {
  final _nameController = TextEditingController();
  final _colorController = TextEditingController(text: '#FF0000');
  final _widthController = TextEditingController(text: '3');

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Escape Route Details'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Route Name',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _colorController,
              decoration: const InputDecoration(
                labelText: 'Color (hex)',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _widthController,
              decoration: const InputDecoration(
                labelText: 'Width',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            Navigator.pop(context, {
              'name': _nameController.text,
              'color': _colorController.text,
              'width': int.tryParse(_widthController.text),
            });
          },
          child: const Text('OK'),
        ),
      ],
    );
  }
}

class _RiskZoneDialog extends StatefulWidget {
  final double initialLat;
  final double initialLng;

  const _RiskZoneDialog({required this.initialLat, required this.initialLng});

  @override
  State<_RiskZoneDialog> createState() => _RiskZoneDialogState();
}

class _RiskZoneDialogState extends State<_RiskZoneDialog> {
  final _nameController = TextEditingController();
  final _latController = TextEditingController();
  final _lngController = TextEditingController();
  final _radiusController = TextEditingController(text: '100');
  final _colorController = TextEditingController(text: '#FF0000');
  final _strokeColorController = TextEditingController(text: '#000000');
  final _opacityController = TextEditingController(text: '0.5');
  final _windDirectionController = TextEditingController(text: '0');
  final _windVelocityController = TextEditingController(text: '0');

  @override
  void initState() {
    super.initState();
    _latController.text = widget.initialLat.toString();
    _lngController.text = widget.initialLng.toString();
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;
    double opacityValue = double.tryParse(_opacityController.text) ?? 0.5;
    
    return AlertDialog(
      title: const Text('Risk Zone Details'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: isMobile ? double.maxFinite : 450,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 8),
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Zone Name',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _latController,
                      decoration: const InputDecoration(
                        labelText: 'Latitude',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: _lngController,
                      decoration: const InputDecoration(
                        labelText: 'Longitude',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _radiusController,
                decoration: const InputDecoration(
                  labelText: 'Radius (meters)',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _colorController,
                      decoration: const InputDecoration(
                        labelText: 'Color (hex)',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: _strokeColorController,
                      decoration: const InputDecoration(
                        labelText: 'Stroke Color (hex)',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Opacity Slider
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Opacity: ${(opacityValue * 100).toStringAsFixed(0)}%',
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 8),
                  Slider(
                    value: opacityValue,
                    min: 0.0,
                    max: 1.0,
                    divisions: 100,
                    label: '${(opacityValue * 100).toStringAsFixed(0)}%',
                    onChanged: (value) {
                      setState(() {
                        opacityValue = value;
                        _opacityController.text = value.toStringAsFixed(2);
                      });
                    },
                  ),
                  TextField(
                    controller: _opacityController,
                    decoration: const InputDecoration(
                      labelText: 'Opacity (0-1)',
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                    ),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    onChanged: (value) {
                      final parsed = double.tryParse(value);
                      if (parsed != null && parsed >= 0.0 && parsed <= 1.0) {
                        setState(() => opacityValue = parsed);
                      }
                    },
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _windDirectionController,
                      decoration: const InputDecoration(
                        labelText: 'Wind Direction (°)',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: _windVelocityController,
                      decoration: const InputDecoration(
                        labelText: 'Wind Velocity (m/s)',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context, {
              'name': _nameController.text,
              'lat': double.tryParse(_latController.text),
              'lng': double.tryParse(_lngController.text),
              'radius': double.tryParse(_radiusController.text),
              'color': _colorController.text,
              'stroke_color': _strokeColorController.text,
              'opacity': double.tryParse(_opacityController.text) ?? 0.5,
              'wind_direction': double.tryParse(_windDirectionController.text),
              'wind_velocity': double.tryParse(_windVelocityController.text),
            });
          },
          child: const Text('Add'),
        ),
      ],
    );
  }
}


// Layer Management Dialog for Admin
class _LayerManagementDialog extends StatefulWidget {
  final List<MapLayer> mapLayers;
  final int projectId;
  final int unitId;
  final int scenarioId;
  final VoidCallback onUpdate;

  const _LayerManagementDialog({
    required this.mapLayers,
    required this.projectId,
    required this.unitId,
    required this.scenarioId,
    required this.onUpdate,
  });

  @override
  State<_LayerManagementDialog> createState() => _LayerManagementDialogState();
}

class _LayerManagementDialogState extends State<_LayerManagementDialog> {
  final Map<int, TextEditingController> _nameControllers = {};
  final Map<int, double> _opacityValues = {};
  final Map<int, TextEditingController> _zIndexControllers = {};
  final Map<int, bool> _visibilityValues = {};

  @override
  void initState() {
    super.initState();
    for (var layer in widget.mapLayers) {
      _nameControllers[layer.id] = TextEditingController(text: layer.name ?? '');
      _opacityValues[layer.id] = layer.opacity ?? 1.0;
      _zIndexControllers[layer.id] = TextEditingController(text: (layer.zIndex ?? 0).toString());
      _visibilityValues[layer.id] = layer.isVisible;
    }
  }

  @override
  void dispose() {
    for (var controller in _nameControllers.values) {
      controller.dispose();
    }
    for (var controller in _zIndexControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _updateLayer(MapLayer layer) async {
    try {
      final apiService = ApiService();
      final response = await apiService.put(
        '${ApiConstants.scenario(widget.projectId, widget.unitId, widget.scenarioId)}/map-layers/${layer.id}',
        data: {
          'name': _nameControllers[layer.id]?.text ?? layer.name,
          'opacity': _opacityValues[layer.id] ?? layer.opacity ?? 1.0,
          'z_index': int.tryParse(_zIndexControllers[layer.id]?.text ?? '') ?? layer.zIndex ?? 0,
          'is_visible': _visibilityValues[layer.id] ?? layer.isVisible,
        },
      );

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Layer updated successfully')),
          );
          widget.onUpdate();
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error updating layer: $e')),
        );
      }
    }
  }

  String _getLayerTypeLabel(String layerType) {
    switch (layerType) {
      case 'layout':
        return 'Layout Images';
      case 'equipment':
        return 'Equipment';
      case 'escape_route':
        return 'Escape Routes';
      case 'risk_zone':
        return 'Risk Zones';
      default:
        return layerType;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return Dialog(
      child: Container(
        width: isMobile ? double.maxFinite : 600,
        height: isMobile ? MediaQuery.of(context).size.height * 0.8 : 600,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Layer Management',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const Divider(),
            Expanded(
              child: widget.mapLayers.isEmpty
                  ? const Center(child: Text('No layers available'))
                  : ListView.builder(
                      itemCount: widget.mapLayers.length,
                      itemBuilder: (context, index) {
                        final layer = widget.mapLayers[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        _getLayerTypeLabel(layer.layerType),
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    Switch(
                                      value: _visibilityValues[layer.id] ?? layer.isVisible,
                                      onChanged: (value) {
                                        setState(() {
                                          _visibilityValues[layer.id] = value;
                                        });
                                        _updateLayer(layer);
                                      },
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                TextField(
                                  controller: _nameControllers[layer.id],
                                  decoration: const InputDecoration(
                                    labelText: 'Layer Name',
                                    border: OutlineInputBorder(),
                                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                                  ),
                                  onChanged: (_) => _updateLayer(layer),
                                ),
                                const SizedBox(height: 12),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Opacity: ${((_opacityValues[layer.id] ?? layer.opacity ?? 1.0) * 100).toStringAsFixed(0)}%',
                                      style: const TextStyle(fontWeight: FontWeight.w500),
                                    ),
                                    Slider(
                                      value: _opacityValues[layer.id] ?? layer.opacity ?? 1.0,
                                      min: 0.0,
                                      max: 1.0,
                                      divisions: 100,
                                      label: '${((_opacityValues[layer.id] ?? layer.opacity ?? 1.0) * 100).toStringAsFixed(0)}%',
                                      onChanged: (value) {
                                        setState(() {
                                          _opacityValues[layer.id] = value;
                                        });
                                        _updateLayer(layer);
                                      },
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                TextField(
                                  controller: _zIndexControllers[layer.id],
                                  decoration: const InputDecoration(
                                    labelText: 'Z-Index (Layer Order)',
                                    border: OutlineInputBorder(),
                                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                                    helperText: 'Higher number = on top',
                                  ),
                                  keyboardType: TextInputType.number,
                                  onChanged: (_) => _updateLayer(layer),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }
}

class _LayoutImageEditDialog extends StatefulWidget {
  final Map<String, dynamic> layoutLayer;
  final int projectId;
  final int unitId;
  final int scenarioId;
  final VoidCallback onUpdate;

  const _LayoutImageEditDialog({
    required this.layoutLayer,
    required this.projectId,
    required this.unitId,
    required this.scenarioId,
    required this.onUpdate,
  });

  @override
  State<_LayoutImageEditDialog> createState() => _LayoutImageEditDialogState();
}

class _LayoutImageEditDialogState extends State<_LayoutImageEditDialog> {
  late TextEditingController _latController;
  late TextEditingController _lngController;
  late TextEditingController _scaleXController;
  late TextEditingController _scaleYController;
  late TextEditingController _rotationController;
  late TextEditingController _zIndexController;
  late double _opacity;
  bool _isUpdating = false;

  @override
  void initState() {
    super.initState();
    _latController = TextEditingController(
      text: widget.layoutLayer['position_lat']?.toString() ?? '0.0',
    );
    _lngController = TextEditingController(
      text: widget.layoutLayer['position_lng']?.toString() ?? '0.0',
    );
    _scaleXController = TextEditingController(
      text: (widget.layoutLayer['scale_x'] ?? 1.0).toString(),
    );
    _scaleYController = TextEditingController(
      text: (widget.layoutLayer['scale_y'] ?? 1.0).toString(),
    );
    _rotationController = TextEditingController(
      text: (widget.layoutLayer['rotation'] ?? 0.0).toString(),
    );
    
    // Get z_index from map_layer
    final mapLayer = widget.layoutLayer['map_layer'] as Map<String, dynamic>?;
    _zIndexController = TextEditingController(
      text: (mapLayer?['z_index'] ?? 0).toString(),
    );
    
    _opacity = widget.layoutLayer['opacity'] != null
        ? double.tryParse(widget.layoutLayer['opacity'].toString()) ?? 0.8
        : (mapLayer?['opacity'] != null
            ? double.tryParse(mapLayer!['opacity'].toString()) ?? 0.8
            : 0.8);
  }

  @override
  void dispose() {
    _latController.dispose();
    _lngController.dispose();
    _scaleXController.dispose();
    _scaleYController.dispose();
    _rotationController.dispose();
    _zIndexController.dispose();
    super.dispose();
  }

  Future<void> _updateLayoutImage() async {
    if (_isUpdating) return;

    setState(() {
      _isUpdating = true;
    });

    try {
      final apiService = ApiService();
      
      // Update layout layer properties
      final response = await apiService.put(
        '${ApiConstants.scenario(widget.projectId, widget.unitId, widget.scenarioId)}/map-layers/layouts/${widget.layoutLayer['id']}',
        data: {
          'position_lat': double.tryParse(_latController.text),
          'position_lng': double.tryParse(_lngController.text),
          'scale_x': double.tryParse(_scaleXController.text),
          'scale_y': double.tryParse(_scaleYController.text),
          'rotation': double.tryParse(_rotationController.text),
          'is_visible': widget.layoutLayer['is_visible'] ?? true,
        },
      );

      // Update map layer z-index and opacity
      final mapLayerId = widget.layoutLayer['map_layer_id'];
      if (mapLayerId != null) {
        await apiService.put(
          '${ApiConstants.scenario(widget.projectId, widget.unitId, widget.scenarioId)}/map-layers/$mapLayerId',
          data: {
            'z_index': int.tryParse(_zIndexController.text),
            'opacity': _opacity,
          },
        );
      }

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Layout image updated successfully')),
          );
          widget.onUpdate();
          Navigator.pop(context);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error updating layout image: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isUpdating = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;
    
    return AlertDialog(
      title: const Text('Edit Layout Image'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: isMobile ? double.maxFinite : 500,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 8),
              TextField(
                controller: _latController,
                decoration: const InputDecoration(
                  labelText: 'Latitude',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _lngController,
                decoration: const InputDecoration(
                  labelText: 'Longitude',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _scaleXController,
                      decoration: const InputDecoration(
                        labelText: 'Scale X',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: _scaleYController,
                      decoration: const InputDecoration(
                        labelText: 'Scale Y',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _rotationController,
                decoration: const InputDecoration(
                  labelText: 'Rotation (degrees)',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _zIndexController,
                decoration: const InputDecoration(
                  labelText: 'Z-Index (Layer Order)',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                  helperText: 'Higher number = on top',
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Opacity: ${(_opacity * 100).toStringAsFixed(0)}%',
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  Slider(
                    value: _opacity,
                    min: 0.0,
                    max: 1.0,
                    divisions: 100,
                    label: '${(_opacity * 100).toStringAsFixed(0)}%',
                    onChanged: (value) {
                      setState(() {
                        _opacity = value;
                      });
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _isUpdating ? null : () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _isUpdating ? null : _updateLayoutImage,
          child: _isUpdating
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Update'),
        ),
      ],
    );
  }
}