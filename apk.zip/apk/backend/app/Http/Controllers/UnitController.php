<?php

namespace App\Http\Controllers;

use App\Models\Unit;
use App\Models\Project;
use Illuminate\Http\Request;

class UnitController extends Controller
{
    public function index(Request $request, $projectId)
    {
        $project = Project::with('assignedUsers')->findOrFail($projectId);

        // Check permission - admin, owner, or assigned user can view
        $canView = $request->user()->hasRole('admin') 
            || $project->user_id === $request->user()->id
            || $project->assignedUsers->contains($request->user()->id);

        if (!$canView) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $units = Unit::where('project_id', $projectId)
            ->with(['scenarios'])
            ->get();

        return response()->json([
            'success' => true,
            'data' => $units,
        ]);
    }

    public function store(Request $request, $projectId)
    {
        $project = Project::findOrFail($projectId);

        // Only admin or project owner can create units
        if (!$request->user()->hasRole('admin') && $project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin or project owner can create units'
            ], 403);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $unit = Unit::create([
            'project_id' => $projectId,
            'name' => $request->name,
            'description' => $request->description,
        ]);

        return response()->json([
            'success' => true,
            'data' => $unit->load('project', 'scenarios'),
            'message' => 'Unit created successfully'
        ], 201);
    }

    public function show(Request $request, $projectId, $id)
    {
        $unit = Unit::with(['project.assignedUsers', 'scenarios'])->findOrFail($id);

        // Check permission - admin, owner, or assigned user can view
        $canView = $request->user()->hasRole('admin') 
            || $unit->project->user_id === $request->user()->id
            || $unit->project->assignedUsers->contains($request->user()->id);

        if (!$canView) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        return response()->json([
            'success' => true,
            'data' => $unit,
        ]);
    }

    public function update(Request $request, $projectId, $id)
    {
        $unit = Unit::with('project')->findOrFail($id);

        // Only admin or project owner can update units (users can only edit scenarios)
        if (!$request->user()->hasRole('admin') && $unit->project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin or project owner can update units'
            ], 403);
        }

        $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $unit->update($request->only(['name', 'description']));

        return response()->json([
            'success' => true,
            'data' => $unit->load('project', 'scenarios'),
            'message' => 'Unit updated successfully'
        ]);
    }

    public function destroy(Request $request, $projectId, $id)
    {
        $unit = Unit::with('project')->findOrFail($id);

        // Only admin or project owner can delete units
        if (!$request->user()->hasRole('admin') && $unit->project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin or project owner can delete units'
            ], 403);
        }

        $unit->delete();

        return response()->json([
            'success' => true,
            'message' => 'Unit deleted successfully'
        ]);
    }
}
