# XAMPP Install Guide - Sabse Aasan Tarika

## 🚀 XAMPP Kya Hai?

XAMPP ek package hai jo sab kuch ek saath deta hai:
- ✅ PHP
- ✅ MySQL
- ✅ phpMyAdmin
- ✅ Apache Server

**Ye backend setup ke liye perfect hai!**

## 📥 Download & Install

### Step 1: Download
1. Visit: https://www.apachefriends.org/
2. Click "Download" (Windows version)
3. Download latest version (PHP 8.1+ recommended)

### Step 2: Install
1. Run downloaded `.exe` file
2. Click "Next" through installer
3. **Important:** Install to `C:\xampp` (default)
4. Complete installation

### Step 3: Start Services
1. Open XAMPP Control Panel
2. Start **Apache**
3. Start **MySQL**

## ✅ Verify Installation

### Check PHP
```bash
php -v
```
Should show PHP version 8.1 or higher

### Check MySQL
- Open: http://localhost/phpmyadmin
- Should show phpMyAdmin interface

## 🎯 Ab Backend Setup

### Step 1: Install Composer
1. Download: https://getcomposer.org/download/
2. Run `Composer-Setup.exe`
3. **Important:** Select PHP from XAMPP: `C:\xampp\php\php.exe`
4. Complete installation

### Step 2: Run Backend Setup
```powershell
cd C:\Users\ah516\Desktop\apk\backend
.\SETUP_BACKEND.ps1
```

### Step 3: Create Database
1. Open: http://localhost/phpmyadmin
2. Click "New"
3. Database name: `plant_layout`
4. Collation: `utf8mb4_unicode_ci`
5. Click "Create"

### Step 4: Edit .env
Open `backend/.env` and set:
```env
DB_PASSWORD=
```
(Leave empty if MySQL has no password)

### Step 5: Complete Setup
```bash
cd backend
php artisan key:generate
php artisan migrate
php artisan db:seed
php artisan storage:link
php artisan serve
```

## ✅ That's It!

Backend ab `http://localhost:8000` par chalega!

## 🐛 Common Issues

### Port 80 Already in Use
**Solution:**
- XAMPP Control Panel mein Apache ke saamne "Config" click karo
- `httpd.conf` open karo
- `Listen 80` ko `Listen 8080` change karo
- Apache restart karo

### MySQL Won't Start
**Solution:**
- Port 3306 check karo (kisi aur service use kar rahi ho)
- XAMPP Control Panel mein MySQL ke saamne "Config" click karo
- Port change karo ya service stop karo

### Composer PHP Not Found
**Solution:**
- Composer install ke time XAMPP PHP path select karo: `C:\xampp\php\php.exe`

---

**XAMPP install karo, phir setup script run karo!** 🚀
