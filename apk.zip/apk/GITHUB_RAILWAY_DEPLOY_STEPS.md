# GitHub + Railway Deployment - Complete Step by Step Guide 🚀

## Overview
Yeh guide aapko batayega ke kaise aap apne project ko GitHub pe push karke Railway pe deploy kar sakte hain.

---

## 📋 Prerequisites Checklist

- [ ] Git installed hai (https://git-scm.com/download/win)
- [ ] GitHub account hai
- [ ] Railway account hai (free - https://railway.app)
- [ ] Project code ready hai

---

## Part 1: GitHub Pe Code Push Karna

### Step 1: Git Install Check Karo

**Windows PowerShell mein:**
```powershell
git --version
```

Agar error aaye to:
1. https://git-scm.com/download/win pe jao
2. Download karo aur install karo
3. Computer restart karo (recommended)

### Step 2: Git Repository Initialize Karo

**Terminal mein project folder mein jao:**
```powershell
cd c:\Users\ah516\Desktop\apk
```

**Git initialize karo:**
```powershell
git init
```

### Step 3: .gitignore File Check Karo

**Agar .gitignore nahi hai, to create karo:**

`.gitignore` file mein yeh add karo:
```
# Laravel
backend/.env
backend/vendor/
backend/storage/*.key
backend/bootstrap/cache/*
backend/storage/framework/cache/*
backend/storage/framework/sessions/*
backend/storage/framework/views/*
backend/storage/logs/*

# Flutter
frontend/.dart_tool/
frontend/.flutter-plugins
frontend/.flutter-plugins-dependencies
frontend/.packages
frontend/.pub-cache/
frontend/.pub/
frontend/build/
frontend/.flutter/
frontend/.idea/
frontend/*.iml
frontend/.metadata
frontend/.fvm/

# OS
.DS_Store
Thumbs.db
*.log

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
```

### Step 4: Files Add Karo

**Sab files staging area mein add karo:**
```powershell
git add .
```

**Status check karo:**
```powershell
git status
```

### Step 5: First Commit Karo

```powershell
git commit -m "Initial commit - Plant Layout Viewer project"
```

### Step 6: GitHub Pe Repository Banao

1. **Browser mein jao:** https://github.com
2. **Login karo** (ya sign up karo)
3. **Top right corner mein "+" icon click karo**
4. **"New repository" select karo**

### Step 7: Repository Settings

**Repository create karte waqt:**
- **Repository name:** `plant-layout-viewer` (ya koi bhi naam)
- **Description:** (Optional) "Plant Layout and Risk Assessment Viewer"
- **Public ya Private:** Public (recommended for free tier)
- **❌ "Initialize with README" mat check karo** (agar code already hai)
- **❌ "Add .gitignore" mat select karo** (humne already banaya hai)
- **❌ "Choose a license" mat select karo**

**"Create repository" button click karo**

### Step 8: GitHub Repository URL Copy Karo

**Repository create hone ke baad, GitHub aapko URL dega:**
```
https://github.com/YOUR_USERNAME/plant-layout-viewer.git
```

**Ya manually:**
- Repository page pe jao
- **Green "Code" button click karo**
- **HTTPS URL copy karo** (e.g., `https://github.com/username/repo.git`)

### Step 9: Local Repository Ko GitHub Se Connect Karo

**Terminal mein:**
```powershell
git remote add origin https://github.com/YOUR_USERNAME/plant-layout-viewer.git
```

**Replace karo:**
- `YOUR_USERNAME` = Aapka GitHub username
- `plant-layout-viewer` = Aapka repository name

**Verify karo:**
```powershell
git remote -v
```

**Output dikhna chahiye:**
```
origin  https://github.com/YOUR_USERNAME/plant-layout-viewer.git (fetch)
origin  https://github.com/YOUR_USERNAME/plant-layout-viewer.git (push)
```

### Step 10: Code Push Karo

**Main branch set karo:**
```powershell
git branch -M main
```

**Code push karo:**
```powershell
git push -u origin main
```

**Agar pehli baar ho to:**
- GitHub username enter karo
- Password mat dalo (GitHub ab passwords accept nahi karta)
- **Personal Access Token** chahiye hoga

### Step 11: GitHub Personal Access Token (Agar Chahiye)

**Agar password error aaye:**

1. **GitHub Settings mein jao:**
   - Profile → Settings → Developer settings → Personal access tokens → Tokens (classic)

2. **"Generate new token" click karo**

3. **Settings:**
   - **Note:** "Railway Deployment" (ya koi naam)
   - **Expiration:** 90 days (ya custom)
   - **Scopes:** `repo` check karo (full control)

4. **"Generate token" click karo**

5. **Token copy karo** (sirf ek baar dikhega!)

6. **Push command run karo:**
   ```powershell
   git push -u origin main
   ```
   - Username: Aapka GitHub username
   - Password: **Token paste karo** (password ki jagah)

**✅ Code GitHub pe push ho gaya!**

---

## Part 2: Railway Pe Deploy Karna

### Step 1: Railway Account Banao

1. **Browser mein jao:** https://railway.app
2. **"Start a New Project" ya "Login" click karo**
3. **"Sign up with GitHub" select karo** (recommended)
4. **GitHub se authorize karo**
5. **Railway dashboard open ho jayega**

### Step 2: New Project Create Karo

1. **Railway dashboard mein:**
   - **"New Project" button click karo** (top right)

2. **"Deploy from GitHub repo" select karo**

3. **GitHub authorize karo** (agar pehli baar ho):
   - **"Configure GitHub App" click karo**
   - **Repositories select karo** (ya "All repositories")
   - **"Install" click karo**

### Step 3: Repository Select Karo

1. **Repository list mein aapka repository dikhega**
2. **"plant-layout-viewer" (ya aapka repo name) click karo**

### Step 4: Railway Automatic Setup

**Railway automatically:**
- ✅ Laravel project detect karega
- ✅ Dependencies install karega
- ✅ Build start kar dega

**Lekin humein manually configure karna padega!**

### Step 5: Service Settings Configure Karo

**Service pe click karo (aapka project name):**

1. **"Settings" tab mein jao**

2. **Root Directory set karo:**
   - **"Root Directory" field mein:** `backend`
   - **Save karo**

3. **Start Command set karo:**
   - **"Deploy" tab mein jao**
   - **"Start Command" field mein:**
     ```bash
     php artisan serve --host=0.0.0.0 --port=$PORT
     ```
   - **Save karo**

### Step 6: Database Add Karo

1. **Project dashboard mein:**
   - **"New" button click karo** (top right)
   - **"Database" select karo**
   - **"Add MySQL" click karo** (ya PostgreSQL)

2. **Database automatically create ho jayega**

3. **Database service pe click karo**

4. **"Connect" tab mein:**
   - **Connection details copy karo** (baad mein use hoga)

### Step 7: Environment Variables Set Karo

**Backend service pe jao → "Variables" tab:**

**Add karo yeh variables:**

```
APP_NAME=Plant Layout API
APP_ENV=production
APP_DEBUG=false
APP_URL=https://your-app.railway.app
```

**Database variables (Database service se copy karo):**
```
DB_CONNECTION=mysql
DB_HOST=YOUR_DB_HOST
DB_PORT=3306
DB_DATABASE=YOUR_DB_NAME
DB_USERNAME=YOUR_DB_USER
DB_PASSWORD=YOUR_DB_PASSWORD
```

**Laravel key generate karo:**
```
APP_KEY=base64:YOUR_KEY_HERE
```

**CORS allow karo:**
```
CORS_ALLOWED_ORIGINS=*
```

### Step 8: Build Command Set Karo

**"Deploy" tab mein:**

**Build Command:**
```bash
cd backend && composer install --no-dev --optimize-autoloader && php artisan key:generate --force
```

**Start Command:**
```bash
php artisan migrate --force && php artisan db:seed --force && php artisan serve --host=0.0.0.0 --port=$PORT
```

**Ya separate commands:**

**Build Command:**
```bash
cd backend && composer install --no-dev --optimize-autoloader
```

**Start Command:**
```bash
php artisan key:generate --force && php artisan migrate --force && php artisan db:seed --force && php artisan serve --host=0.0.0.0 --port=$PORT
```

### Step 9: Deploy Trigger Karo

1. **"Deployments" tab mein jao**
2. **"Redeploy" button click karo** (ya automatic deploy ho jayega)

### Step 10: Deploy Status Check Karo

1. **"Deployments" tab mein:**
   - **Build logs dekh sakte ho**
   - **Status check karo:**
     - 🟡 **Building** = In progress
     - 🟢 **Active** = Success!
     - 🔴 **Failed** = Error (logs check karo)

2. **"Logs" tab mein:**
   - **Real-time logs dekh sakte ho**
   - **Errors check karo**

### Step 11: URL Milne Ke Baad

**Deploy complete hone ke baad:**

1. **Service pe click karo**
2. **"Settings" tab mein:**
   - **"Generate Domain" click karo** (ya automatic mil jayega)
   - **URL copy karo:** `https://your-app.railway.app`

3. **API URL hoga:** `https://your-app.railway.app/api`

---

## Part 3: API URL Update Karna

### Step 1: API URL Copy Karo

**Railway se URL:** `https://your-app.railway.app/api`

### Step 2: Local Code Mein Update Karo

**File:** `frontend/lib/core/constants/api_constants.dart`

**Line 15 update karo:**
```dart
static const String baseUrl = 'https://your-app.railway.app/api';
```

### Step 3: GitHub Pe Push Karo

```powershell
cd c:\Users\ah516\Desktop\apk
git add frontend/lib/core/constants/api_constants.dart
git commit -m "Update API URL to Railway"
git push
```

**Ya script use karo:**
```powershell
.\UPDATE_API_URL.ps1 -Url "https://your-app.railway.app/api"
```

---

## Part 4: APK Rebuild Karna

### Step 1: APK Build Karo

```powershell
cd c:\Users\ah516\Desktop\apk\frontend
flutter clean
flutter pub get
flutter build apk --release
```

**Ya script:**
```powershell
.\REBUILD_APK.ps1
```

### Step 2: APK Location

**APK file:**
```
frontend\build\app\outputs\flutter-apk\app-release.apk
```

---

## ✅ Complete Checklist

### GitHub:
- [ ] Git installed
- [ ] Repository initialized
- [ ] .gitignore created
- [ ] Files committed
- [ ] GitHub repository created
- [ ] Remote added
- [ ] Code pushed to GitHub

### Railway:
- [ ] Railway account created
- [ ] GitHub connected
- [ ] Repository selected
- [ ] Root directory set (`backend`)
- [ ] Build command set
- [ ] Start command set
- [ ] Database created
- [ ] Environment variables set
- [ ] Deploy successful
- [ ] URL received

### Local:
- [ ] API URL updated
- [ ] Code pushed to GitHub
- [ ] APK rebuilt
- [ ] APK tested

---

## 🆘 Troubleshooting

### Issue: Git Push Fail

**Error:** "Authentication failed"

**Solution:**
1. Personal Access Token use karo (password ki jagah)
2. Token expire ho gaya? Naya token generate karo

### Issue: Railway Deploy Fail

**Error:** "Build failed"

**Solution:**
1. **Logs check karo:**
   - "Deployments" → Latest deployment → "View Logs"
2. **Common issues:**
   - Root directory sahi hai? (`backend`)
   - Build command sahi hai?
   - Environment variables sahi hain?

### Issue: Database Connection Error

**Error:** "SQLSTATE[HY000] [2002]"

**Solution:**
1. Database service running hai?
2. Database variables sahi hain?
3. `DB_HOST` sahi hai? (Railway internal host use karo)

### Issue: API Not Accessible

**Error:** "Connection refused"

**Solution:**
1. Service active hai?
2. URL sahi hai? (`https://` use karo, `http://` nahi)
3. CORS settings check karo

---

## 📝 Important Notes

1. **Railway Free Tier:**
   - Monthly usage limit hai
   - Service sleep ho sakta hai agar inactive ho
   - Production ke liye paid plan better hai

2. **Database:**
   - MySQL ya PostgreSQL dono available hain
   - Connection details automatically environment variables mein add ho jayenge

3. **Automatic Deployments:**
   - GitHub pe push karne se automatically deploy ho jayega
   - Manual redeploy ki zaroorat nahi!

4. **Environment Variables:**
   - Sensitive data ko environment variables mein rakho
   - `.env` file mat commit karo GitHub pe

---

## 🎉 Success!

**Ab aapka project:**
- ✅ GitHub pe hosted hai
- ✅ Railway pe deployed hai
- ✅ Publicly accessible hai
- ✅ APK kahin se bhi chalega!

**Next Steps:**
1. APK rebuild karo
2. Device pe install karo
3. Test karo!

---

**Good luck! 🚀**
