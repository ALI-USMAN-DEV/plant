package com.plantlayout.plant_layout_viewer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
