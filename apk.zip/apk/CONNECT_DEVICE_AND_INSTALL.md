# Connect Device & Install APK - Step by Step 📱

## ⚠️ Current Status

**Device Status:** Not Connected
**APK Status:** Ready (57.01 MB)

## 📱 Step 1: Connect Android Device

### Enable USB Debugging:

1. **Enable Developer Options:**
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times
   - You'll see "You are now a developer!"

2. **Enable USB Debugging:**
   - Go to Settings → Developer Options
   - Enable "USB Debugging"
   - Enable "Install via USB" (if available)

3. **Connect Device:**
   - Connect Android device to computer via USB cable
   - On device, you'll see "Allow USB debugging?" prompt
   - Check "Always allow from this computer"
   - Tap "Allow"

4. **Verify Connection:**
   ```bash
   adb devices
   ```
   Should show your device ID

## 🚀 Step 2: Auto-Install Script

Once device is connected, run this command:

```bash
cd C:\Users\ah516\Desktop\apk\frontend
adb install -r build\app\outputs\flutter-apk\app-release.apk
```

## 🔄 Alternative: Use Auto-Install Script

I've created a script that will:
1. Wait for device connection
2. Automatically install APK
3. Launch the app

Run this:
```powershell
cd C:\Users\ah516\Desktop\apk
.\INSTALL_APK_AUTO.ps1
```

## 📋 Manual Installation Steps

If ADB doesn't work, use manual installation:

1. **Copy APK:**
   - Copy `frontend\build\app\outputs\flutter-apk\app-release.apk` to device
   - Via USB file transfer or email/cloud

2. **Install:**
   - Open file manager on device
   - Navigate to APK location
   - Tap APK file
   - Tap "Install"
   - Enable "Install from Unknown Sources" if prompted

## ✅ Verification

After installation, verify:

```bash
# Check if app is installed
adb shell pm list packages | Select-String plantlayout

# Launch app
adb shell am start -n com.plantlayout.viewer/.MainActivity
```

## 🐛 Troubleshooting

### Device Not Detected:
- Check USB cable (try different cable)
- Try different USB port
- Restart ADB: `adb kill-server && adb start-server`
- Check device shows "USB debugging connected"

### Installation Fails:
- Uninstall previous version first
- Check device has enough storage
- Enable "Install via USB" in Developer Options

### App Won't Launch:
- Check backend server is running
- Verify API URL is correct
- Check app logs: `adb logcat | Select-String plantlayout`

---

**Connect your device and run the install command!** 📱
