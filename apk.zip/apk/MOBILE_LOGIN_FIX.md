# Mobile Login Issue Fix 🔧

## Problem
Mobile device se login karne par loader ghumta hai aur phir wapas login screen pe aa jata hai.

## Root Cause
**API URL issue!** `10.0.2.2` sirf Android **EMULATOR** ke liye hai. Physical device ke liye computer ka **real IP address** chahiye.

## Solution

### Step 1: Computer ka IP Address Find Karo

**Windows:**
```powershell
ipconfig
```
Look for "IPv4 Address" (usually something like `192.168.x.x` or `10.x.x.x`)

**Or run this:**
```powershell
Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" }
```

### Step 2: API URL Update Karo

File: `frontend/lib/core/constants/api_constants.dart`

**Change this:**
```dart
static const String baseUrl = 'http://10.0.2.2:8000/api';
```

**To this (apna IP use karo):**
```dart
static const String baseUrl = 'http://192.168.1.100:8000/api';  // Apna IP yahan dalo
```

### Step 3: Backend Server Check Karo

Backend server chal raha hai na? Check karo:
```bash
cd backend
php artisan serve --host=0.0.0.0 --port=8000
```

**Important:** `--host=0.0.0.0` zaroori hai taaki device se access ho sake!

### Step 4: Firewall Check Karo

Windows Firewall backend port (8000) ko block na kar raha ho. Agar block hai to allow karo.

### Step 5: Network Check Karo

- Device aur computer **same WiFi network** pe hain?
- Device se browser mein `http://YOUR_IP:8000/api` open karo - kuch response aana chahiye

### Step 6: APK Rebuild Karo

API URL change karne ke baad APK rebuild karna padega:

```bash
cd frontend
flutter clean
flutter pub get
flutter build apk --release
```

## Quick Test

1. Computer pe backend server start karo:
   ```bash
   cd backend
   php artisan serve --host=0.0.0.0 --port=8000
   ```

2. Mobile device se browser mein test karo:
   ```
   http://YOUR_COMPUTER_IP:8000/api/login
   ```
   
   Agar "Method Not Allowed" error aaye to sahi hai (POST chahiye, GET nahi)

3. APK install karo aur login try karo

## Common Issues

### Issue: "Connection refused" or "Network error"
**Solution:** 
- Backend server `0.0.0.0` pe chal raha hai?
- Firewall allow kar raha hai?
- Same network pe hain?

### Issue: "401 Unauthorized"
**Solution:** 
- Credentials sahi hain? (`admin@example.com` / `password`)
- Backend database seeded hai?

### Issue: Still going back to login
**Solution:**
- Check logs: `flutter run` karke console check karo
- Error message dekhne ke liye debug mode on karo

## Updated Files

1. ✅ `api_constants.dart` - Login endpoint fixed
2. ✅ `auth_provider.dart` - Better error handling added
3. ✅ `login_screen.dart` - Better error messages

---

**Ab mobile se login kaam karega!** 🎉
