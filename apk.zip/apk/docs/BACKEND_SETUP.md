# Backend Setup Guide (Laravel)

## Prerequisites

- PHP >= 8.1
- Composer
- MySQL >= 5.7
- Node.js & NPM (for asset compilation)

## Installation Steps

### 1. Install Dependencies

```bash
cd backend
composer install
```

### 2. Environment Configuration

Copy the `.env.example` file to `.env`:

```bash
cp .env.example .env
```

Edit `.env` and configure:

```env
APP_NAME="Plant Layout API"
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost:8000

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=plant_layout
DB_USERNAME=root
DB_PASSWORD=your_password

GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here
```

### 3. Generate Application Key

```bash
php artisan key:generate
```

### 4. Create Database

Create a MySQL database:

```sql
CREATE DATABASE plant_layout CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 5. Run Migrations

```bash
php artisan migrate
```

### 6. Seed Database (Optional)

```bash
php artisan db:seed
```

This creates:
- Admin user: `admin@example.com` / `password`
- Regular user: `user@example.com` / `password`
- Sample project with 50 scenarios

### 7. Create Storage Link

```bash
php artisan storage:link
```

### 8. Start Development Server

```bash
php artisan serve
```

The API will be available at `http://localhost:8000`

## API Endpoints

### Authentication
- `POST /api/register` - Register new user
- `POST /api/login` - Login
- `POST /api/logout` - Logout
- `GET /api/me` - Get current user

### Projects
- `GET /api/projects` - List projects
- `POST /api/projects` - Create project
- `GET /api/projects/{id}` - Get project
- `PUT /api/projects/{id}` - Update project
- `DELETE /api/projects/{id}` - Delete project

### Units
- `GET /api/projects/{projectId}/units` - List units
- `POST /api/projects/{projectId}/units` - Create unit
- `GET /api/projects/{projectId}/units/{id}` - Get unit
- `PUT /api/projects/{projectId}/units/{id}` - Update unit
- `DELETE /api/projects/{projectId}/units/{id}` - Delete unit

### Scenarios
- `GET /api/projects/{projectId}/units/{unitId}/scenarios` - List scenarios
- `POST /api/projects/{projectId}/units/{unitId}/scenarios` - Create scenario
- `GET /api/projects/{projectId}/units/{unitId}/scenarios/{id}` - Get scenario
- `PUT /api/projects/{projectId}/units/{unitId}/scenarios/{id}` - Update scenario
- `DELETE /api/projects/{projectId}/units/{unitId}/scenarios/{id}` - Delete scenario

### Map Layers
- `POST /api/projects/{projectId}/units/{unitId}/scenarios/{scenarioId}/map-layers/layouts` - Upload layout image
- `POST /api/projects/{projectId}/units/{unitId}/scenarios/{scenarioId}/map-layers/equipment` - Add equipment
- `POST /api/projects/{projectId}/units/{unitId}/scenarios/{scenarioId}/map-layers/escape-routes` - Add escape route
- `POST /api/projects/{projectId}/units/{unitId}/scenarios/{scenarioId}/map-layers/risk-zones` - Add risk zone

### Reports
- `POST /api/projects/{projectId}/units/{unitId}/reports/generate` - Generate PDF report
- `GET /api/projects/{projectId}/units/{unitId}/reports` - List reports
- `GET /api/projects/{projectId}/units/{unitId}/reports/{id}/download` - Download report

## CORS Configuration

Update `config/cors.php` if needed for your frontend domain.

## File Storage

Files are stored in:
- `storage/app/public/layouts/` - Layout images
- `storage/app/public/equipment/` - Equipment icons
- `storage/app/public/documents/` - Documents
- `storage/app/public/reports/` - Generated PDFs

Make sure these directories are writable:
```bash
chmod -R 775 storage
chmod -R 775 bootstrap/cache
```
