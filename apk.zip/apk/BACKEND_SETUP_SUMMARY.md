# Backend Setup - Complete Summary ✅

## 🚀 Sabse Aasan Tarika (Recommended)

### Option 1: Automated Script (Sabse Aasan)

**PowerShell mein:**
```powershell
cd backend
.\SETUP_BACKEND.ps1
```

**Ya CMD mein:**
```cmd
cd backend
SETUP_BACKEND.bat
```

Ye script automatically:
- ✅ Composer check karega
- ✅ Dependencies install karega
- ✅ .env file create karega
- ✅ App key generate karega
- ✅ Migrations run karega
- ✅ Storage link create karega

**Aapko sirf:**
1. Database create karna hoga (phpMyAdmin mein)
2. `.env` file mein password set karna hoga

### Option 2: Manual Setup

#### Step 1: Install Composer (Agar nahi hai)
- Download: https://getcomposer.org/download/
- Windows: `Composer-Setup.exe` install karo

#### Step 2: Install Dependencies
```bash
cd backend
composer install
```

#### Step 3: Create .env File
```bash
# .env.example se copy karo (agar hai)
copy .env.example .env

# Ya manually create karo with:
DB_DATABASE=plant_layout
DB_USERNAME=root
DB_PASSWORD=your_password
```

#### Step 4: Generate App Key
```bash
php artisan key:generate
```

#### Step 5: Create Database
**phpMyAdmin mein:**
1. http://localhost/phpmyadmin
2. "New" → Database name: `plant_layout`
3. Collation: `utf8mb4_unicode_ci`
4. "Create"

#### Step 6: Run Migrations
```bash
php artisan migrate
```

#### Step 7: Seed Database (Optional)
```bash
php artisan db:seed
```
Creates: Admin user aur sample data

#### Step 8: Storage Link
```bash
php artisan storage:link
```

#### Step 9: Start Server
```bash
php artisan serve
```

**Backend ab `http://localhost:8000` par chalega!**

## 📋 Checklist

- [ ] Composer installed
- [ ] `composer install` done
- [ ] `.env` file created
- [ ] Database password set in `.env`
- [ ] `php artisan key:generate` done
- [ ] Database `plant_layout` created
- [ ] `php artisan migrate` done
- [ ] `php artisan db:seed` done (optional)
- [ ] `php artisan storage:link` done
- [ ] `php artisan serve` running

## ✅ Verify

Browser mein: `http://localhost:8000`

Agar response mil jaye to sab theek hai!

## 🐛 Common Issues

### Issue 1: Composer Not Found
**Solution:**
- Install Composer: https://getcomposer.org/
- Verify: `composer --version`

### Issue 2: PHP Not Found
**Solution:**
- Install PHP 8.1+
- Or use XAMPP/WAMP
- Verify: `php -v`

### Issue 3: Database Connection Failed
**Solution:**
- MySQL running hai check karo
- `.env` mein credentials sahi hain check karo
- Database `plant_layout` create kiya hai check karo

### Issue 4: Migration Failed
**Solution:**
```bash
# Fresh start
php artisan migrate:fresh
php artisan db:seed
```

## 📁 Files Created

Main ne ye files banaye hain:
- ✅ `backend/SETUP_BACKEND.ps1` - PowerShell script
- ✅ `backend/SETUP_BACKEND.bat` - Batch script
- ✅ `backend/QUICK_SETUP.md` - Quick guide
- ✅ `backend/README_SETUP.md` - Detailed guide
- ✅ `BACKEND_SETUP_HINDI.md` - Hindi guide

## 🎯 Next Steps

Backend setup complete hone ke baad:

1. **Frontend Configure**: 
   - Edit `frontend/lib/core/constants/api_constants.dart`
   - Set API URL: `http://10.0.2.2:8000/api` (emulator)
   - Or `http://YOUR_IP:8000/api` (device)

2. **Frontend Run**:
   ```bash
   cd frontend
   flutter run
   ```

3. **Test**:
   - Login: `admin@example.com` / `password`
   - Sab features test karo!

## 💡 Tips

- **XAMPP Use Karo**: Agar PHP/MySQL setup nahi hai to XAMPP install karo
- **phpMyAdmin**: Database create karne ke liye easy hai
- **Script Use Karo**: Automated script sabse aasan hai

---

**Ab setup script run karo ya manual steps follow karo!** 🚀

**Agar koi issue aaye to batao, main help karunga!** 😊
