# Plant Layout Viewer - Setup Script (PowerShell)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Plant Layout Viewer - Setup Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check Backend
Write-Host "[1/8] Checking Backend..." -ForegroundColor Yellow
if (Test-Path "backend\composer.json") {
    Write-Host "✓ Backend found!" -ForegroundColor Green
} else {
    Write-Host "✗ ERROR: composer.json not found!" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Install Backend Dependencies
Write-Host "[2/8] Installing Backend Dependencies..." -ForegroundColor Yellow
Set-Location backend
if (Get-Command composer -ErrorAction SilentlyContinue) {
    Write-Host "Running: composer install" -ForegroundColor Cyan
    composer install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "✗ Composer install failed!" -ForegroundColor Red
        Write-Host "Please install Composer first: https://getcomposer.org/" -ForegroundColor Yellow
    } else {
        Write-Host "✓ Dependencies installed!" -ForegroundColor Green
    }
} else {
    Write-Host "⚠ Composer not found. Please install Composer first." -ForegroundColor Yellow
    Write-Host "Download from: https://getcomposer.org/" -ForegroundColor Yellow
}
Write-Host ""

# Create .env file
Write-Host "[3/8] Creating .env file..." -ForegroundColor Yellow
if (-not (Test-Path ".env")) {
    if (Test-Path ".env.example") {
        Copy-Item ".env.example" ".env"
        Write-Host "✓ .env file created from .env.example" -ForegroundColor Green
    } else {
        Write-Host "⚠ .env.example not found. Please create .env manually." -ForegroundColor Yellow
    }
} else {
    Write-Host "✓ .env file already exists" -ForegroundColor Green
}
Write-Host ""

# Generate App Key
Write-Host "[4/8] Generating App Key..." -ForegroundColor Yellow
if (Get-Command php -ErrorAction SilentlyContinue) {
    php artisan key:generate
    Write-Host "✓ App key generated!" -ForegroundColor Green
} else {
    Write-Host "⚠ PHP not found. Please install PHP first." -ForegroundColor Yellow
    Write-Host "Please run manually: php artisan key:generate" -ForegroundColor Yellow
}
Write-Host ""

# Database Setup
Write-Host "[5/8] Database Setup..." -ForegroundColor Yellow
Write-Host "Please create database: plant_layout" -ForegroundColor Cyan
Write-Host "Then run: php artisan migrate" -ForegroundColor Cyan
Write-Host ""

# Seed Database
Write-Host "[6/8] Seeding Database..." -ForegroundColor Yellow
Write-Host "Please run: php artisan db:seed" -ForegroundColor Cyan
Write-Host ""

# Storage Link
Write-Host "[7/8] Creating Storage Link..." -ForegroundColor Yellow
if (Get-Command php -ErrorAction SilentlyContinue) {
    php artisan storage:link
    Write-Host "✓ Storage link created!" -ForegroundColor Green
} else {
    Write-Host "⚠ Please run manually: php artisan storage:link" -ForegroundColor Yellow
}
Write-Host ""

# Frontend Setup
Set-Location ..\frontend
Write-Host "[8/8] Installing Frontend Dependencies..." -ForegroundColor Yellow
if (Test-Path "pubspec.yaml") {
    if (Get-Command flutter -ErrorAction SilentlyContinue) {
        Write-Host "Running: flutter pub get" -ForegroundColor Cyan
        flutter pub get
        if ($LASTEXITCODE -ne 0) {
            Write-Host "✗ Flutter pub get failed!" -ForegroundColor Red
        } else {
            Write-Host "✓ Frontend dependencies installed!" -ForegroundColor Green
        }
    } else {
        Write-Host "⚠ Flutter not found. Please install Flutter first." -ForegroundColor Yellow
    }
} else {
    Write-Host "✗ ERROR: pubspec.yaml not found!" -ForegroundColor Red
}
Write-Host ""

Set-Location ..
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "1. Configure .env file with database credentials" -ForegroundColor White
Write-Host "2. Create database: plant_layout" -ForegroundColor White
Write-Host "3. Run migrations: cd backend && php artisan migrate" -ForegroundColor White
Write-Host "4. Seed database: php artisan db:seed" -ForegroundColor White
Write-Host "5. Start backend: php artisan serve" -ForegroundColor White
Write-Host "6. Start frontend: cd frontend && flutter run" -ForegroundColor White
Write-Host ""
