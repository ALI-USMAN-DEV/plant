# Install & Test APK - Complete Guide 📱

## ✅ APK Build Complete

- **Location:** `frontend/build/app/outputs/flutter-apk/app-release.apk`
- **Size:** 57.0 MB
- **Status:** Ready to install

## 📱 Installation Methods

### Method 1: Via ADB (Recommended)

#### Prerequisites:
1. Android device connected via USB
2. USB debugging enabled
3. ADB installed and in PATH

#### Steps:
```bash
cd frontend
adb devices  # Verify device is connected
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

### Method 2: Manual Installation

1. **Copy APK to Device:**
   - Connect Android device via USB
   - Copy `frontend/build/app/outputs/flutter-apk/app-release.apk` to device
   - Or transfer via email/cloud storage

2. **Enable Unknown Sources:**
   - Go to Settings → Security
   - Enable "Install from Unknown Sources" or "Install Unknown Apps"
   - Select the file manager app you'll use

3. **Install APK:**
   - Open file manager on device
   - Navigate to APK location
   - Tap on `app-release.apk`
   - Tap "Install"
   - Wait for installation to complete

## 🔧 Configuration

### Update API URL for Physical Device

If installing on a physical Android device (not emulator), update API URL:

1. **Find your computer's IP address:**
   ```bash
   # Windows
   ipconfig
   
   # Look for IPv4 Address (e.g., 192.168.1.100)
   ```

2. **Update API Constants:**
   - Edit `frontend/lib/core/constants/api_constants.dart`
   - Change `baseUrl` from `http://10.0.2.2:8000/api` to `http://YOUR_IP:8000/api`
   - Example: `http://192.168.1.100:8000/api`

3. **Rebuild APK (if needed):**
   ```bash
   cd frontend
   flutter build apk --release
   ```

### For Emulator:
- Keep: `http://10.0.2.2:8000/api` (already configured)

### For Physical Device:
- Change to: `http://YOUR_COMPUTER_IP:8000/api`

## 🚀 Testing Checklist

### 1. Backend Setup
- [ ] Backend server running at `http://localhost:8000`
- [ ] Database connected and migrated
- [ ] API accessible from device/emulator

### 2. App Installation
- [ ] APK installed successfully
- [ ] App opens without crashes
- [ ] No permission errors

### 3. Authentication
- [ ] Login screen displays
- [ ] Can login with: `admin@example.com` / `password`
- [ ] Can register new user
- [ ] Logout works

### 4. Projects
- [ ] Projects list displays
- [ ] Can create new project
- [ ] Can edit/delete project
- [ ] Can view project details

### 5. Units
- [ ] Units list displays for project
- [ ] Can create new unit
- [ ] Can edit/delete unit
- [ ] Can navigate to scenarios

### 6. Scenarios
- [ ] Scenarios list displays for unit
- [ ] Can create new scenario
- [ ] Can edit/delete scenario
- [ ] Can open scenario detail

### 7. Map Tab
- [ ] Map displays with OpenStreetMap tiles
- [ ] Can upload layout image
- [ ] Can add equipment items
- [ ] Can draw escape routes
- [ ] Can create risk zones
- [ ] Layer visibility toggles work

### 8. Text Tab
- [ ] Rich text editor displays
- [ ] Can type and format text
- [ ] Can save text content
- [ ] Text persists after reload

### 9. Document Tab
- [ ] Documents list displays
- [ ] Can upload documents
- [ ] Can view/download documents
- [ ] Can delete documents

### 10. Table Tab
- [ ] Table displays
- [ ] Can add/edit/remove rows
- [ ] Can add/edit/remove columns
- [ ] Table data saves correctly

### 11. Reports
- [ ] Can generate report for unit
- [ ] Report includes all scenario data
- [ ] PDF downloads successfully
- [ ] Report content is accurate

## 🐛 Troubleshooting

### App Won't Install
- **Error:** "App not installed"
  - **Solution:** Uninstall previous version first, then reinstall
  - **Command:** `adb uninstall com.plantlayout.viewer`

### App Crashes on Launch
- **Check:** Backend server is running
- **Check:** API URL is correct for your device
- **Check:** Internet connection (for map tiles)
- **Check:** Permissions granted (Storage, Internet)

### Can't Connect to Backend
- **For Emulator:** Use `http://10.0.2.2:8000/api`
- **For Physical Device:** Use `http://YOUR_COMPUTER_IP:8000/api`
- **Check:** Firewall allows port 8000
- **Check:** Backend server is running
- **Check:** Device and computer on same network

### Maps Not Loading
- **Check:** Internet connection
- **Check:** OpenStreetMap tile server accessible
- **Check:** Network permissions in AndroidManifest.xml

### File Upload Not Working
- **Check:** Storage permissions granted
- **Check:** File size limits
- **Check:** Backend storage directory writable

## 📊 Test Results Template

```
Date: ___________
Device: ___________
Android Version: ___________
APK Version: 1.0.0+1

✅ Authentication: Pass/Fail
✅ Projects: Pass/Fail
✅ Units: Pass/Fail
✅ Scenarios: Pass/Fail
✅ Map Features: Pass/Fail
✅ Text Editor: Pass/Fail
✅ Documents: Pass/Fail
✅ Tables: Pass/Fail
✅ Reports: Pass/Fail

Notes:
_________________________________
_________________________________
```

## 🎯 Next Steps After Testing

1. **Fix any bugs found during testing**
2. **Optimize performance if needed**
3. **Create signed APK for distribution**
4. **Prepare for Play Store (if needed)**

---

**APK ready to install and test!** 🚀
