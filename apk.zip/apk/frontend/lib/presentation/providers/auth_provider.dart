import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:plant_layout_viewer/data/models/user_model.dart';
import 'package:plant_layout_viewer/data/services/api_service.dart';
import 'package:plant_layout_viewer/core/constants/api_constants.dart';
import 'package:dio/dio.dart';

class AuthProvider with ChangeNotifier {
  UserModel? _user;
  String? _token;
  bool _isLoading = false;

  UserModel? get user => _user;
  String? get token => _token;
  bool get isAuthenticated => _token != null && _user != null;
  bool get isLoading => _isLoading;
  bool get isAdmin => _user?.roles?.contains('admin') ?? false;

  AuthProvider() {
    _loadAuthData();
  }

  Future<void> _loadAuthData() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      _token = prefs.getString('auth_token');
      
      if (_token != null) {
        await fetchUser();
      }
    } catch (e) {
      _token = null;
      _user = null;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiService().post(
        ApiConstants.login,
        data: {
          'email': email,
          'password': password,
        },
      );
      
      // Debug: Print response for troubleshooting
      if (kDebugMode) {
        print('Login Response: ${response.statusCode}');
        print('Response Data: ${response.data}');
      }

      if (response.statusCode == 200 && response.data['success'] == true) {
        _token = response.data['data']['token'];
        _user = UserModel.fromJson(response.data['data']['user']);
        
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('auth_token', _token!);
        
        _isLoading = false;
        notifyListeners();
        return true;
      }
      
      _isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      // Debug: Print error for troubleshooting
      if (kDebugMode) {
        print('Login Error: $e');
        if (e is DioException) {
          print('Dio Error Type: ${e.type}');
          print('Dio Error Message: ${e.message}');
          print('Response Status: ${e.response?.statusCode}');
          print('Response Data: ${e.response?.data}');
          print('Request URL: ${e.requestOptions.uri}');
        }
      }
      
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> register(String name, String email, String password, String passwordConfirmation) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiService().post(
        ApiConstants.register,
        data: {
          'name': name,
          'email': email,
          'password': password,
          'password_confirmation': passwordConfirmation,
        },
      );

      if (response.statusCode == 201 && response.data['success'] == true) {
        _token = response.data['data']['token'];
        _user = UserModel.fromJson(response.data['data']['user']);
        
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('auth_token', _token!);
        
        _isLoading = false;
        notifyListeners();
        return true;
      }
      
      _isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> fetchUser() async {
    try {
      final response = await ApiService().get(ApiConstants.me);
      if (response.statusCode == 200 && response.data['success'] == true) {
        _user = UserModel.fromJson(response.data['data']);
        notifyListeners();
      }
    } catch (e) {
      // Handle error
    }
  }

  Future<void> logout() async {
    try {
      await ApiService().post(ApiConstants.logout);
    } catch (e) {
      // Ignore errors
    } finally {
      _token = null;
      _user = null;
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('auth_token');
      notifyListeners();
    }
  }
}
