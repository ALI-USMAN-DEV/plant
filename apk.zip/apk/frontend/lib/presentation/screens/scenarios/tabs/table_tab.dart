import 'package:flutter/material.dart';
import 'package:plant_layout_viewer/data/models/project_model.dart';
import 'package:plant_layout_viewer/data/models/unit_model.dart';
import 'package:plant_layout_viewer/data/models/scenario_model.dart';
import 'package:plant_layout_viewer/data/services/api_service.dart';
import 'package:plant_layout_viewer/core/constants/api_constants.dart';

class TableTab extends StatefulWidget {
  final ProjectModel project;
  final UnitModel unit;
  final ScenarioModel scenario;

  const TableTab({
    super.key,
    required this.project,
    required this.unit,
    required this.scenario,
  });

  @override
  State<TableTab> createState() => _TableTabState();
}

class _TableTabState extends State<TableTab> {
  List<String> _headers = [];
  List<List<String>> _rows = [];
  bool _isLoading = true;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _loadTableData();
  }

  Future<void> _loadTableData() async {
    setState(() => _isLoading = true);
    try {
      final response = await ApiService().get(
        ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id),
      );

      if (response.statusCode == 200 && response.data['success'] == true) {
        final tableData = response.data['data']['table'];
        if (tableData != null && tableData['table_data'] != null) {
          final data = tableData['table_data'];
          setState(() {
            _headers = List<String>.from(data['headers'] ?? []);
            _rows = (data['rows'] as List?)
                    ?.map((row) => List<String>.from(row))
                    .toList() ?? [];
            _isLoading = false;
          });
        } else {
          setState(() {
            _headers = ['Column 1', 'Column 2'];
            _rows = [['', ''], ['', '']];
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      setState(() {
        _headers = ['Column 1', 'Column 2'];
        _rows = [['', ''], ['', '']];
        _isLoading = false;
      });
    }
  }

  Future<void> _saveTableData() async {
    setState(() => _isSaving = true);
    try {
      await ApiService().put(
        '${ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id)}/table',
        data: {
          'table_data': {
            'headers': _headers,
            'rows': _rows,
          },
        },
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Table saved successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving table: $e')),
        );
      }
    } finally {
      setState(() => _isSaving = false);
    }
  }

  void _addColumn() {
    setState(() {
      _headers.add('Column ${_headers.length + 1}');
      for (var row in _rows) {
        row.add('');
      }
    });
  }

  void _removeColumn(int index) {
    if (_headers.length > 1) {
      setState(() {
        _headers.removeAt(index);
        for (var row in _rows) {
          if (row.length > index) {
            row.removeAt(index);
          }
        }
      });
    }
  }

  void _addRow() {
    setState(() {
      _rows.add(List.filled(_headers.length, ''));
    });
  }

  void _removeRow(int index) {
    if (_rows.length > 1) {
      setState(() {
        _rows.removeAt(index);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(8.0),
          color: Colors.grey[200],
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.add),
                onPressed: _addColumn,
                tooltip: 'Add Column',
              ),
              IconButton(
                icon: const Icon(Icons.add_box),
                onPressed: _addRow,
                tooltip: 'Add Row',
              ),
              const Spacer(),
              if (_isSaving)
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                )
              else
                IconButton(
                  icon: const Icon(Icons.save),
                  onPressed: _saveTableData,
                  tooltip: 'Save',
                ),
            ],
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SingleChildScrollView(
              child: DataTable(
                columns: _headers.asMap().entries.map((entry) {
                  return DataColumn(
                    label: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Expanded(
                          child: TextField(
                            controller: TextEditingController(text: entry.value),
                            onChanged: (value) {
                              _headers[entry.key] = value;
                            },
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                              isDense: true,
                            ),
                          ),
                        ),
                        if (_headers.length > 1)
                          IconButton(
                            icon: const Icon(Icons.close, size: 18),
                            onPressed: () => _removeColumn(entry.key),
                            tooltip: 'Remove Column',
                          ),
                      ],
                    ),
                  );
                }).toList(),
                rows: _rows.asMap().entries.map((rowEntry) {
                  return DataRow(
                    cells: rowEntry.value.asMap().entries.map((cellEntry) {
                      return DataCell(
                        TextField(
                          controller: TextEditingController(text: cellEntry.value),
                          onChanged: (value) {
                            _rows[rowEntry.key][cellEntry.key] = value;
                          },
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            isDense: true,
                          ),
                        ),
                      );
                    }).toList(),
                  );
                }).toList(),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
