# Auto Install APK Script
# This script waits for device and installs APK automatically

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "APK Auto-Install Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if APK exists
$apkPath = "frontend\build\app\outputs\flutter-apk\app-release.apk"
if (-not (Test-Path $apkPath)) {
    Write-Host "ERROR: APK not found at: $apkPath" -ForegroundColor Red
    Write-Host "Please build APK first: flutter build apk --release" -ForegroundColor Yellow
    exit 1
}

Write-Host "APK found: $apkPath" -ForegroundColor Green
$apkSize = [math]::Round((Get-Item $apkPath).Length / 1MB, 2)
Write-Host "APK Size: $apkSize MB" -ForegroundColor Yellow
Write-Host ""

# Wait for device
Write-Host "Waiting for Android device..." -ForegroundColor Cyan
Write-Host "Please:" -ForegroundColor Yellow
Write-Host "  1. Connect Android device via USB" -ForegroundColor White
Write-Host "  2. Enable USB debugging" -ForegroundColor White
Write-Host "  3. Accept USB debugging prompt on device" -ForegroundColor White
Write-Host ""

$maxAttempts = 30
$attempt = 0
$deviceFound = $false

while ($attempt -lt $maxAttempts -and -not $deviceFound) {
    Start-Sleep -Seconds 2
    $devices = adb devices 2>&1 | Select-String "device$"
    
    if ($devices) {
        Write-Host "Device connected!" -ForegroundColor Green
        $deviceFound = $true
        break
    } else {
        $attempt++
        Write-Host "Attempt $attempt/$maxAttempts - Waiting for device..." -ForegroundColor Yellow
    }
}

if (-not $deviceFound) {
    Write-Host ""
    Write-Host "ERROR: No device detected after $maxAttempts attempts" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please check:" -ForegroundColor Yellow
    Write-Host "  - USB cable is connected" -ForegroundColor White
    Write-Host "  - USB debugging is enabled" -ForegroundColor White
    Write-Host "  - USB debugging prompt is accepted" -ForegroundColor White
    Write-Host ""
    Write-Host "Then run this script again" -ForegroundColor Cyan
    exit 1
}

Write-Host ""
Write-Host "Device Information:" -ForegroundColor Cyan
adb devices -l
Write-Host ""

# Uninstall previous version
Write-Host "Uninstalling previous version (if exists)..." -ForegroundColor Cyan
adb uninstall com.plantlayout.viewer 2>&1 | Out-Null
Write-Host "Previous version removed" -ForegroundColor Green
Write-Host ""

# Install APK
Write-Host "Installing APK..." -ForegroundColor Cyan
Write-Host "This may take 30-60 seconds..." -ForegroundColor Yellow
Write-Host ""

$installResult = adb install -r $apkPath 2>&1
$installResult | ForEach-Object { Write-Host $_ -ForegroundColor White }

if ($installResult -match "Success" -or $installResult -match "already installed") {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "APK INSTALLED SUCCESSFULLY!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    
    # Verify installation
    Write-Host "Verifying installation..." -ForegroundColor Cyan
    $installed = adb shell pm list packages | Select-String "com.plantlayout.viewer"
    if ($installed) {
        Write-Host "App verified in installed packages!" -ForegroundColor Green
    }
    Write-Host ""
    
    # Launch app
    Write-Host "Launching app..." -ForegroundColor Cyan
    adb shell am start -n com.plantlayout.viewer/.MainActivity 2>&1 | Out-Null
    Start-Sleep -Seconds 2
    Write-Host "App launch command sent!" -ForegroundColor Green
    Write-Host ""
    
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "INSTALLATION COMPLETE!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Package: com.plantlayout.viewer" -ForegroundColor Cyan
    Write-Host "APK Size: $apkSize MB" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Check your device - app should be open!" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Next: Test all features" -ForegroundColor Cyan
    Write-Host ""
    
} else {
    Write-Host ""
    Write-Host "ERROR: Installation failed!" -ForegroundColor Red
    Write-Host "Check the error messages above" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Common fixes:" -ForegroundColor Cyan
    Write-Host "  - Uninstall previous version manually" -ForegroundColor White
    Write-Host "  - Check device has enough storage" -ForegroundColor White
    Write-Host "  - Enable 'Install via USB' in Developer Options" -ForegroundColor White
    Write-Host ""
    exit 1
}
