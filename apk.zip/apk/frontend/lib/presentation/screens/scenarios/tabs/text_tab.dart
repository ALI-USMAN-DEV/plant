import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart';
import 'package:plant_layout_viewer/data/models/project_model.dart';
import 'package:plant_layout_viewer/data/models/unit_model.dart';
import 'package:plant_layout_viewer/data/models/scenario_model.dart';
import 'package:plant_layout_viewer/data/services/api_service.dart';
import 'package:plant_layout_viewer/core/constants/api_constants.dart';

class TextTab extends StatefulWidget {
  final ProjectModel project;
  final UnitModel unit;
  final ScenarioModel scenario;

  const TextTab({
    super.key,
    required this.project,
    required this.unit,
    required this.scenario,
  });

  @override
  State<TextTab> createState() => _TextTabState();
}

class _TextTabState extends State<TextTab> {
  late QuillController _controller;
  late FocusNode _focusNode;
  late ScrollController _scrollController;
  String _currentContent = '';
  bool _isLoading = true;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _controller = QuillController.basic();
    _focusNode = FocusNode();
    _scrollController = ScrollController();
    _loadTextContent();
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadTextContent() async {
    setState(() => _isLoading = true);
    try {
      final response = await ApiService().get(
        ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id),
      );

      if (response.statusCode == 200 && response.data['success'] == true) {
        final textData = response.data['data']['text'];
        if (textData != null && textData['content'] != null) {
          setState(() {
            _currentContent = textData['content'];
            _controller.document = Document.fromJson(
              _controller.document.toDelta().toJson(),
            );
          });
        }
      }
    } catch (e) {
      // Handle error
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _saveTextContent() async {
    setState(() => _isSaving = true);
    try {
      final delta = _controller.document.toDelta();
      final content = delta.toJson().toString();

      await ApiService().put(
        '${ApiConstants.scenario(widget.project.id, widget.unit.id, widget.scenario.id)}/text',
        data: {'content': content},
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Text saved successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving text: $e')),
        );
      }
    } finally {
      setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(8.0),
          color: Colors.grey[200],
          child: Row(
            children: [
              const Text('Rich Text Editor', style: TextStyle(fontWeight: FontWeight.bold)),
              const Spacer(),
              if (_isSaving)
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                )
              else
                IconButton(
                  icon: const Icon(Icons.save),
                  onPressed: _saveTextContent,
                  tooltip: 'Save',
                ),
            ],
          ),
        ),
        Expanded(
          child: QuillEditor(
            focusNode: _focusNode,
            scrollController: _scrollController,
            configurations: QuillEditorConfigurations(
              controller: _controller,
              placeholder: 'Type your text here...',
              readOnly: false,
            ),
          ),
        ),
        QuillToolbar.simple(
          configurations: QuillSimpleToolbarConfigurations(
            controller: _controller,
            sharedConfigurations: const QuillSharedConfigurations(),
          ),
        ),
      ],
    );
  }
}
