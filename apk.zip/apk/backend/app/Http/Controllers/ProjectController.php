<?php

namespace App\Http\Controllers;

use App\Models\Project;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function index(Request $request)
    {
        $query = Project::with(['user', 'units']);

        // Admin sees all projects, users see assigned projects
        if (!$request->user()->hasRole('admin')) {
            $query->where(function($q) use ($request) {
                $q->where('user_id', $request->user()->id)
                  ->orWhereHas('assignedUsers', function($q) use ($request) {
                      $q->where('users.id', $request->user()->id);
                  });
            });
        }

        $projects = $query->get();

        return response()->json([
            'success' => true,
            'data' => $projects,
        ]);
    }

    public function store(Request $request)
    {
        // Only admin can create projects
        if (!$request->user()->hasRole('admin')) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin can create projects'
            ], 403);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'status' => 'nullable|in:active,archived',
        ]);

        $project = Project::create([
            'user_id' => $request->user()->id,
            'name' => $request->name,
            'description' => $request->description,
            'status' => $request->status ?? 'active',
        ]);

        return response()->json([
            'success' => true,
            'data' => $project->load('user', 'units'),
            'message' => 'Project created successfully'
        ], 201);
    }

    public function show(Request $request, $id)
    {
        $project = Project::with(['user', 'units.scenarios', 'assignedUsers'])->findOrFail($id);

        // Check permission - admin or owner or assigned user
        if (!$request->user()->hasRole('admin') 
            && $project->user_id !== $request->user()->id
            && !$project->assignedUsers->contains($request->user()->id)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        return response()->json([
            'success' => true,
            'data' => $project,
        ]);
    }

    public function update(Request $request, $id)
    {
        $project = Project::findOrFail($id);

        // Only admin or project owner can update
        if (!$request->user()->hasRole('admin') && $project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin or project owner can update projects'
            ], 403);
        }

        $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'status' => 'sometimes|in:active,archived',
        ]);

        $project->update($request->only(['name', 'description', 'status']));

        return response()->json([
            'success' => true,
            'data' => $project->load('user', 'units'),
            'message' => 'Project updated successfully'
        ]);
    }

    public function destroy(Request $request, $id)
    {
        $project = Project::findOrFail($id);

        // Only admin or project owner can delete
        if (!$request->user()->hasRole('admin') && $project->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin or project owner can delete projects'
            ], 403);
        }

        $project->delete();

        return response()->json([
            'success' => true,
            'message' => 'Project deleted successfully'
        ]);
    }

    // Assign project to users (Admin only)
    public function assignUsers(Request $request, $id)
    {
        $project = Project::findOrFail($id);

        // Only admin can assign projects
        if (!$request->user()->hasRole('admin')) {
            return response()->json([
                'success' => false,
                'message' => 'Only admin can assign projects'
            ], 403);
        }

        $request->validate([
            'user_ids' => 'required|array',
            'user_ids.*' => 'exists:users,id',
        ]);

        $project->assignedUsers()->sync($request->user_ids);

        return response()->json([
            'success' => true,
            'data' => $project->load('assignedUsers'),
            'message' => 'Project assigned to users successfully'
        ]);
    }

    // Get all users for assignment (Admin only)
    public function getUsersForAssignment(Request $request)
    {
        if (!$request->user()->hasRole('admin')) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $users = \App\Models\User::where('id', '!=', $request->user()->id)
            ->select('id', 'name', 'email')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $users,
        ]);
    }
}
