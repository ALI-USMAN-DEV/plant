# Quick Hosting Setup Script
# Ye script aapko hosting setup karne mein help karega

Write-Host "🌐 Project Hosting Setup" -ForegroundColor Cyan
Write-Host "========================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Yeh script aapko hosting setup karne mein help karega." -ForegroundColor Yellow
Write-Host ""

# Check if API URL already updated
$apiConstantsFile = "frontend\lib\core\constants\api_constants.dart"
if (Test-Path $apiConstantsFile) {
    $content = Get-Content $apiConstantsFile -Raw
    if ($content -match "https://.*\.(onrender|railway|heroku)\.(com|app)") {
        Write-Host "✅ API URL already updated with cloud URL!" -ForegroundColor Green
        $currentUrl = [regex]::Match($content, "static const String baseUrl = '([^']+)'").Groups[1].Value
        Write-Host "Current URL: $currentUrl" -ForegroundColor White
        Write-Host ""
    } elseif ($content -match "http://192\.168\.|http://10\.0\.2\.2") {
        Write-Host "⚠️  API URL abhi local IP use kar raha hai." -ForegroundColor Yellow
        Write-Host "Cloud hosting ke baad URL update karna hoga." -ForegroundColor Yellow
        Write-Host ""
    }
}

Write-Host "📋 Hosting Options:" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Render.com (Recommended - Free, Easy)" -ForegroundColor White
Write-Host "2. Railway.app (Free, Very Easy)" -ForegroundColor White
Write-Host "3. Manual Setup (Guide follow karo)" -ForegroundColor White
Write-Host "4. Exit" -ForegroundColor White
Write-Host ""

$choice = Read-Host "Select option (1-4)"

switch ($choice) {
    "1" {
        Write-Host ""
        Write-Host "🚀 Render.com Setup" -ForegroundColor Cyan
        Write-Host "===================" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "📖 Steps:" -ForegroundColor Yellow
        Write-Host "1. https://render.com pe jao" -ForegroundColor White
        Write-Host "2. GitHub se sign up karo" -ForegroundColor White
        Write-Host "3. 'New Web Service' create karo" -ForegroundColor White
        Write-Host "4. Backend folder select karo" -ForegroundColor White
        Write-Host "5. Environment variables set karo" -ForegroundColor White
        Write-Host "6. Deploy wait karo" -ForegroundColor White
        Write-Host ""
        Write-Host "📄 Detailed guide: DEPLOY_TO_RENDER.md" -ForegroundColor Cyan
        Write-Host ""
        $openGuide = Read-Host "Guide open karein? (y/n)"
        if ($openGuide -eq "y") {
            if (Test-Path "DEPLOY_TO_RENDER.md") {
                notepad "DEPLOY_TO_RENDER.md"
            }
        }
        
        Write-Host ""
        Write-Host "Jab URL mil jaye, ye command run karo:" -ForegroundColor Yellow
        Write-Host '.\UPDATE_API_URL.ps1 -Url "https://your-app.onrender.com/api"' -ForegroundColor Green
    }
    "2" {
        Write-Host ""
        Write-Host "🚂 Railway.app Setup" -ForegroundColor Cyan
        Write-Host "====================" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "📖 Steps:" -ForegroundColor Yellow
        Write-Host "1. https://railway.app pe jao" -ForegroundColor White
        Write-Host "2. GitHub se sign up karo" -ForegroundColor White
        Write-Host "3. 'New Project' → 'Deploy from GitHub'" -ForegroundColor White
        Write-Host "4. Backend folder select karo" -ForegroundColor White
        Write-Host "5. Database automatically add ho jayega" -ForegroundColor White
        Write-Host "6. Deploy automatically start ho jayega" -ForegroundColor White
        Write-Host ""
        Write-Host "Railway sab kuch automatically handle karta hai!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Jab URL mil jaye, ye command run karo:" -ForegroundColor Yellow
        Write-Host '.\UPDATE_API_URL.ps1 -Url "https://your-app.railway.app/api"' -ForegroundColor Green
    }
    "3" {
        Write-Host ""
        Write-Host "📖 Complete Guide" -ForegroundColor Cyan
        Write-Host "================" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Detailed guide: HOSTING_COMPLETE_GUIDE.md" -ForegroundColor Yellow
        Write-Host ""
        if (Test-Path "HOSTING_COMPLETE_GUIDE.md") {
            $openGuide = Read-Host "Guide open karein? (y/n)"
            if ($openGuide -eq "y") {
                notepad "HOSTING_COMPLETE_GUIDE.md"
            }
        }
    }
    "4" {
        Write-Host "Exiting..." -ForegroundColor Yellow
        exit 0
    }
    default {
        Write-Host "Invalid option!" -ForegroundColor Red
        exit 1
    }
}

Write-Host ""
Write-Host "📋 After Hosting:" -ForegroundColor Cyan
Write-Host "1. URL update karo: .\UPDATE_API_URL.ps1 -Url 'YOUR_URL'" -ForegroundColor White
Write-Host "2. APK rebuild karo: .\REBUILD_APK.ps1" -ForegroundColor White
Write-Host "3. APK test karo device pe" -ForegroundColor White
Write-Host ""
Write-Host "✅ Done! APK ab kahin se bhi chalega!" -ForegroundColor Green
