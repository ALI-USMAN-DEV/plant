<?php

namespace App\Http\Controllers;

use App\Models\Scenario;
use App\Models\ScenarioDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DocumentController extends Controller
{
    // Helper function to check if user can access project
    private function canAccessProject($user, $project)
    {
        return $user->hasRole('admin') 
            || $project->user_id === $user->id
            || $project->assignedUsers->contains($user->id);
    }

    public function store(Request $request, $projectId, $unitId, $scenarioId)
    {
        $scenario = Scenario::with('unit.project.assignedUsers')->findOrFail($scenarioId);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        $request->validate([
            'file' => 'required|file|mimes:jpeg,jpg,png,pdf,doc,docx|max:20480',
        ]);

        $file = $request->file('file');
        $mimeType = $file->getMimeType();
        $fileType = 'image';

        if (str_contains($mimeType, 'pdf')) {
            $fileType = 'pdf';
        } elseif (str_contains($mimeType, 'word') || str_contains($mimeType, 'document')) {
            $fileType = 'word';
        }

        $path = $file->store('documents', 'public');

        $document = ScenarioDocument::create([
            'scenario_id' => $scenarioId,
            'file_path' => $path,
            'file_name' => $file->getClientOriginalName(),
            'file_type' => $fileType,
            'file_size' => $file->getSize(),
            'mime_type' => $mimeType,
        ]);

        return response()->json([
            'success' => true,
            'data' => $document,
            'message' => 'Document uploaded successfully'
        ], 201);
    }

    public function destroy(Request $request, $projectId, $unitId, $scenarioId, $id)
    {
        $document = ScenarioDocument::with('scenario.unit.project.assignedUsers')->findOrFail($id);

        // Admin, owner, or assigned user can edit scenarios
        if (!$this->canAccessProject($request->user(), $document->scenario->unit->project)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }

        Storage::disk('public')->delete($document->file_path);
        $document->delete();

        return response()->json([
            'success' => true,
            'message' => 'Document deleted successfully'
        ]);
    }
}
