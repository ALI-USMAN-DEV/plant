<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Role;
use App\Models\Project;
use App\Models\Unit;
use App\Models\Scenario;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Create roles
        $adminRole = Role::create([
            'name' => 'admin',
            'description' => 'Administrator with full access',
        ]);

        $userRole = Role::create([
            'name' => 'user',
            'description' => 'Regular user with limited access',
        ]);

        // Create admin user
        $admin = User::create([
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'password' => Hash::make('password'),
        ]);
        $admin->roles()->attach($adminRole);

        // Create regular user
        $user = User::create([
            'name' => 'Test User',
            'email' => 'user@example.com',
            'password' => Hash::make('password'),
        ]);
        $user->roles()->attach($userRole);

        // Create sample project
        $project = Project::create([
            'user_id' => $admin->id,
            'name' => 'Sample Plant Project',
            'description' => 'A sample project for testing',
            'status' => 'active',
        ]);

        // Create sample unit
        $unit = Unit::create([
            'project_id' => $project->id,
            'name' => 'Unit 1',
            'description' => 'Main processing unit',
        ]);

        // Create sample scenarios (50 scenarios as per requirement)
        for ($i = 1; $i <= 50; $i++) {
            $scenario = Scenario::create([
                'unit_id' => $unit->id,
                'name' => "Scenario {$i}",
                'description' => "Description for scenario {$i}",
                'map_center_lat' => 40.7128 + (rand(-100, 100) / 1000),
                'map_center_lng' => -74.0060 + (rand(-100, 100) / 1000),
                'map_zoom' => 15.0,
            ]);

            // Create default tabs
            $scenario->tabs()->createMany([
                ['type' => 'map', 'title' => 'Map & Layers', 'order' => 0],
                ['type' => 'text', 'title' => 'Text', 'order' => 1],
                ['type' => 'document', 'title' => 'Documents', 'order' => 2],
                ['type' => 'table', 'title' => 'Table', 'order' => 3],
            ]);

            // Create default map layers
            $baseLayer = $scenario->mapLayers()->create([
                'layer_type' => 'base',
                'name' => 'Base Map',
                'z_index' => 0,
            ]);

            $layoutLayer = $scenario->mapLayers()->create([
                'layer_type' => 'layout',
                'name' => 'Layout Layer',
                'z_index' => 1,
            ]);

            $equipmentLayer = $scenario->mapLayers()->create([
                'layer_type' => 'equipment',
                'name' => 'Equipment Layer',
                'z_index' => 2,
            ]);

            $escapeRouteLayer = $scenario->mapLayers()->create([
                'layer_type' => 'escape_route',
                'name' => 'Escape Route Layer',
                'z_index' => 3,
            ]);

            $riskZoneLayer = $scenario->mapLayers()->create([
                'layer_type' => 'risk_zone',
                'name' => 'Risk Zone Layer',
                'z_index' => 4,
            ]);

            // Create sample text content
            $scenario->text()->create([
                'content' => "<h2>Scenario {$i} Content</h2><p>This is sample text content for scenario {$i}.</p>",
            ]);

            // Create sample table
            $scenario->table()->create([
                'table_data' => [
                    'headers' => ['Item', 'Value', 'Status'],
                    'rows' => [
                        ['Item 1', 'Value 1', 'Active'],
                        ['Item 2', 'Value 2', 'Inactive'],
                    ],
                ],
            ]);
        }
    }
}
