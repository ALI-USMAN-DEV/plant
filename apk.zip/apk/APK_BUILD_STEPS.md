# APK Build - Step by Step 🚀

## 📱 Android APK Build Karne Ke Liye

### Prerequisites Check

#### Step 1: Android Studio Install (Agar nahi hai)
1. Download: https://developer.android.com/studio
2. Install Android Studio
3. SDK Manager se Android SDK install karo
4. Android SDK Platform Tools install karo

#### Step 2: Flutter Android Setup Verify
```bash
flutter doctor
```

**Required:**
- ✅ Android toolchain - develop for Android devices
- ✅ Android Studio (version)
- ✅ Android SDK (SDK location)

### APK Build Process

#### Step 1: Android Configuration Check
```bash
cd frontend
flutter doctor
```

#### Step 2: Clean Build (Optional but Recommended)
```bash
flutter clean
flutter pub get
```

#### Step 3: Build Release APK
```bash
flutter build apk --release
```

**Ya Debug APK (Testing):**
```bash
flutter build apk --debug
```

### APK File Location

After build, APK mil jayega:
```
frontend/build/app/outputs/flutter-apk/app-release.apk
```

### APK Install Karo

#### Option A: ADB se (Android Device/Emulator)
```bash
# Device connect karo
adb devices

# APK install karo
adb install frontend/build/app/outputs/flutter-apk/app-release.apk
```

#### Option B: Manually
1. APK file device par copy karo (USB/Email/Cloud)
2. Device par file manager se open karo
3. "Install from Unknown Sources" allow karo (agar needed)
4. Install button click karo

### APK Signing (Production ke liye)

Release APK ke liye signing key create karo:

```bash
cd frontend/android/app
keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias release
```

Phir `android/app/build.gradle` mein signing config add karo.

## 🔧 Troubleshooting

### "Android SDK not found"
- Android Studio install karo
- SDK Manager se Android SDK install karo
- Environment variable set karo: `ANDROID_HOME`

### "Gradle sync failed"
```bash
cd frontend/android
./gradlew clean
cd ../..
flutter clean
flutter pub get
```

### "Build failed"
- Check `android/app/build.gradle`
- Check `AndroidManifest.xml`
- Check Flutter doctor output

## 📋 Quick Build Commands

### Release APK
```bash
cd frontend
flutter build apk --release
```

### Debug APK
```bash
cd frontend
flutter build apk --debug
```

### Split APKs (Size optimize)
```bash
flutter build apk --split-per-abi
```

## ✅ Before Building

- [ ] Android Studio installed
- [ ] Android SDK configured
- [ ] Flutter doctor shows Android ready
- [ ] Backend server running (for testing)
- [ ] API URL configured correctly

## 🎯 Next Steps

1. **Android Studio install karo** (agar nahi hai)
2. **Flutter doctor run karo** - Android setup verify karo
3. **APK build karo** - `flutter build apk --release`
4. **APK install karo** - Device par test karo

---

**APK build karne ke liye Android setup karo!** 🚀
