<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ScenarioDocument extends Model
{
    protected $fillable = [
        'scenario_id',
        'file_path',
        'file_name',
        'file_type',
        'file_size',
        'mime_type',
    ];

    public function scenario(): BelongsTo
    {
        return $this->belongsTo(Scenario::class);
    }
}
