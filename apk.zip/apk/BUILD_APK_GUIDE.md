# Build APK - Complete Guide 🚀

## 📱 APK Build Karne Ke Liye

### Prerequisites

1. **Android Studio** installed
2. **Android SDK** configured
3. **Flutter** Android support enabled

### Step 1: Android Setup Verify Karo

```bash
flutter doctor
```

Check karo:
- ✅ Android toolchain installed
- ✅ Android Studio installed
- ✅ Android SDK configured

### Step 2: Android SDK Path Set Karo (Agar needed)

```bash
# Android SDK path set karo
set ANDROID_HOME=C:\Users\YourName\AppData\Local\Android\Sdk
```

### Step 3: APK Build Karo

#### Option A: Debug APK (Testing ke liye)
```bash
cd frontend
flutter build apk --debug
```

#### Option B: Release APK (Production ke liye)
```bash
cd frontend
flutter build apk --release
```

### Step 4: APK Location

APK file mil jayega:
- **Debug:** `frontend/build/app/outputs/flutter-apk/app-debug.apk`
- **Release:** `frontend/build/app/outputs/flutter-apk/app-release.apk`

### Step 5: APK Install Karo

#### Android Device/Emulator par:
```bash
# APK install karo
adb install frontend/build/app/outputs/flutter-apk/app-release.apk
```

Ya manually:
1. APK file device par copy karo
2. File manager se open karo
3. Install karo

## 🔧 Common Issues & Solutions

### Issue 1: "Android SDK not found"
**Solution:**
1. Android Studio install karo
2. SDK Manager se Android SDK install karo
3. Flutter doctor run karo

### Issue 2: "Gradle build failed"
**Solution:**
```bash
cd frontend/android
./gradlew clean
cd ..
flutter clean
flutter pub get
flutter build apk
```

### Issue 3: "Signing config error"
**Solution:**
Release APK ke liye signing key create karo (optional for testing)

## 📋 Quick Commands

### Build Release APK
```bash
cd frontend
flutter build apk --release
```

### Build Debug APK
```bash
cd frontend
flutter build apk --debug
```

### Install APK
```bash
adb install build/app/outputs/flutter-apk/app-release.apk
```

## ✅ APK Build Checklist

- [ ] Android Studio installed
- [ ] Android SDK configured
- [ ] Flutter doctor shows Android toolchain
- [ ] Backend server running
- [ ] API URL configured
- [ ] APK build command run
- [ ] APK file generated
- [ ] APK installed on device

---

**APK build karne ke liye Android setup karo!** 🚀
