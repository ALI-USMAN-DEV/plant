# 🚀 APK Ko Live Karne Ke Liye - Start Yahan Se!

## Kya Karna Hai?

Aapke APK ko **kahin se bhi** chalane ke liye backend ko **cloud pe host** karna hoga.

---

## ⚡ Quick Start (3 Steps)

### Step 0: GitHub Pe Code Push Karo (Zaroori!)
Agar code GitHub pe nahi hai:
```powershell
.\GITHUB_SETUP.ps1
```
Ya manually:
```powershell
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### Step 1: Backend Host Karo
**Option A: Railway.app (Sabse Easy - Recommended!)**
1. https://railway.app pe jao
2. GitHub se sign up karo
3. "New Project" → "Deploy from GitHub"
4. Aapka repo select karo
5. **Automatically deploy ho jayega!** (Zero config!)

**Option B: Render.com**
1. https://render.com pe jao
2. GitHub se sign up karo
3. "New Web Service" create karo
4. GitHub repo connect karo
5. Backend deploy karo
6. URL copy karo (e.g., `https://your-app.onrender.com`)

**Detailed Guide:** `DEPLOY_TO_RENDER.md` ya `HOSTING_COMPLETE_GUIDE.md` dekh lo

### Step 2: API URL Update Karo
Jab hosting complete ho jaye aur URL mil jaye:

```powershell
.\UPDATE_API_URL.ps1 -Url "https://your-app.onrender.com/api"
```

Ya manually:
- File: `frontend/lib/core/constants/api_constants.dart`
- Line 15: `static const String baseUrl = 'https://your-app.onrender.com/api';`

### Step 3: APK Rebuild Karo
```powershell
.\REBUILD_APK.ps1
```

**Done!** 🎉 Ab APK kahin se bhi chalega!

---

## 📁 Files Created

1. **GITHUB_DIRECT_HOSTING.md** - GitHub se hosting guide (READ THIS FIRST!)
2. **GITHUB_SETUP.ps1** - GitHub pe code push karne ke liye script
3. **HOSTING_COMPLETE_GUIDE.md** - Complete hosting guide (sab options)
4. **DEPLOY_TO_RENDER.md** - Render.com step-by-step guide
5. **UPDATE_API_URL.ps1** - API URL update script
6. **REBUILD_APK.ps1** - APK rebuild script
7. **QUICK_HOSTING_SETUP.ps1** - Interactive setup helper

---

## 🎯 Recommended Approach

### For Beginners (Sabse Easy):
1. **GitHub pe code push karo** (`GITHUB_SETUP.ps1` run karo)
2. **Railway.app** use karo (sabse easy - zero config!)
3. GitHub repo connect karo
4. **Automatically deploy ho jayega!**
5. URL update karo
6. APK rebuild karo

### For More Control:
1. **GitHub pe code push karo**
2. **Render.com** use karo
3. Step-by-step `DEPLOY_TO_RENDER.md` follow karo
4. Custom configuration kar sakte ho

**Note:** GitHub Pages backend ke liye nahi hai! Lekin GitHub repo ko connect karke Render/Railway pe deploy kar sakte ho.

---

## 📋 Checklist

- [ ] Hosting platform choose kiya (Render/Railway)
- [ ] Backend deployed
- [ ] Database setup ho gaya
- [ ] API URL mil gaya
- [ ] API URL update kiya (`UPDATE_API_URL.ps1`)
- [ ] APK rebuild kiya (`REBUILD_APK.ps1`)
- [ ] APK test kiya device pe
- [ ] Sab kuch kaam kar raha hai! ✅

---

## 🆘 Help Needed?

1. **Quick Setup:** `QUICK_HOSTING_SETUP.ps1` run karo
2. **Detailed Guide:** `HOSTING_COMPLETE_GUIDE.md` padho
3. **Render Specific:** `DEPLOY_TO_RENDER.md` follow karo

---

## 💡 Important Notes

1. **Free Tier:**
   - Render: Service sleep ho sakta hai (15 min inactive)
   - Railway: Monthly limit hai
   - Production ke liye paid plan better hai

2. **Database:**
   - PostgreSQL free tier available (Render)
   - MySQL ke liye PlanetScale (free) use karo

3. **HTTPS:**
   - Mobile app ke liye HTTPS zaroori hai
   - HTTP kaam nahi karega

4. **CORS:**
   - Mobile app ke liye CORS allow karna zaroori hai
   - Environment variable: `CORS_ALLOWED_ORIGINS=*`

---

## 🚀 Next Steps

1. **Abhi:** `QUICK_HOSTING_SETUP.ps1` run karo
2. **Ya:** `DEPLOY_TO_RENDER.md` follow karo
3. **URL milne ke baad:** `UPDATE_API_URL.ps1` run karo
4. **APK rebuild:** `REBUILD_APK.ps1` run karo
5. **Test karo:** Device pe install karo aur test karo

---

**Ab aapka APK kahin se bhi chalega!** ✨

Good luck! 🍀
