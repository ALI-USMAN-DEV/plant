import 'package:flutter/material.dart';
import 'package:plant_layout_viewer/data/models/project_model.dart';
import 'package:plant_layout_viewer/data/models/unit_model.dart';
import 'package:plant_layout_viewer/data/models/scenario_model.dart';
import 'package:plant_layout_viewer/presentation/screens/scenarios/tabs/map_tab.dart';
import 'package:plant_layout_viewer/presentation/screens/scenarios/tabs/text_tab.dart';
import 'package:plant_layout_viewer/presentation/screens/scenarios/tabs/document_tab.dart';
import 'package:plant_layout_viewer/presentation/screens/scenarios/tabs/table_tab.dart';

class ScenarioDetailScreen extends StatefulWidget {
  final ProjectModel project;
  final UnitModel unit;
  final ScenarioModel scenario;

  const ScenarioDetailScreen({
    super.key,
    required this.project,
    required this.unit,
    required this.scenario,
  });

  @override
  State<ScenarioDetailScreen> createState() => _ScenarioDetailScreenState();
}

class _ScenarioDetailScreenState extends State<ScenarioDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.scenario.name),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.map), text: 'Map & Layers'),
            Tab(icon: Icon(Icons.text_fields), text: 'Text'),
            Tab(icon: Icon(Icons.description), text: 'Documents'),
            Tab(icon: Icon(Icons.table_chart), text: 'Table'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          MapTab(
            project: widget.project,
            unit: widget.unit,
            scenario: widget.scenario,
          ),
          TextTab(
            project: widget.project,
            unit: widget.unit,
            scenario: widget.scenario,
          ),
          DocumentTab(
            project: widget.project,
            unit: widget.unit,
            scenario: widget.scenario,
          ),
          TableTab(
            project: widget.project,
            unit: widget.unit,
            scenario: widget.scenario,
          ),
        ],
      ),
    );
  }
}
