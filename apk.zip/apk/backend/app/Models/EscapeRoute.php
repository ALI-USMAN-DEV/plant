<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EscapeRoute extends Model
{
    protected $fillable = [
        'map_layer_id',
        'name',
        'color',
        'width',
        'path_data',
        'is_visible',
    ];

    protected $casts = [
        'path_data' => 'array',
        'is_visible' => 'boolean',
    ];

    public function mapLayer(): BelongsTo
    {
        return $this->belongsTo(MapLayer::class);
    }
}
