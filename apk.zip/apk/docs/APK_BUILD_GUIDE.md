# APK Build Guide

## Prerequisites

1. **Flutter SDK**
   - Install Flutter SDK from [flutter.dev](https://flutter.dev)
   - Verify installation: `flutter doctor`

2. **Android Studio**
   - Download from [developer.android.com](https://developer.android.com/studio)
   - Install Android SDK (API level 21+)
   - Install Android SDK Build-Tools

3. **Java Development Kit (JDK)**
   - Install JDK 8 or higher
   - Set JAVA_HOME environment variable

**Note:** No API key required! The app uses Leaflet maps with OpenStreetMap tiles (free, no API key needed).

## Step-by-Step Build Process

### 1. Configure API Base URL

Edit `frontend/lib/core/constants/api_constants.dart`:

```dart
static const String baseUrl = 'http://your-backend-url:8000/api';
```

### 2. Install Dependencies

```bash
cd frontend
flutter pub get
```

### 3. Verify Setup

```bash
flutter doctor
```

Ensure all checks pass (or at least Android toolchain is ready).

### 4. Build Debug APK

```bash
flutter build apk --debug
```

Output: `build/app/outputs/flutter-apk/app-debug.apk`

### 5. Build Release APK (Unsigned)

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`

**Note:** This APK is unsigned and cannot be published to Play Store.

## APK Signing (For Play Store)

### 1. Generate Keystore

```bash
keytool -genkey -v -keystore ~/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

You'll be prompted for:
- Password (remember this!)
- Name, organization, etc.

### 2. Create key.properties

Create `frontend/android/key.properties`:

```properties
storePassword=your_store_password
keyPassword=your_key_password
keyAlias=upload
storeFile=/path/to/upload-keystore.jks
```

**Important:** Add `key.properties` to `.gitignore`!

### 3. Update build.gradle

Edit `frontend/android/app/build.gradle`:

```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    ...
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

### 4. Build Signed Release APK

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk` (now signed)

## Build App Bundle (AAB) for Play Store

Google Play prefers App Bundles:

```bash
flutter build appbundle --release
```

Output: `build/app/outputs/bundle/release/app-release.aab`

## Split APKs (Smaller Size)

Build separate APKs for different architectures:

```bash
flutter build apk --split-per-abi --release
```

This creates:
- `app-armeabi-v7a-release.apk` (32-bit ARM)
- `app-arm64-v8a-release.apk` (64-bit ARM)
- `app-x86_64-release.apk` (x86_64)

## Testing the APK

### Install on Device

```bash
# Via ADB
adb install build/app/outputs/flutter-apk/app-release.apk

# Or transfer file and install manually
```

### Test Checklist
- [ ] App launches successfully
- [ ] Login works
- [ ] Maps display correctly
- [ ] All tabs function
- [ ] File uploads work
- [ ] Reports generate
- [ ] No crashes

## Troubleshooting

### Build Errors

**Error: "Gradle build failed"**
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
flutter build apk --release
```

**Error: "SDK location not found"**
- Set `ANDROID_HOME` environment variable
- Or create `local.properties` in `android/`:
  ```
  sdk.dir=/path/to/Android/sdk
  ```

**Error: "Maps not showing"**
- Check internet connection (required for map tiles)
- Verify OpenStreetMap tile server is accessible
- Check network permissions in AndroidManifest.xml

**Error: "Signing config not found"**
- Verify `key.properties` exists
- Check paths in `key.properties` are correct
- Ensure keystore file exists

### Performance Issues

**Large APK Size**
- Use `--split-per-abi` flag
- Enable ProGuard/R8
- Remove unused assets

**Slow Build**
- Enable Gradle daemon
- Increase Gradle memory:
  ```gradle
  org.gradle.jvmargs=-Xmx4096m
  ```

## Distribution

### Google Play Store
1. Create developer account ($25 one-time fee)
2. Create new app in Play Console
3. Upload signed AAB or APK
4. Complete store listing
5. Submit for review

### Direct Distribution
- Upload APK to file hosting
- Share download link
- Users enable "Install from unknown sources"

### Internal Testing
- Use Play Console internal testing track
- Add testers via email
- Distribute without public release

## Version Management

### Update Version

Edit `pubspec.yaml`:
```yaml
version: 1.0.1+2
```
Format: `version_name+build_number`

### Build with Version

```bash
flutter build apk --release --build-number=2 --build-name=1.0.1
```

## Best Practices

1. **Always test debug build first**
2. **Keep keystore secure and backed up**
3. **Use App Bundle for Play Store**
4. **Test on multiple devices**
5. **Monitor APK size**
6. **Use ProGuard for release**
7. **Version your builds properly**

## Additional Resources

- [Flutter Build Documentation](https://docs.flutter.dev/deployment/android)
- [Google Play Console](https://play.google.com/console)
- [Android App Signing](https://developer.android.com/studio/publish/app-signing)
