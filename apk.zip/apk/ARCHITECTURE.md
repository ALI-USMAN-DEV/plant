# System Architecture

## Overview

The application follows a clean architecture pattern with clear separation between frontend and backend.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────┐
│                    Flutter Frontend                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ Presentation │  │   Domain     │  │     Data     │  │
│  │   (UI/State) │  │  (Business)  │  │  (API/Repo)  │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────┘
                        │ HTTP/REST
                        ▼
┌─────────────────────────────────────────────────────────┐
│                   Laravel Backend                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   Routes     │  │ Controllers  │  │   Models     │  │
│  │  (API)       │  │  (Logic)     │  │  (Database)  │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────┐
│                    MySQL Database                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   Projects   │  │    Units     │  │  Scenarios   │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────┘
```

## Data Flow

### Authentication Flow
1. User logs in via Flutter
2. Flutter sends credentials to Laravel `/api/login`
3. Laravel validates and returns Sanctum token
4. Flutter stores token and includes in all subsequent requests

### Data Hierarchy Flow
```
Project (1) → Units (N) → Scenarios (40-60+) → Tabs (N) → Layers (N)
```

### Map Layer System
- **Base Layer**: Google Maps (always visible, toggleable)
- **Layout Layer**: Multiple image overlays (position, scale, rotate)
- **Equipment Layer**: Custom icons placed on map
- **Escape Route Layer**: Polylines with colors
- **Risk Zone Layer**: Circles with wind direction indicators

## Folder Structure

### Laravel Backend
```
backend/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AuthController.php
│   │   │   ├── ProjectController.php
│   │   │   ├── UnitController.php
│   │   │   ├── ScenarioController.php
│   │   │   ├── MapLayerController.php
│   │   │   └── ReportController.php
│   │   └── Middleware/
│   │       └── RoleMiddleware.php
│   ├── Models/
│   │   ├── User.php
│   │   ├── Project.php
│   │   ├── Unit.php
│   │   ├── Scenario.php
│   │   └── ...
│   └── Services/
│       └── ReportService.php
├── database/
│   └── migrations/
├── routes/
│   └── api.php
└── storage/
    └── app/
        └── public/
            ├── layouts/
            ├── equipment/
            ├── documents/
            └── reports/
```

### Flutter Frontend
```
frontend/
├── lib/
│   ├── main.dart
│   ├── core/
│   │   ├── constants/
│   │   ├── theme/
│   │   └── utils/
│   ├── data/
│   │   ├── models/
│   │   ├── repositories/
│   │   └── services/
│   │       └── api_service.dart
│   ├── domain/
│   │   ├── entities/
│   │   └── repositories/
│   └── presentation/
│       ├── auth/
│       ├── projects/
│       ├── units/
│       ├── scenarios/
│       │   ├── map_tab/
│       │   ├── text_tab/
│       │   ├── document_tab/
│       │   └── table_tab/
│       └── reports/
└── assets/
    └── icons/
```

## API Communication

### Base URL
- Development: `http://localhost:8000/api`
- Production: `https://your-domain.com/api`

### Authentication
- All protected routes require: `Authorization: Bearer {token}`
- Token obtained via `/api/login`
- Token refreshed via `/api/refresh`

### Response Format
```json
{
  "success": true,
  "data": {...},
  "message": "Success message"
}
```

## Permission System

### Admin Role
- Full CRUD on all resources
- User management
- System configuration

### User Role
- View all projects/units/scenarios
- Edit scenarios (limited)
- Generate reports

## Security

- Laravel Sanctum for API authentication
- CSRF protection on web routes
- Input validation on all endpoints
- File upload validation
- Role-based access control
