<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EquipmentItem extends Model
{
    protected $fillable = [
        'map_layer_id',
        'name',
        'icon_path',
        'position_lat',
        'position_lng',
        'rotation',
        'size',
    ];

    protected $casts = [
        'position_lat' => 'decimal:8',
        'position_lng' => 'decimal:8',
        'rotation' => 'decimal:2',
    ];

    public function mapLayer(): BelongsTo
    {
        return $this->belongsTo(MapLayer::class);
    }
}
