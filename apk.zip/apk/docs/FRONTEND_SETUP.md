# Frontend Setup Guide (Flutter)

## Prerequisites

- Flutter SDK >= 3.0.0
- Dart SDK >= 3.0.0
- Android Studio / Xcode (for mobile development)
- Android SDK (for Android builds)
- Internet connection (for map tiles)

## Installation Steps

### 1. Install Flutter Dependencies

```bash
cd frontend
flutter pub get
```

### 2. Configure API Base URL

Edit `lib/core/constants/api_constants.dart`:

```dart
static const String baseUrl = 'http://your-backend-url:8000/api';
```

For Android emulator, use `http://10.0.2.2:8000/api`
For physical device, use your computer's IP address: `http://192.168.x.x:8000/api`

### 3. Run the Application

```bash
flutter run
```

## Building APK

### Debug APK

```bash
flutter build apk --debug
```

Output: `build/app/outputs/flutter-apk/app-debug.apk`

### Release APK

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`

### Split APKs (for smaller size)

```bash
flutter build apk --split-per-abi
```

This creates separate APKs for:
- `app-armeabi-v7a-release.apk` (32-bit)
- `app-arm64-v8a-release.apk` (64-bit)
- `app-x86_64-release.apk` (x86_64)

## APK Signing (Release)

### 1. Generate Keystore

```bash
keytool -genkey -v -keystore ~/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

### 2. Create key.properties

Create `android/key.properties`:

```properties
storePassword=your_store_password
keyPassword=your_key_password
keyAlias=upload
storeFile=/path/to/upload-keystore.jks
```

### 3. Update build.gradle

The `build.gradle` file should reference `key.properties` for signing configuration.

## Project Structure

```
frontend/
├── lib/
│   ├── main.dart
│   ├── core/
│   │   ├── constants/
│   │   ├── theme/
│   │   └── utils/
│   ├── data/
│   │   ├── models/
│   │   ├── repositories/
│   │   └── services/
│   ├── domain/
│   │   ├── entities/
│   │   └── repositories/
│   └── presentation/
│       ├── auth/
│       ├── projects/
│       ├── units/
│       ├── scenarios/
│       └── reports/
└── assets/
    └── icons/
```

## Map Configuration

The app uses **Leaflet maps** (via flutter_map) with OpenStreetMap tiles. No API key required!

### Custom Tile Layers

You can customize the map tiles by editing `map_tab.dart`:
- OpenStreetMap (default): `https://tile.openstreetmap.org/{z}/{x}/{y}.png`
- Other providers: Mapbox, CartoDB, etc.

### Layer Management

The map supports multiple toggleable layers:
- **Base Map**: OpenStreetMap tiles
- **Layout Layer**: Image overlays
- **Equipment Layer**: Markers with custom icons
- **Escape Route Layer**: Polylines
- **Risk Zone Layer**: Circles with wind direction

## Troubleshooting

### Maps not loading
- Check internet connection (required for map tiles)
- Verify OpenStreetMap tile server is accessible
- Check network permissions in AndroidManifest.xml

### API connection errors
- Check backend is running
- Verify CORS settings in Laravel
- Check network permissions in AndroidManifest.xml

### Build errors
- Run `flutter clean`
- Run `flutter pub get`
- Check Flutter and Dart versions compatibility
