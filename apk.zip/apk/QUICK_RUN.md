# Quick Run Guide - Abhi Run Karein! 🚀

## ✅ Frontend Ready!
Flutter dependencies install ho gaye hain!

## 📋 Ab Kya Karna Hai

### Step 1: Backend Start (Terminal 1)
```bash
cd backend

# Agar composer install nahi hua to:
composer install

# .env file check karo (agar nahi hai to .env.example se copy karo)
# Database credentials set karo

# Migrations run karo (agar nahi hui to):
php artisan migrate

# Server start karo:
php artisan serve
```

### Step 2: Frontend Run (Terminal 2)
```bash
cd frontend

# API URL check karo
# Edit: lib/core/constants/api_constants.dart
# Android Emulator: http://10.0.2.2:8000/api
# Physical Device: http://YOUR_IP:8000/api

# App run karo:
flutter run
```

### Step 3: Test
1. Login: `admin@example.com` / `password`
2. Sab features test karo!

## ⚡ Quick Commands

### Backend
```bash
cd backend
php artisan serve
```

### Frontend
```bash
cd frontend
flutter run
```

### Build APK
```bash
cd frontend
flutter build apk --release
```

## 🎉 Done!

Ab aap app use kar sakte hain!
