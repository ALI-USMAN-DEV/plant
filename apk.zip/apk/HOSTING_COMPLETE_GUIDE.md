# Project Hosting Guide - APK Ko Live Karne Ke Liye 🌐

## Overview
Yeh guide aapko batayega ke kaise aap apne backend ko cloud pe host karke APK ko kahin se bhi use kar sakte hain.

---

## 🎯 Kya Karna Hai?

1. **Backend ko cloud pe host karo** (Render, Railway, ya koi aur platform)
2. **API URL update karo** Flutter app mein
3. **APK rebuild karo** naye URL ke saath
4. **APK distribute karo** - ab kahin se bhi chalega!

---

## 📋 Option 1: Render.com (Recommended - Free Tier)

### Step 1: Render Account Banao
1. https://render.com pe jao
2. "Get Started for Free" click karo
3. GitHub se sign up karo (recommended)

### Step 2: Database Setup (MySQL)
1. Render dashboard mein **"New +"** click karo
2. **"PostgreSQL"** select karo (free tier available)
   - **Note:** Agar MySQL chahiye to **"MySQL"** select karo (paid)
   - Ya **PlanetScale** (free MySQL) use karo
3. Database name: `plant_layout_db`
4. Region: Choose closest to you
5. **"Create Database"** click karo
6. Database URL copy karo (baad mein use hoga)

### Step 3: Backend Deploy Karo
1. Render dashboard mein **"New +"** → **"Web Service"**
2. **GitHub repo connect karo** (ya code upload karo)
3. Settings:
   - **Name:** `plant-layout-api`
   - **Environment:** `PHP`
   - **Build Command:**
     ```bash
     composer install --no-dev --optimize-autoloader
     php artisan key:generate
     php artisan migrate --force
     php artisan db:seed --force
     ```
   - **Start Command:**
     ```bash
     php artisan serve --host=0.0.0.0 --port=$PORT
     ```
   - **Root Directory:** `backend`

4. **Environment Variables** add karo:
   ```
   APP_NAME=Plant Layout API
   APP_ENV=production
   APP_KEY=base64:YOUR_KEY_HERE
   APP_DEBUG=false
   APP_URL=https://your-app.onrender.com
   
   DB_CONNECTION=mysql
   DB_HOST=YOUR_DB_HOST
   DB_PORT=3306
   DB_DATABASE=plant_layout_db
   DB_USERNAME=YOUR_DB_USER
   DB_PASSWORD=YOUR_DB_PASSWORD
   
   CORS_ALLOWED_ORIGINS=*
   ```

5. **"Create Web Service"** click karo
6. Deploy hone ka wait karo (5-10 minutes)

### Step 4: URL Milne Ke Baad
- Render aapko URL dega: `https://your-app.onrender.com`
- API URL hoga: `https://your-app.onrender.com/api`

---

## 📋 Option 2: Railway.app (Free Tier - Easy)

### Step 1: Railway Account
1. https://railway.app pe jao
2. GitHub se sign up karo

### Step 2: New Project
1. **"New Project"** click karo
2. **"Deploy from GitHub repo"** select karo
3. Backend folder select karo

### Step 3: Database Add Karo
1. **"New"** → **"Database"** → **"MySQL"**
2. Database automatically create ho jayega
3. Connection details automatically environment variables mein add ho jayenge

### Step 4: Configure
1. **Settings** tab mein:
   - **Root Directory:** `backend`
   - **Start Command:** `php artisan serve --host=0.0.0.0 --port=$PORT`
   
2. **Variables** tab mein:
   ```
   APP_ENV=production
   APP_DEBUG=false
   ```
   (Database variables automatically add honge)

3. Deploy start ho jayega automatically

### Step 5: URL
- Railway aapko URL dega: `https://your-app.railway.app`
- API URL: `https://your-app.railway.app/api`

---

## 📋 Option 3: PlanetScale (Free MySQL) + Render

Agar aapko free MySQL chahiye:

1. **PlanetScale** (https://planetscale.com) pe account banao
2. New database create karo
3. Connection string copy karo
4. Render pe deploy karte waqt is connection string ko use karo

---

## 🔧 API URL Update Karna

### Method 1: Manual Update
1. File open karo: `frontend/lib/core/constants/api_constants.dart`
2. Line 15 update karo:
   ```dart
   static const String baseUrl = 'https://your-app.onrender.com/api';
   ```
   Ya
   ```dart
   static const String baseUrl = 'https://your-app.railway.app/api';
   ```

### Method 2: Script Use Karo
```powershell
.\UPDATE_API_URL.ps1 -Url "https://your-app.onrender.com/api"
```

---

## 📱 APK Rebuild Karna

URL update karne ke baad APK rebuild karna zaroori hai:

```powershell
cd frontend
flutter clean
flutter pub get
flutter build apk --release
```

Ya script use karo:
```powershell
.\REBUILD_APK.ps1
```

---

## ✅ Testing Checklist

1. ✅ Backend deployed hai?
   - Test: Browser mein `https://your-url.com/api` open karo
   - Response aana chahiye

2. ✅ API URL updated hai?
   - Check: `api_constants.dart` file

3. ✅ APK rebuild hua hai?
   - Check: `frontend/build/app/outputs/flutter-apk/app-release.apk`

4. ✅ APK test kiya?
   - Device pe install karo
   - Login try karo
   - Features test karo

---

## 🚀 Quick Start (Render)

1. **Render.com** pe account banao
2. **New Web Service** → GitHub repo connect karo
3. Settings configure karo (upar dekh lo)
4. Deploy wait karo
5. URL copy karo
6. API URL update karo
7. APK rebuild karo
8. Done! 🎉

---

## 📝 Important Notes

1. **Free Tier Limitations:**
   - Render: Service sleep ho sakta hai agar 15 minutes inactive ho
   - Railway: Monthly usage limit hai
   - Solution: Paid plan le lo ya multiple free accounts use karo

2. **Database:**
   - Production mein proper database use karo
   - Local database mat use karo

3. **Security:**
   - `APP_DEBUG=false` production mein
   - Strong passwords use karo
   - API keys secure rakho

4. **CORS:**
   - Mobile app ke liye CORS allow karo
   - `CORS_ALLOWED_ORIGINS=*` temporary testing ke liye OK hai

---

## 🆘 Troubleshooting

### Issue: Backend deploy nahi ho raha
- Check build logs
- Environment variables sahi hain?
- Database connection sahi hai?

### Issue: APK se connect nahi ho raha
- API URL sahi hai?
- HTTPS use kar rahe ho? (HTTP mobile pe kaam nahi karega)
- CORS settings check karo

### Issue: Database connection error
- Database credentials sahi hain?
- Database publicly accessible hai?
- Firewall rules check karo

---

## 📞 Next Steps

1. Hosting platform choose karo (Render recommended)
2. Backend deploy karo
3. URL update karo
4. APK rebuild karo
5. Test karo
6. Distribute karo! 🚀

---

**Ab aapka APK kahin se bhi chalega!** ✨
