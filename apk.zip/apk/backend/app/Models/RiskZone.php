<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RiskZone extends Model
{
    protected $fillable = [
        'map_layer_id',
        'name',
        'center_lat',
        'center_lng',
        'radius_meters',
        'color',
        'stroke_color',
        'stroke_width',
        'opacity',
        'wind_direction',
        'wind_velocity',
        'is_visible',
    ];

    protected $casts = [
        'center_lat' => 'decimal:8',
        'center_lng' => 'decimal:8',
        'radius_meters' => 'decimal:2',
        'opacity' => 'decimal:2',
        'wind_direction' => 'decimal:2',
        'wind_velocity' => 'decimal:2',
        'is_visible' => 'boolean',
    ];

    public function mapLayer(): BelongsTo
    {
        return $this->belongsTo(MapLayer::class);
    }
}
