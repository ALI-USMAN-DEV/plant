# GitHub Pe Pura Folder Upload Karne Ka Aasan Tarika 🚀

## ✅ Haan, Pura Folder Upload Karna Hai!

Aapko **pura project folder** GitHub pe upload karna hai, lekin kuch files exclude karni hain (like `.env`, `build/`, etc.)

---

## 🎯 Method 1: Git Commands (Recommended - Best Practice)

### Step 1: Git Install Check

```powershell
git --version
```

Agar nahi hai to: https://git-scm.com/download/win

### Step 2: Project Folder Mein Jao

```powershell
cd c:\Users\ah516\Desktop\apk
```

### Step 3: Git Initialize Karo

```powershell
git init
```

### Step 4: .gitignore Check Karo

**Agar `.gitignore` file nahi hai, to create karo:**

**File:** `.gitignore` (project root mein)

**Content:**
```
# Laravel Backend
backend/.env
backend/vendor/
backend/storage/*.key
backend/bootstrap/cache/*
backend/storage/framework/cache/*
backend/storage/framework/sessions/*
backend/storage/framework/views/*
backend/storage/logs/*

# Flutter Frontend
frontend/.dart_tool/
frontend/.flutter-plugins
frontend/.flutter-plugins-dependencies
frontend/.packages
frontend/.pub-cache/
frontend/.pub/
frontend/build/
frontend/.flutter/
frontend/.idea/
frontend/*.iml
frontend/.metadata
frontend/.fvm/

# OS Files
.DS_Store
Thumbs.db
*.log

# IDE Files
.vscode/
.idea/
*.swp
*.swo
*~

# Documentation (optional - agar exclude karna ho)
# *.md
```

### Step 5: Sab Files Add Karo

```powershell
git add .
```

**Ye command:**
- ✅ `.gitignore` ke according files add karega
- ❌ Excluded files skip karega

### Step 6: Status Check Karo

```powershell
git status
```

**Dekho ke kaunsi files add hui hain:**
- 🟢 Green = Added
- 🔴 Red = Not added (excluded by .gitignore)

### Step 7: Commit Karo

```powershell
git commit -m "Initial commit - Plant Layout Viewer project"
```

### Step 8: GitHub Pe Repository Banao

1. **https://github.com** pe jao
2. **Login karo**
3. **Top right "+" → "New repository"**
4. **Repository name:** `plant-layout-viewer` (ya koi bhi naam)
5. **❌ "Initialize with README" mat check karo**
6. **❌ "Add .gitignore" mat select karo**
7. **"Create repository" click karo**

### Step 9: Repository URL Copy Karo

**GitHub pe repository create hone ke baad:**
- **"Code" button click karo**
- **HTTPS URL copy karo:** `https://github.com/YOUR_USERNAME/plant-layout-viewer.git`

### Step 10: Connect & Push Karo

```powershell
git remote add origin https://github.com/YOUR_USERNAME/plant-layout-viewer.git
git branch -M main
git push -u origin main
```

**Agar password error aaye:**
- GitHub ab passwords accept nahi karta
- **Personal Access Token** chahiye hoga

**Token generate karo:**
1. GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. "Generate new token"
3. `repo` scope select karo
4. Token copy karo
5. Push command mein **password ki jagah token paste karo**

**✅ Pura folder GitHub pe upload ho gaya!**

---

## 🎯 Method 2: Manual Upload (Easier - Beginners)

### Step 1: GitHub Pe Repository Banao

1. **https://github.com** pe jao
2. **"New repository" click karo**
3. **Repository name:** `plant-layout-viewer`
4. **"Initialize with README" check karo** (optional)
5. **"Create repository" click karo**

### Step 2: Files Upload Karo

**GitHub repository page pe:**

1. **"uploading an existing file" link click karo** (ya "Add file" → "Upload files")

2. **Files drag & drop karo:**
   - **Pura folder drag karo** (ya individual files)
   - **Important:** `.env`, `build/`, `vendor/` mat upload karo!

3. **Files select karo:**
   - ✅ `backend/` folder (except `.env`, `vendor/`)
   - ✅ `frontend/` folder (except `build/`, `.dart_tool/`)
   - ✅ Root files (`.gitignore`, `README.md`, etc.)

4. **"Commit changes" click karo**

**⚠️ Note:** Ye method slow hai aur large files ke liye problem ho sakti hai. Git commands better hain.

---

## 📋 Kya Upload Karna Hai?

### ✅ Upload Karna Hai:
- ✅ `backend/` folder (except excluded files)
- ✅ `frontend/` folder (except excluded files)
- ✅ `.gitignore` file
- ✅ `README.md` (agar hai)
- ✅ Documentation files (optional)

### ❌ Upload NAHI Karna:
- ❌ `backend/.env` (sensitive data)
- ❌ `backend/vendor/` (composer install se mil jayega)
- ❌ `frontend/build/` (build files)
- ❌ `frontend/.dart_tool/` (temporary files)
- ❌ `.env` files (anywhere)
- ❌ `node_modules/` (agar hai)
- ❌ Large files (>100MB)

---

## 🔍 Verify Karo

**GitHub repository pe jao aur check karo:**

1. **Files dikh rahi hain?**
   - `backend/` folder
   - `frontend/` folder
   - `.gitignore` file

2. **Excluded files nahi hain?**
   - `.env` files
   - `build/` folders
   - `vendor/` folder

---

## 🆘 Common Issues

### Issue: Files Upload Nahin Ho Rahi

**Solution:**
- File size check karo (GitHub 100MB limit hai)
- Internet connection check karo
- Git commands use karo (faster)

### Issue: Password Error

**Solution:**
- Personal Access Token use karo
- Token expire ho gaya? Naya generate karo

### Issue: Too Many Files

**Solution:**
- `.gitignore` properly set karo
- Large files exclude karo
- Git commands use karo (better handling)

---

## ✅ Summary

**Haan, pura folder upload karna hai, lekin:**
- ✅ Git commands se (recommended)
- ✅ `.gitignore` se excluded files automatically skip ho jayengi
- ✅ Sensitive files mat upload karo

**Best Practice:** Method 1 (Git commands) use karo - faster, safer, aur better!

---

**Detailed Guide:** `GITHUB_RAILWAY_DEPLOY_STEPS.md` padho
