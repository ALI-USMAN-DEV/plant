# Update API Constants with Public ngrok URL
param(
    [Parameter(Mandatory=$true)]
    [string]$NgrokUrl
)

$apiConstantsFile = "frontend\lib\core\constants\api_constants.dart"

if (-not (Test-Path $apiConstantsFile)) {
    Write-Host "❌ File not found: $apiConstantsFile" -ForegroundColor Red
    exit 1
}

# Ensure URL has /api at the end
if (-not $NgrokUrl.EndsWith("/api")) {
    $NgrokUrl = "$NgrokUrl/api"
}

# Ensure URL starts with https://
if (-not $NgrokUrl.StartsWith("http")) {
    $NgrokUrl = "https://$NgrokUrl"
}

Write-Host "Updating API URL to: $NgrokUrl" -ForegroundColor Cyan

# Read file
$content = Get-Content $apiConstantsFile -Raw

# Update baseUrl
$pattern = "static const String baseUrl = '.*?';"
$replacement = "static const String baseUrl = '$NgrokUrl';"

if ($content -match $pattern) {
    $content = $content -replace $pattern, $replacement
    Set-Content -Path $apiConstantsFile -Value $content -NoNewline
    Write-Host "✅ API URL updated!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Next: Rebuild APK" -ForegroundColor Yellow
    Write-Host "  cd frontend" -ForegroundColor White
    Write-Host "  flutter clean" -ForegroundColor White
    Write-Host "  flutter pub get" -ForegroundColor White
    Write-Host "  flutter build apk --release" -ForegroundColor White
} else {
    Write-Host "❌ Could not find baseUrl in file" -ForegroundColor Red
    exit 1
}
